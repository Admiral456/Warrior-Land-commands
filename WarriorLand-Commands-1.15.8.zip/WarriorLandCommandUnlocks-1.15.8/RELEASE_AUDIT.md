# WarriorLand Command Unlocks — audit vydání 1.15.8

## Rozsah

Tato iterace zůstává čistě Paper-only pro Minecraft Java 1.21.10 a Java 21 bytecode. Neobsahuje Fabric, Forge, klientský mód ani plugin-message bridge.

## Změny 1.15.8

- Přidán generátor `scripts/render_source_preview.py`, který čte `config.yml`, `MenuLayout.java` a skutečné PNG modely z resource packu. Generuje celoplošný zdrojový náhled a zvětšený detail do `docs/source-preview.png`, `docs/source-preview-detail.png` a `docs/source-preview-task-progress.png`.
- Náhled používá skutečné pořadí katalogu (výchozí řazení), skutečnou cenu a závislost `/chatcolour` a reálné sloty 54slotového Paper inventáře. Ukázkový zůstatek a stavy jsou výslovně demo data, nikoli údaje konkrétního hráče.
- Vylepšena volitelná ItemsAdder textura pozadí: ostřejší fialový rám, tmavě modré/indigové vrstvy a dekorativní noční silueta; průhledná okna 54 slotů a rozměr 176×222 zůstávají zachovány.
- Zdrojový náhled se regeneruje ve build skriptu i GitHub Actions a je součástí release artifactů.
- Katalog, ceny, úkoly, permission nodes, HUD, tutorial a nákupní logika se nemění.

## Zachované funkce

- Spodní quick-guide lišta v hlavním GUI je skutečně interaktivní: Úkoly otevírají krok 4 tutorialu, Moje body otevírají statistiky, Legenda stavů vysvětluje barvy a HUD přepíná uloženou osobní preferenci bez restartu.
- Tlačítko Tutoriál v horní řadě otevírá šestistránkový Paper inventory návod. Stávající první-volba Ano/Ne a opakování zůstávají zachované.
- `CommandCardVisualPolicy` vybírá stav každé karty podle vlastnictví, chybějících závislostí, dokončení úkolů a dostupného zůstatku.
- Volitelný resource pack obsahuje pět vizuálních variant na každou ze 75 příkazových ikon: zelená `unlocked`, zlatá `ready`, oranžová `insufficient`, šedofialová `locked`, červená `unavailable`.
- BossBar používá `SEGMENTED_12` a kratší, konzistentnější text s body, odemčeními a úkoly.
- Přidány JUnit testy pro mapování rychlých akcí a pravidla stavových ikon. Validátory kontrolují existenci každé varianty i JSON reference.


## Volitelná ItemsAdder vrstva

- Projekt obsahuje reflexivní, compile-time volitelné napojení na `TexturedInventoryWrapper`/`FontImageWrapper`; preferuje aktuální konstruktorové varianty s `titleOffset`/`textureOffset`, podporuje starší veřejné varianty a při neexistujícím glyphu nebo neplatném inventáři se přepne na normální Paper inventory.
- Samostatný content addon definuje `warriorland_unlocks:command_menu_background` a 176×222 RGBA font-image. Konfigurace je ve výchozím nastavení vypnutá.
- Generátor a validátor kontrolují YAML, namespace, rozměry textury, průhledná slotová okna a vazbu font image ID.
- ItemsAdder je doporučená volitelná závislost pro větší vizuální posun bez Fabricu. Není nutný pro funkčnost nákupů ani HUDu. Skutečné zarovnání je stále potřeba testovat na dané verzi ItemsAdderu na staging serveru.

## Ověření provedené v tomto prostředí

- `scripts/generate_resource_pack_icons.py`: regenerace 75 základních ikon.
- `scripts/generate_command_icon_states.py`: vygenerování 375 stavových variant.
- `scripts/render_source_preview.py`: PASS — hlavní náhled, zvětšený detail i tooltip úkolu vygenerovány z aktuálního zdroje a resource packu.
- `scripts/validate_project.py`: YAML, katalog, aliasy, kategorie, ceny/úkoly, 54slotové GUI a reference modelů.
- `scripts/validate_server_only.py`: Paper-only architektura, test policy HUD/tutorial/resource pack a stavové varianty.
- Java 21 syntax parse: všech 89 Java zdrojových a testovacích souborů prošlo syntaktickým parsováním bez chyby.
- Samostatný Java smoke test `ItemsAdderConstructorPolicy`: **6 případů PASS** v předchozí iteraci 1.15.7; Java runtime kód se v 1.15.8 neměnil, proto tento smoke test nebyl v této iteraci znovu spuštěn.
- `scripts/validate_project.py`: PASS — 75 odemčení, 101 unikátních selektorů, kategorie, ceny/úkoly, modely a resource pack.
- `scripts/validate_server_only.py`: PASS — Paper-only balení, tutorial/HUD/resource pack a nové ItemsAdder offsety/diagnostika.
- Maven/Gradle/JUnit full build: **neproveden v tomto prostředí** — executable Gradle není nainstalovaný a DNS nedovoluje stáhnout Gradle/dependencies. JUnit testy včetně nových pěti konstruktorových testů jsou připravené pro CI, ale zde nejsou označeny jako spuštěné.
- Runtime test na skutečném Paper serveru: **neproveden**.

## Důležité limity

Standardní Bukkit inventory má 54 slotů; položka zůstává jedním skutečným předmětem a dlouhý text je tooltip. Stavové varianty pomáhají rychle odlišit kartu, ale nepromění inventář v úplně vlastní celoobrazovkovou aplikaci. Pro větší grafický posun bez klientského módu dává smysl využít existující ItemsAdder: jeho font images umí zobrazit vlastní glyphy a lze přes API stavět vlastní HUD/GUIs. To musí být nasazeno jako resource-pack content společně s ostatním packem a otestováno na konkrétní verzi ItemsAdderu. Bez toho běží fallback ikony i základní Paper HUD.

## Před produkcí

1. Spusť `scripts/build_release.sh` nebo GitHub Actions.
2. Ověř úspěšný JUnit/Gradle build a vznik `build/libs/WarriorLandCommandUnlocks-1.15.8.jar`.
3. Na kopii Paper 1.21.10 otestuj klikací rychlou lištu, tutorial Ano/Ne/reset, HUD on/off/status, nákupní potvrzení a odchod/připojení.
4. Pokud používáš vlastní ikony, nahraj resource pack na HTTPS hosting, nastav URL/SHA-1 a povol `settings.use-resource-pack-icons`.
5. Pokud používáš ItemsAdder background, nainstaluj addon, spusť `/iareload` a `/iazip`, nastav `itemsadder-textured-gui: true` a ověř zarovnání `itemsadder-title-offset` / `itemsadder-texture-offset` na stagingu.
6. Neoznačuj vydání jako produkčně ověřené dřív, než projdou build a runtime testy.
