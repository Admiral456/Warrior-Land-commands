#!/usr/bin/env python3
"""Static release validator for WarriorLand; requires PyYAML (development-only)."""
from __future__ import annotations
import collections
import pathlib
import re
import sys
import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
RESOURCE = ROOT / "src/main/resources"
CONFIG_PATH = RESOURCE / "config.yml"
PLUGIN_PATH = RESOURCE / "plugin.yml"
VALID_COMMAND = re.compile(r"^[a-z0-9_.-]+(?: [a-z0-9_.-]+)*$")
TASK_TYPES = {"BREAK_BLOCK", "FISH_CAUGHT", "KILL_MOB", "CRAFT_ITEM", "VOTE", "JOBS_ACTION"}
FILTERS = {
    "materials": {"BREAK_BLOCK", "FISH_CAUGHT", "CRAFT_ITEM"},
    "entities": {"KILL_MOB"},
    "jobs": {"JOBS_ACTION"},
}


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def main() -> int:
    errors: list[str] = []
    build_text = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
    if "JavaLanguageVersion.of(21)" not in build_text or "options.release.set(21)" not in build_text:
        fail(errors, "Paper/Minecraft 1.21.10 release must compile to Java 21 bytecode")
    workflow_text = (ROOT / ".github/workflows/build.yml").read_text(encoding="utf-8")
    readme_text = (ROOT / "README.md").read_text(encoding="utf-8")
    custom_doc_text = (ROOT / "CUSTOM_COMMANDS.md").read_text(encoding="utf-8")
    gui_doc_text = (ROOT / "docs/MENU_UI.md").read_text(encoding="utf-8")
    testing_text = (ROOT / "TESTING.md").read_text(encoding="utf-8")
    changelog_text = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    audit_text = (ROOT / "RELEASE_AUDIT.md").read_text(encoding="utf-8") if (ROOT / "RELEASE_AUDIT.md").exists() else ""
    test_source = (ROOT / "src/test/java/cz/warriorland/commandunlocks/DefaultConfigIntegrityTest.java").read_text(encoding="utf-8")
    layout_source = (ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuLayout.java").read_text(encoding="utf-8")
    menu_manager_source = (ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuManager.java").read_text(encoding="utf-8")
    layout_test_source = (ROOT / "src/test/java/cz/warriorland/commandunlocks/MenuLayoutTest.java").read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"', build_text, re.M)
    if not match:
        fail(errors, "build.gradle.kts does not define a numeric semantic project version")
        project_version = ""
    else:
        project_version = match.group(1)
    try:
        config = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
        metadata = yaml.safe_load(PLUGIN_PATH.read_text(encoding="utf-8"))
        workflow = yaml.safe_load(workflow_text)
    except Exception as exc:
        print(f"FAIL YAML parse: {exc}")
        return 1
    if not isinstance(config, dict) or not isinstance(metadata, dict) or not isinstance(workflow, dict):
        print("FAIL YAML roots must be mappings")
        return 1
    build_job = workflow.get("jobs", {}).get("build") if isinstance(workflow.get("jobs"), dict) else None
    if not isinstance(build_job, dict) or not isinstance(build_job.get("steps"), list) or not build_job.get("steps"):
        print("FAIL .github/workflows/build.yml must define jobs.build.steps")
        return 1

    unlocks = config.get("unlocks")
    categories = config.get("categories")
    if not isinstance(unlocks, dict) or not unlocks:
        fail(errors, "config.yml must contain a non-empty unlocks mapping")
        unlocks = {}
    if not isinstance(categories, dict) or not categories:
        fail(errors, "config.yml must contain a non-empty categories mapping")
        categories = {}
    if len(unlocks) < 40:
        fail(errors, f"expected at least 40 unlocks, found {len(unlocks)}")

    # Catch the previously observed release bug where source, tests and CI named different JAR versions.
    if project_version:
        expected_artifact = f"WarriorLandCommandUnlocks-{project_version}.jar"
        if not changelog_text.startswith(f"## {project_version}\n"):
            fail(errors, f"CHANGELOG.md must start with release {project_version}")
        if not audit_text.startswith(f"# WarriorLand Command Unlocks — audit vydání {project_version}\n"):
            fail(errors, f"RELEASE_AUDIT.md must identify release {project_version}")
        for label, content in (("README.md", readme_text), ("CUSTOM_COMMANDS.md", custom_doc_text),
                               ("docs/MENU_UI.md", gui_doc_text), ("TESTING.md", testing_text)):
            heading_has_version = (f"## Funkce aktuální verze {project_version}" in content
                                   if label == "README.md" else project_version in content.splitlines()[0])
            if not heading_has_version:
                fail(errors, f"{label} current-version heading must identify release {project_version}")
        if expected_artifact not in readme_text:
            fail(errors, f"README.md must use {expected_artifact}")
        if f'JAR="build/libs/{expected_artifact}"' not in workflow_text:
            fail(errors, f"GitHub Actions must verify {expected_artifact}")
        if f"version: '{project_version}'" not in workflow_text:
            fail(errors, f"GitHub Actions metadata check must expect {project_version}")
        if f"name: WarriorLandCommandUnlocks-{project_version}-${{{{ github.sha }}}}" not in workflow_text:
            fail(errors, "GitHub Actions artifact name must match the current release version")
        if 'System.getProperty("warriorland.projectVersion")' not in test_source:
            fail(errors, "metadata JUnit test must compare plugin.yml with Gradle's project version")
        if 'systemProperty("warriorland.projectVersion", project.version.toString())' not in build_text:
            fail(errors, "Gradle test task must pass project.version to JUnit")
    if metadata.get("version") != "${version}":
        fail(errors, "plugin.yml version should be Gradle-filtered using ${version}")

    # Search/sort must use a server-side policy and ship focused regression coverage.
    search_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/CommandSearchPolicy.java"
    search_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/CommandSearchPolicyTest.java"
    if not search_policy.exists() or not search_test.exists():
        fail(errors, "server-side catalog search policy and JUnit regression tests must ship")
    else:
        policy_text = search_policy.read_text(encoding="utf-8")
        test_text = search_test.read_text(encoding="utf-8")
        if "MAX_QUERY_LENGTH = 48" not in policy_text or "isValidSort" not in policy_text:
            fail(errors, "search policy must bound query length and validate sort modes")
        if "sanitizesSeparatorsControlsAndLength" not in test_text or "validatesOnlySupportedSortModes" not in test_text:
            fail(errors, "search policy tests must cover sanitization and sort allow-list")
    for example in (ROOT / "examples/mycommand/mycommand-wltips-snippet.yml", ROOT / "examples/mycommand/warriorland-unlock-wltips-snippet.yml"):
        try:
            yaml.safe_load(example.read_text(encoding="utf-8"))
        except Exception as exc:
            fail(errors, f"MyCommand YAML example {example.name} is invalid: {exc}")

    # MyCommand must be a soft dependency so its registered custom commands exist before alias discovery.
    softdepend = metadata.get("softdepend", [])
    if "MyCommand" not in softdepend:
        fail(errors, "plugin.yml softdepend must include MyCommand for registered custom-command discovery")
    mycommand_doc = ROOT / "docs/MYCOMMAND_INTEGRATION.md"
    mycommand_example = ROOT / "examples/mycommand/mycommand-wltips-snippet.yml"
    unlock_example = ROOT / "examples/mycommand/warriorland-unlock-wltips-snippet.yml"
    if not mycommand_doc.exists() or not mycommand_example.exists() or not unlock_example.exists():
        fail(errors, "MyCommand integration guide and both matching YAML snippets must ship with the source")
    else:
        mycommand_text = mycommand_example.read_text(encoding="utf-8")
        unlock_text = unlock_example.read_text(encoding="utf-8")
        node = "warriorland.unlocks.custom.wltips"
        if "register: true" not in mycommand_text or "permission-required: true" not in mycommand_text:
            fail(errors, "MyCommand unlock example must register its command and require permission")
        if f"permission-node: {node}" not in mycommand_text or f"- {node}" not in unlock_text:
            fail(errors, "MyCommand permission node must match the corresponding unlock grant")
        if "RUN_AS_OPERATOR" in mycommand_text or "RUN_CONSOLE" in mycommand_text:
            fail(errors, "The shipped MyCommand example must not execute privileged console commands")

    category_slots: list[int] = []
    for cat_id, category in categories.items():
        if not isinstance(category, dict):
            fail(errors, f"categories.{cat_id} must be a mapping")
            continue
        slot = category.get("slot")
        if isinstance(slot, bool) or not isinstance(slot, int) or slot not in {0, 9, 18, 27, 36}:
            fail(errors, f"categories.{cat_id}: sidebar slot must be one of 0, 9, 18, 27, 36")
        elif slot in category_slots:
            fail(errors, f"categories.{cat_id}: sidebar slot {slot} is duplicated")
        else:
            category_slots.append(slot)
    if "all" not in categories:
        fail(errors, "categories must include the 'all' category for the all-items shop view")
    if len(categories) != len(category_slots):
        fail(errors, "every category must have one unique sidebar slot")

    # Verify the actual Java slot map, not just the explanatory docs/diagram.
    layout_arrays: dict[str, list[int]] = {}
    for array_name in ("CARD_SLOTS", "QUICK_INFO_SLOTS", "DETAIL_SLOTS", "SEPARATOR_SLOTS", "CATEGORY_SLOTS", "HEADER_SLOTS", "FOOTER_SLOTS"):
        array_match = re.search(rf"private static final int\[\] {array_name}\s*=\s*\{{([^}}]*)\}};", layout_source, re.S)
        if not array_match:
            fail(errors, f"MenuLayout.java is missing slot array {array_name}")
            continue
        values = [int(value) for value in re.findall(r"-?\d+", array_match.group(1))]
        if len(values) != len(set(values)):
            fail(errors, f"MenuLayout.{array_name} contains duplicate slots")
        if any(value < 0 or value >= 54 for value in values):
            fail(errors, f"MenuLayout.{array_name} contains an out-of-range inventory slot")
        layout_arrays[array_name] = values
    if len(layout_arrays.get("CARD_SLOTS", [])) != 12:
        fail(errors, "GUI must show exactly 12 command cards per page in the current readable layout")
    if len(layout_arrays.get("QUICK_INFO_SLOTS", [])) != 4:
        fail(errors, "GUI must reserve four quick-guide slots below the 12 command cards")
    expected_slot_groups = ("CATEGORY_SLOTS", "HEADER_SLOTS", "SEPARATOR_SLOTS", "CARD_SLOTS", "QUICK_INFO_SLOTS", "DETAIL_SLOTS", "FOOTER_SLOTS")
    combined_slots: list[int] = []
    for array_name in expected_slot_groups:
        combined_slots.extend(layout_arrays.get(array_name, []))
    if len(combined_slots) != len(set(combined_slots)):
        fail(errors, "GUI slot groups overlap in MenuLayout.java")
    if set(combined_slots) != set(range(54)):
        fail(errors, "GUI slot groups must cover all 54 inventory slots exactly once")
    if set(layout_arrays.get("CATEGORY_SLOTS", [])) != set(category_slots):
        fail(errors, "MenuLayout category slots must match categories configured in config.yml")
    if "slot == 50" not in menu_manager_source or "slot == 43" not in menu_manager_source:
        fail(errors, "MenuManager click handling must match the next-page and detail action slots")
    if "inventory.setItem(43, item(Material.EMERALD_BLOCK" not in menu_manager_source:
        fail(errors, "MenuManager must place the purchase action in the documented detail action slot")
    if "MenuLayout.cardSlots()" not in menu_manager_source or "MenuLayout.detailSlots()" not in menu_manager_source:
        fail(errors, "MenuManager must consume the tested MenuLayout slot map")
    if "allSectionsFitThe54SlotInventoryWithoutOverlaps" not in layout_test_source:
        fail(errors, "MenuLayoutTest must test inventory slot overlap")

    normalized_ids: set[str] = set()
    selectors: dict[str, str] = {}
    total_selectors = 0
    for raw_id, item in unlocks.items():
        if not isinstance(item, dict):
            fail(errors, f"unlocks.{raw_id} must be a mapping")
            continue
        uid = str(raw_id).lower()
        if not re.fullmatch(r"[a-z0-9_-]+", uid):
            fail(errors, f"invalid unlock id {raw_id!r}")
        if uid in normalized_ids:
            fail(errors, f"case-insensitive duplicate unlock id {raw_id!r}")
        normalized_ids.add(uid)
        if str(item.get("category", "utility")).lower() not in categories:
            fail(errors, f"unlocks.{raw_id}: unknown category {item.get('category')!r}")
        required_plugins = item.get("required-plugins", [])
        if not isinstance(required_plugins, list) or any(not isinstance(plugin_name, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", plugin_name.strip()) for plugin_name in required_plugins):
            fail(errors, f"unlocks.{raw_id}: required-plugins must be a list of plugin names")
        elif len({name.lower() for name in required_plugins}) != len(required_plugins):
            fail(errors, f"unlocks.{raw_id}: duplicate required-plugins entries")
        commands = item.get("commands")
        if not isinstance(commands, list) or not commands:
            fail(errors, f"unlocks.{raw_id}: commands must be a non-empty list")
            commands = []
        seen_local: set[str] = set()
        for raw_cmd in commands:
            if not isinstance(raw_cmd, str):
                fail(errors, f"unlocks.{raw_id}: command selectors must be strings")
                continue
            cmd = " ".join(raw_cmd.strip().lstrip("/").lower().split())
            total_selectors += 1
            if not VALID_COMMAND.fullmatch(cmd):
                fail(errors, f"unlocks.{raw_id}: invalid selector {raw_cmd!r}")
            if cmd in seen_local:
                fail(errors, f"unlocks.{raw_id}: duplicate selector {cmd!r}")
            seen_local.add(cmd)
            previous = selectors.get(cmd)
            if previous is not None and previous != uid:
                fail(errors, f"selector {cmd!r} appears in both {previous!r} and {uid!r}")
            selectors[cmd] = uid
        permissions = item.get("permissions")
        if not isinstance(permissions, list) or not permissions or not all(isinstance(x, str) and x.strip() for x in permissions):
            fail(errors, f"unlocks.{raw_id}: permissions must be a non-empty list of non-empty strings")
        elif len({x.strip().lower() for x in permissions}) != len(permissions):
            fail(errors, f"unlocks.{raw_id}: permission list contains case-insensitive duplicates")
        for numeric in ("cost", "task-reward"):
            value = item.get(numeric, 0 if numeric == "task-reward" else None)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                fail(errors, f"unlocks.{raw_id}: {numeric} must be a non-negative integer")
        tasks = item.get("tasks")
        if not isinstance(tasks, list) or not tasks:
            fail(errors, f"unlocks.{raw_id}: tasks must be a non-empty list")
            tasks = []
        task_ids: set[str] = set()
        for index, task in enumerate(tasks):
            where = f"unlocks.{raw_id}.tasks[{index}]"
            if not isinstance(task, dict):
                fail(errors, f"{where} must be a mapping")
                continue
            task_id = str(task.get("id", "")).lower()
            if not task_id or task_id in task_ids:
                fail(errors, f"{where}: missing or duplicate task id {task_id!r}")
            task_ids.add(task_id)
            task_type = str(task.get("type", "")).upper()
            if task_type not in TASK_TYPES:
                fail(errors, f"{where}: unsupported type {task_type!r}")
            amount = task.get("amount")
            if isinstance(amount, bool) or not isinstance(amount, int) or amount < 1:
                fail(errors, f"{where}: amount must be a positive integer")
            for field, allowed_types in FILTERS.items():
                values = task.get(field)
                if values is not None and (not isinstance(values, list) or not all(isinstance(x, str) and x.strip() for x in values)):
                    fail(errors, f"{where}: {field} must be a list of non-empty strings")
                elif values and task_type not in allowed_types:
                    fail(errors, f"{where}: {field} is incompatible with {task_type}")
            if task_type == "JOBS_ACTION" and not task.get("jobs"):
                fail(errors, f"{where}: JOBS_ACTION must list jobs")

    for name in ("prikazy", "chatcolour", "nickcolour"):
        if not isinstance(metadata.get("commands", {}).get(name), dict):
            fail(errors, f"plugin.yml does not register /{name}")
    if metadata.get("main") != "cz.warriorland.commandunlocks.CommandUnlocksPlugin":
        fail(errors, "plugin.yml main class does not match source package")
    if str(metadata.get("api-version")) != "1.21.10":
        fail(errors, "plugin.yml api-version differs from the pinned Paper API target")

    expected_aliases = ["chatcolour", "chatcolor"]
    if unlocks.get("chatcolour", {}).get("commands") != expected_aliases:
        fail(errors, "chatcolour/chatcolor must remain aliases of the same unlock item")
    if "chatcolor" in unlocks:
        fail(errors, "chatcolor must not be a second paid unlock item")
    if unlocks.get("chatcolour", {}).get("required-plugins") != ["ChatColor2"]:
        fail(errors, "unlocks.chatcolour must require ChatColor2 to avoid selling an unavailable feature")
    if unlocks.get("nickcolour", {}).get("required-plugins") != ["Essentials"]:
        fail(errors, "unlocks.nickcolour must require Essentials for its implementation")
    if "other" in unlocks:
        fail(errors, "unverified command 'other' must not be sold as a real feature")
    hud_source = (ROOT / "src/main/java/cz/warriorland/commandunlocks/HudNotifier.java").read_text(encoding="utf-8")
    hud_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/HudStatusPolicy.java"
    hud_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/HudStatusPolicyTest.java"
    if config.get("settings", {}).get("hud-status-bar") is not True or "SEGMENTED_12" not in hud_source:
        fail(errors, "native Paper BossBar HUD should be enabled by default and use a segmented bar")
    if not hud_policy.is_file() or not hud_test.is_file() or "HudStatusPolicy.progress" not in hud_source:
        fail(errors, "native HUD preferences/progress must have a tested, clamped policy")
    if not (ROOT / "src/main/java/cz/warriorland/commandunlocks/PlayerDataStore.java").is_file() or "setHudChoice" not in (ROOT / "src/main/java/cz/warriorland/commandunlocks/PlayerDataStore.java").read_text(encoding="utf-8"):
        fail(errors, "per-player HUD choice must be persisted")
    for id_ in ("workbench", "ignore", "nick", "nickcolour"):
        if id_ not in unlocks:
            fail(errors, f"expected reviewed custom/Essentials entry {id_!r} is missing")

    if errors:
        print(f"FAIL: {len(errors)} issue(s)")
        for error in errors:
            print(f" - {error}")
        return 1
    cats = collections.Counter(str(item.get("category", "utility")).lower() for item in unlocks.values())
    print("PASS YAML parse: config.yml, plugin.yml and .github/workflows/build.yml")
    print(f"PASS catalog: {len(unlocks)} definitions, {total_selectors} selectors, {len(selectors)} unique selectors")
    print("PASS catalog integrity: IDs, aliases, categories, permissions, costs, rewards, tasks and filter compatibility")
    print(f"PASS category distribution: {dict(sorted(cats.items()))}")
    print("PASS approved entries: workbench, ignore, nick, chatcolour/chatcolor (one purchase), nickcolour; 'other' excluded as unverified")
    print("PASS dependency gates: ChatColor2 and Essentials requirements are declared for dependent custom features")
    print("PASS metadata: command registrations, main class, Paper API target")
    print(f"PASS release consistency: Gradle, README, docs, JUnit metadata assertion, CI artifact and changelog agree on {project_version}")
    print(f"PASS GUI categories: {len(categories)} unique sidebar slots and the all-items category")
    print(f"PASS GUI layout: {len(layout_arrays.get('CARD_SLOTS', []))} cards/page; all 54 slots are uniquely assigned and covered")
    return 0

if __name__ == "__main__":
    sys.exit(main())
