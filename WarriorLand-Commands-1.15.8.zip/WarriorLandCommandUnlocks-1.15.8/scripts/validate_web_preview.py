#!/usr/bin/env python3
"""Validate the static WarriorLand web preview against the authoritative Paper config."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
errors: list[str] = []

def check(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)

config = yaml.safe_load((ROOT / "src/main/resources/config.yml").read_text(encoding="utf-8"))
plugin = yaml.safe_load((ROOT / "src/main/resources/plugin.yml").read_text(encoding="utf-8"))
gradle = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
version_match = re.search(r'^version\s*=\s*"([^"]+)"', gradle, re.MULTILINE)
source_version = version_match.group(1) if version_match else "unknown"
web = json.loads((WEB / "data/catalog.json").read_text(encoding="utf-8"))
source_unlocks = config.get("unlocks") or {}
entries = web.get("unlocks") or []
check(web.get("version") == source_version, "web catalogue version does not match build.gradle.kts")
check(len(entries) == len(source_unlocks) == 75, f"expected 75 items; got web={len(entries)} source={len(source_unlocks)}")
ids = [entry.get("id") for entry in entries]
check(len(ids) == len(set(ids)), "duplicate unlock IDs in web catalogue")
check(set(ids) == set(source_unlocks), "web catalogue IDs differ from config.yml")
counts = Counter(entry.get("category") for entry in entries)
source_counts = Counter(definition.get("category", "utility") for definition in source_unlocks.values())
check(counts == source_counts, f"category counts differ: web={dict(counts)} source={dict(source_counts)}")

for unlock_id, definition in source_unlocks.items():
    item = next((entry for entry in entries if entry.get("id") == unlock_id), None)
    if item is None:
        continue
    check(item.get("cost") == int(definition.get("cost", 0)), f"{unlock_id}: price mismatch")
    check(item.get("commands") == definition.get("commands", []), f"{unlock_id}: command aliases mismatch")
    check(item.get("requiredPlugins", []) == definition.get("required-plugins", []), f"{unlock_id}: required plugins mismatch")
    check(item.get("tasks", []) == definition.get("tasks", []), f"{unlock_id}: tasks mismatch")
    for suffix in ("", "_locked", "_ready", "_insufficient", "_unavailable", "_unlocked"):
        icon = WEB / "assets/command-icons" / f"{unlock_id}{suffix}.png"
        check(icon.is_file(), f"missing command image {icon.relative_to(ROOT)}")

for relative in ("index.html", "styles.css", "app.js", "data/catalog.json", "assets/backgrounds/warriorland-night.jpg"):
    check((WEB / relative).is_file(), f"missing web file: {relative}")

node = subprocess.run(["node", "--check", str(WEB / "app.js")], capture_output=True, text=True)
check(node.returncode == 0, f"JavaScript syntax check failed: {node.stderr.strip()}")

if errors:
    print(f"FAIL web preview validation: {len(errors)} issue(s)")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"PASS web catalogue: {len(entries)} unlocks; categories {dict(counts)}")
print("PASS catalogue data matches src/main/resources/config.yml")
print("PASS all 450 per-command base and state icon files are present")
print("PASS web structure, background asset and JavaScript syntax")
