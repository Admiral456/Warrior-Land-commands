#!/usr/bin/env python3
"""Validate Paper-only packaging, tutorial persistence, and optional 1.21.10 resource-pack models."""
from __future__ import annotations
import json
import pathlib
import re
import sys
import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
errors: list[str] = []
def check(condition: bool, message: str) -> None:
    if not condition: errors.append(message)

build = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
plugin = (ROOT / "src/main/java/cz/warriorland/commandunlocks/CommandUnlocksPlugin.java").read_text(encoding="utf-8")
manager = (ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuManager.java").read_text(encoding="utf-8")
command = (ROOT / "src/main/java/cz/warriorland/commandunlocks/UnlockCommand.java").read_text(encoding="utf-8")
store = (ROOT / "src/main/java/cz/warriorland/commandunlocks/PlayerDataStore.java").read_text(encoding="utf-8")
listener = (ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuListener.java").read_text(encoding="utf-8")
config = yaml.safe_load((ROOT / "src/main/resources/config.yml").read_text(encoding="utf-8"))
metadata = yaml.safe_load((ROOT / "src/main/resources/plugin.yml").read_text(encoding="utf-8"))

check('version = "1.15.8"' in build, "Gradle version must be 1.15.8")
check((ROOT / "scripts/build_release.sh").is_file(), "a reproducible local release build script must be included")
check(not (ROOT / "ClientMod").exists(), "ClientMod directory must not ship in the Paper-only project")
check(not (ROOT / "src/main/java/cz/warriorland/commandunlocks/ClientUiBridge.java").exists(), "ClientUiBridge must be removed")
check(not (ROOT / "src/main/java/cz/warriorland/commandunlocks/ClientActionRateLimiter.java").exists(), "ClientActionRateLimiter is client-bridge-only and must be removed")
check("plugin-message" not in plugin.lower() and "registerOutgoingPluginChannel" not in plugin and "registerIncomingPluginChannel" not in plugin,
      "server plugin must not register client plugin-message channels")
check("getTutorialChoice" in command and "openTutorialPrompt" in command, "first-run /prikazy flow must consult and open the tutorial prompt")
check("tutorial-enabled" in store and "saveSync()" in store, "tutorial decision must be saved persistently in players.yml")
check("TUTORIAL_STEPS" in manager and "openTutorialPage" in manager and "handleTutorialClick" in manager,
      "tutorial must run entirely in Paper inventory screens")
check("TutorialHolder" in listener and "setCancelled(true)" in listener, "tutorial inventories must be identified and protected from item movement")
check(config.get("settings", {}).get("hud-status-bar") is True, "persistent vanilla BossBar HUD must be enabled by default")
check("BossBar" in (ROOT / "src/main/java/cz/warriorland/commandunlocks/HudNotifier.java").read_text(encoding="utf-8")
      and "SEGMENTED_12" in (ROOT / "src/main/java/cz/warriorland/commandunlocks/HudNotifier.java").read_text(encoding="utf-8")
      and "HudStatusPolicy.isTaskComplete" in (ROOT / "src/main/java/cz/warriorland/commandunlocks/HudNotifier.java").read_text(encoding="utf-8"),
      "server HUD must use a native segmented BossBar instead of requiring a client mod")
check('case "hud" -> handleHud(sender, args)' in command and "getHudChoice" in store and "setHudChoice" in store and 'case "on",' in command and 'case "off",' in command,
      "players must be able to persistently toggle their HUD on/off/status")
quick_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuQuickActionPolicy.java"
quick_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/MenuQuickActionPolicyTest.java"
visual_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/CommandCardVisualPolicy.java"
visual_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/CommandCardVisualPolicyTest.java"
menu_manager = (ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuManager.java").read_text(encoding="utf-8")
check(quick_policy.is_file() and quick_test.is_file() and "MenuQuickActionPolicy.actionFor" in menu_manager,
      "bottom quick-guide bar actions must be clickable and covered by unit tests")
check(visual_policy.is_file() and visual_test.is_file() and "CommandCardVisualPolicy.variant" in menu_manager,
      "command-card icon status colors must be selected by tested state policy")
check((ROOT / "src/main/java/cz/warriorland/commandunlocks/HudStatusPolicy.java").is_file()
      and (ROOT / "src/test/java/cz/warriorland/commandunlocks/HudStatusPolicyTest.java").is_file(),
      "BossBar HUD preference/progress policy must have dedicated unit tests")
check(config.get("settings", {}).get("use-resource-pack-icons") is False,
      "optional item model integration must remain disabled by default")
check(config.get("settings", {}).get("allow-unverified-manual-resource-pack-icons") is False,
      "unverified manual resource-pack icons must remain disabled by default")
check(config.get("settings", {}).get("itemsadder-textured-gui") is False,
      "ItemsAdder textured inventory must remain optional/off by default")
check(config.get("settings", {}).get("itemsadder-font-image") == "warriorland_unlocks:command_menu_background",
      "ItemsAdder font image id must match the supplied optional content addon")
check("TexturedInventoryWrapper" in manager and "warriorland_unlocks:command_menu_background" in manager
      and "using the safe vanilla inventory" in manager,
      "optional ItemsAdder GUI integration must use the textured wrapper and preserve vanilla fallback")
check("FontImageWrapper" in manager and 'getMethod("exists")' in manager
      and "lastTexturedGuiCreationSucceeded = true" in manager and "itemsAdderGuiStatus" in manager,
      "ItemsAdder glyph existence and last creation result must be diagnosed rather than assumed")
check("plugin.resourcePackListener() != null" in manager and "canUseCustomIcons(player)" in manager,
      "custom item models must never be used just because the resource-pack listener is missing")
ia_constructor_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/ItemsAdderConstructorPolicy.java"
ia_constructor_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/ItemsAdderConstructorPolicyTest.java"
check(ia_constructor_policy.is_file() and ia_constructor_test.is_file()
      and "TITLE_AND_TEXTURE_ARRAY_OFFSETS" in ia_constructor_policy.read_text(encoding="utf-8")
      and "itemsadder-title-offset" in manager and "itemsadder-texture-offset" in manager,
      "ItemsAdder GUI must support current offset-aware constructor signatures and have regression tests")
check(config.get("settings", {}).get("itemsadder-title-offset") == 0
      and config.get("settings", {}).get("itemsadder-texture-offset") == 0,
      "ItemsAdder title/texture offsets must be explicit and safe by default")
addon_config_path = ROOT / "itemsadder-addon/contents/warriorland_unlocks/config.yml"
addon_image_path = ROOT / "itemsadder-addon/contents/warriorland_unlocks/resourcepack/assets/warriorland_unlocks/textures/font/command_menu_background.png"
addon_readme_path = ROOT / "itemsadder-addon/README.md"
check(addon_config_path.is_file() and addon_image_path.is_file() and addon_readme_path.is_file(),
      "optional ItemsAdder GUI addon, config, texture, and install readme must be included")
if addon_config_path.is_file():
    try:
        ia_config = yaml.safe_load(addon_config_path.read_text(encoding="utf-8"))
        check(ia_config.get("info", {}).get("namespace") == "warriorland_unlocks",
              "ItemsAdder addon namespace must be warriorland_unlocks")
        glyph = ia_config.get("font_images", {}).get("command_menu_background", {})
        check(glyph.get("path") == "font/command_menu_background.png"
              and glyph.get("scale_ratio") == 222 and glyph.get("y_position") == 222,
              "ItemsAdder background glyph configuration must match the generated 176x222 image")
    except Exception as exc:
        errors.append(f"ItemsAdder addon config invalid: {exc}")
if addon_image_path.is_file():
    try:
        from PIL import Image
        with Image.open(addon_image_path) as ia_image:
            check(ia_image.size == (176,222), "ItemsAdder GUI font image must be 176x222 and below Minecraft's 256px limit")
            check(ia_image.mode == "RGBA", "ItemsAdder GUI font image needs transparency")
            alpha = ia_image.getchannel("A")
            check(alpha.getextrema()[0] == 0 and alpha.getextrema()[1] == 255,
                  "ItemsAdder GUI font image must provide transparent slot windows and opaque frame pixels")
    except Exception as exc:
        errors.append(f"ItemsAdder GUI background texture invalid: {exc}")
icon_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/ResourcePackIconPolicy.java"
icon_policy_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/ResourcePackIconPolicyTest.java"
check(icon_policy.is_file() and icon_policy_test.is_file(),
      "resource-pack custom icons must have a tested safe fallback policy")
if icon_policy.is_file():
    icon_policy_text = icon_policy.read_text(encoding="utf-8")
    check("allowUnverifiedManualPack" in icon_policy_text and "verifiedAutomaticLoad" in icon_policy_text,
          "resource-pack icon policy must distinguish verified automatic delivery and unverified manual install")
choice_policy = ROOT / "src/main/java/cz/warriorland/commandunlocks/TutorialChoiceMutationPolicy.java"
choice_policy_test = ROOT / "src/test/java/cz/warriorland/commandunlocks/TutorialChoiceMutationPolicyTest.java"
check(choice_policy.is_file() and choice_policy_test.is_file()
      and "TutorialChoiceMutationPolicy.persistOrRestore" in store,
      "tutorial preference must roll back in-memory state if durable save fails and have regression tests")
check('"settings.use-resource-pack-icons"' in plugin and '"settings.allow-unverified-manual-resource-pack-icons"' in plugin
      and '"settings.hud-notifications"' in plugin and '"settings.hud-notification-sounds"' in plugin and '"settings.hud-particles"' in plugin
      and 'diskConfig.set(settingPath, defaults.get(settingPath))' in plugin,
      "older installations must safely migrate optional resource-pack/HUD flags without overwriting explicit values")
check((ROOT / "src/main/java/cz/warriorland/commandunlocks/HudNotifier.java").is_file()
      and 'plugin.hud().purchaseSucceeded' in (ROOT / "src/main/java/cz/warriorland/commandunlocks/PurchaseService.java").read_text(encoding="utf-8")
      and 'plugin.hud().taskReward' in (ROOT / "src/main/java/cz/warriorland/commandunlocks/TaskService.java").read_text(encoding="utf-8")
      and 'Particle.TOTEM_OF_UNDYING' in (ROOT / "src/main/java/cz/warriorland/commandunlocks/HudNotifier.java").read_text(encoding="utf-8"),
      "server-only HUD must notify purchase and task-reward events with vanilla particles")
check("/prikazy tutorial reset" in (ROOT / "src/main/resources/config.yml").read_text(encoding="utf-8"),
      "help message must document tutorial preference reset")
check("MyCommand" in metadata.get("softdepend", []), "MyCommand must remain an optional server soft dependency")
check((ROOT / "src/main/java/cz/warriorland/commandunlocks/ResourcePackListener.java").is_file(), "optional resource-pack delivery listener must exist")
check((ROOT / "src/main/java/cz/warriorland/commandunlocks/ResourcePackPolicy.java").is_file(), "resource-pack URL/hash policy must exist")
check(config.get("settings", {}).get("resource-pack-url", "") == "", "resource-pack delivery must remain optional by default")
check(config.get("settings", {}).get("resource-pack-force", False) is False, "resource-pack force mode must be opt-in")
check(isinstance(config.get("settings", {}).get("resource-pack-prompt"), str) and len(config["settings"]["resource-pack-prompt"]) <= 180, "resource-pack prompt must be a short configurable plain-text string")
resource_listener = (ROOT / "src/main/java/cz/warriorland/commandunlocks/ResourcePackListener.java").read_text(encoding="utf-8")
resource_policy = (ROOT / "src/main/java/cz/warriorland/commandunlocks/ResourcePackPolicy.java").read_text(encoding="utf-8")
check("ResourcePackIconPolicy.canUseCustomIcons" in resource_listener,
      "custom models must use the tested safe fallback policy when no pack URL is configured")
check("SUCCESSFULLY_LOADED" in resource_listener and "event.getID()" in resource_listener,
      "pack listener must track only the configured resource pack UUID after a successful client load")
check("DISCARDED" in resource_listener, "pack listener must restore vanilla fallback when the client discards the pack")
check("addResourcePack(requestId, url" in resource_listener and "safePrompt(promptText)" in resource_listener and "onConfigurationReloaded" in resource_listener,
      "pack delivery should add (not replace) the pack, use a stable UUID and show a plain-text acceptance prompt")
check("removeResourcePack(previousRequestId)" in resource_listener and "offerConfiguredPack(online)" in resource_listener,
      "a changed pack config must remove only the old WarriorLand pack and re-offer the new one online")
check((ROOT / "src/main/java/cz/warriorland/commandunlocks/ResourcePackReloadPolicy.java").is_file()
      and (ROOT / "src/test/java/cz/warriorland/commandunlocks/ResourcePackReloadPolicyTest.java").is_file(),
      "resource-pack reload, stale ID cleanup and force-mode re-offer rules must have focused unit tests")
check("ResourcePackReloadPolicy.shouldOfferToPlayer" in resource_listener and "force != plugin.getConfig().getBoolean" in resource_listener,
      "reload policy must not send a stale delayed URL or force mode and must skip already-loaded players")
check("boolean forceModeChanged = previousForce != nextForce" in resource_listener and "ResourcePackReloadPolicy.shouldOfferToPlayer" in resource_listener,
      "changing force mode should re-offer only to players who have not confirmed the current pack")
check("!requestId.equals(configuredRequestId())" in resource_listener,
      "delayed join delivery must not send a stale URL/hash after configuration reload")
check("removeResourcePacks()" not in resource_listener and "clearResourcePacks()" not in resource_listener,
      "resource-pack reload must not clear unrelated packs sent by other plugins")
check("character > 0x7f" in resource_policy and "requestId(String rawUrl, String rawSha1)" in resource_policy,
      "resource-pack policy must reject non-ASCII URLs and create a stable pack request ID")
check(config.get("settings", {}).get("hud-task-progress") is True and "plugin.hud().taskProgress" in (ROOT / "src/main/java/cz/warriorland/commandunlocks/TaskService.java").read_text(encoding="utf-8"),
      "rate-limited action-bar task progress must be enabled and wired to task progress events")
check((ROOT / "src/main/java/cz/warriorland/commandunlocks/HudProgressPolicy.java").is_file()
      and (ROOT / "src/test/java/cz/warriorland/commandunlocks/HudProgressPolicyTest.java").is_file(),
      "HUD progress throttling and progress-bar policy must have focused unit tests")
check("1.15.8" in (ROOT / "README.md").read_text(encoding="utf-8"), "README must document current release")
check(not any((ROOT / p).exists() for p in ["scripts/validate_client_ui.py", "scripts/validate_client_layout_geometry.py", "scripts/validate_tutorial.py"]),
      "outdated client-mod validators must not ship")
preview_script = ROOT / "scripts/render_source_preview.py"
preview_image = ROOT / "docs/source-preview.png"
preview_detail = ROOT / "docs/source-preview-detail.png"
preview_task = ROOT / "docs/source-preview-task-progress.png"
preview_background = ROOT / "docs/preview-world-background.jpg"
check(preview_script.is_file(), "source-based GUI preview generator must ship")
check(preview_background.is_file(), "preview background must be bundled so CI output is reproducible")
check(preview_detail.is_file(), "zoomed source-based GUI preview must ship")
check(preview_task.is_file(), "task-progress tooltip preview must ship")
check(preview_script.is_file() and "MenuLayout.java" in preview_script.read_text(encoding="utf-8")
      and "src/main/resources/config.yml" in preview_script.read_text(encoding="utf-8")
      and "textures/item/command_icons" in preview_script.read_text(encoding="utf-8"),
      "GUI preview must use source configuration, real slot map and actual resource-pack icons")
try:
    from PIL import Image
    with Image.open(preview_image) as preview:
        check(preview.size == (1920, 1080), "source-based GUI preview must be 1920x1080")
        check(preview.mode in ("RGB", "RGBA"), "source-based GUI preview must be RGB/RGBA")
except Exception as exc:
    errors.append(f"source-based GUI preview missing or invalid: {exc}")

# Validate the standalone 1.21.10 resource pack's model references against the default catalog.
pack = ROOT / "resource-pack"
try:
    packmeta = json.loads((pack / "pack.mcmeta").read_text(encoding="utf-8"))
    packdata = packmeta["pack"]
    check(packdata.get("min_format") == [69, 0] and packdata.get("max_format") == [69, 0], "resource pack must target Java 1.21.10 format 69.0")
except Exception as exc:
    errors.append(f"resource-pack pack.mcmeta invalid: {exc}")
try:
    from PIL import Image
    pack_icon = pack / "pack.png"
    with Image.open(pack_icon) as icon:
        check(icon.size == (128, 128), "resource-pack pack.png should be a crisp 128x128 icon")
        check(icon.mode in ("RGBA", "RGB"), "resource-pack pack.png must be RGB/RGBA")
except Exception as exc:
    errors.append(f"resource-pack pack.png invalid: {exc}")
try:
    unlocks = config["unlocks"]
    check(len(unlocks) == 75, f"resource-pack mapping expected 75 unlocks, found {len(unlocks)}")
    for raw_id in unlocks:
        key = re.sub(r"[^a-z0-9_.-]+", "_", str(raw_id).lower()).strip("_") or "unknown"
        item_model = pack / f"assets/warriorland/items/command_icons/{key}.json"
        model = pack / f"assets/warriorland/models/item/command_icons/{key}.json"
        texture = pack / f"assets/warriorland/textures/item/command_icons/{key}.png"
        check(item_model.is_file(), f"missing resource-pack item model for {raw_id}: {item_model.relative_to(ROOT)}")
        check(model.is_file(), f"missing resource-pack model for {raw_id}: {model.relative_to(ROOT)}")
        check(texture.is_file() and texture.stat().st_size > 0, f"missing/empty icon texture for {raw_id}")
        if texture.exists():
            try:
                from PIL import Image
                with Image.open(texture) as icon_image:
                    check(icon_image.size == (64, 64), f"icon texture for {raw_id} must be 64x64")
                    check(icon_image.mode in ("RGBA", "RGB"), f"icon texture for {raw_id} must be RGB/RGBA")
            except Exception as exc:
                errors.append(f"icon texture for {raw_id} cannot be decoded: {exc}")
        if item_model.exists():
            try:
                item_def = json.loads(item_model.read_text(encoding="utf-8"))
                check(item_def["model"]["model"] == f"warriorland:item/command_icons/{key}", f"wrong item model ref for {raw_id}")
            except Exception as exc:
                errors.append(f"item model JSON invalid for {raw_id}: {exc}")
        if model.exists():
            try:
                model_def = json.loads(model.read_text(encoding="utf-8"))
                check(model_def["textures"]["layer0"] == f"warriorland:item/command_icons/{key}", f"wrong texture ref for {raw_id}")
            except Exception as exc:
                errors.append(f"model JSON invalid for {raw_id}: {exc}")
        for state in ("unlocked", "ready", "insufficient", "locked", "unavailable"):
            state_item = pack / f"assets/warriorland/items/command_icons/{key}_{state}.json"
            state_model = pack / f"assets/warriorland/models/item/command_icons/{key}_{state}.json"
            state_texture = pack / f"assets/warriorland/textures/item/command_icons/{key}_{state}.png"
            check(state_item.is_file() and state_model.is_file() and state_texture.is_file(),
                  f"missing state-aware icon variant {key}_{state}")
            if state_item.exists():
                try:
                    state_def = json.loads(state_item.read_text(encoding="utf-8"))
                    check(state_def["model"]["model"] == f"warriorland:item/command_icons/{key}_{state}",
                          f"wrong item model ref for state {key}_{state}")
                except Exception as exc:
                    errors.append(f"state item model JSON invalid for {key}_{state}: {exc}")
except Exception as exc:
    errors.append(f"could not validate unlock map/resource pack: {exc}")

if errors:
    print(f"FAIL: {len(errors)} issue(s)")
    for err in errors: print(f" - {err}")
    sys.exit(1)
print("PASS Paper-only release: no ClientMod, Fabric bridge, or client plugin-message channels")
print("PASS optional ItemsAdder GUI skin: namespace, 176x222 transparent font image, API fallback and disabled-by-default config")
print("PASS resource-pack delivery: URL validation, request UUID matching, prompt text and safe icon fallback")
print("PASS HUD progress: rate-limited action-bar updates are wired to actual task progress")
print("PASS tutorial: first-run prompt, persistent per-UUID choice, six Paper inventory pages, replay/reset command")
print("PASS resource pack: Java 1.21.10 format 69.0; all base icons and five state-aware variants per unlock are present")
