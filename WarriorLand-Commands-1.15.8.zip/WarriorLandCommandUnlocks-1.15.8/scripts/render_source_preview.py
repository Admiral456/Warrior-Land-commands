#!/usr/bin/env python3
"""Render a source-faithful explanatory preview using the real config, slot map and RP textures.

This is deliberately an approximation of the ordinary Paper inventory client render, not a claim
that the program has been captured from a live Minecraft session. Item names/lore only appear in a
vanilla tooltip when hovered; the preview demonstrates that limitation rather than inventing a mod UI.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any
import yaml
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "src/main/resources/config.yml"
LAYOUT = ROOT / "src/main/java/cz/warriorland/commandunlocks/MenuLayout.java"
PACK_ROOT = ROOT / "resource-pack/assets/warriorland/textures/item/command_icons"
IA_BG = ROOT / "itemsadder-addon/contents/warriorland_unlocks/resourcepack/assets/warriorland_unlocks/textures/font/command_menu_background.png"
OUT = ROOT / "docs/source-preview.png"

CANVAS_W, CANVAS_H = 1920, 1080
SCALE = 3  # representative GUI scale; container slots render as 48px icons
PANEL_W, PANEL_H = 176 * SCALE, 222 * SCALE
PANEL_X, PANEL_Y = (CANVAS_W - PANEL_W) // 2, (CANVAS_H - PANEL_H) // 2
BG_PATH = ROOT / "docs/preview-world-background.jpg"

FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"

def font(size: int, bold: bool = False, mono: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_MONO if mono else (FONT_BOLD if bold else FONT_REG), size)


def parse_array(source: str, name: str) -> list[int]:
    m = re.search(rf"{name}\s*=\s*\{{([^}}]*)\}}", source, re.S)
    if not m:
        raise ValueError(f"Missing {name} in MenuLayout.java")
    return [int(v) for v in re.findall(r"-?\d+", m.group(1))]


def color(hex_color: str) -> tuple[int, int, int, int]:
    s = hex_color.lstrip("#")
    if len(s) == 6:
        return tuple(int(s[i:i+2], 16) for i in (0, 2, 4)) + (255,)
    return tuple(int(s[i:i+2], 16) for i in (0, 2, 4, 6))


def get_icon(identifier: str, state: str | None = None) -> Image.Image | None:
    stem = identifier.lower().replace("-", "_")
    candidates = []
    if state:
        candidates.append(PACK_ROOT / f"{stem}_{state}.png")
    candidates.append(PACK_ROOT / f"{stem}.png")
    for path in candidates:
        if path.exists():
            with Image.open(path) as icon:
                return icon.convert("RGBA")
    return None


def make_vanilla_icon(kind: str, size: int = 48) -> Image.Image:
    """Simple pixel-style approximations for built-in item materials not in this RP pack."""
    s = 16
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # 16x16 pixel icons in the style of common Minecraft inventory materials.
    if kind in {"GOLD_INGOT", "GOLD", "COIN"}:
        d.rectangle((3, 5, 12, 10), fill=(220, 157, 25, 255), outline=(255, 219, 77, 255))
        d.line((4, 6, 11, 6), fill=(255, 243, 135, 255))
        d.rectangle((6, 7, 10, 9), fill=(255, 202, 35, 255))
    elif kind in {"EMERALD", "GREEN_GEM"}:
        d.polygon([(8,1),(13,4),(15,8),(8,15),(1,8),(3,4)], fill=(15, 177, 91, 255), outline=(111, 255, 171, 255))
        d.line((4,4,8,2), fill=(190,255,206,255))
    elif kind in {"BARRIER", "ERROR"}:
        d.ellipse((1,1,14,14), fill=(205, 27, 52, 255), outline=(255, 116, 128, 255))
        d.line((4,4,11,11), fill=(255,255,255,255), width=2)
        d.line((11,4,4,11), fill=(255,255,255,255), width=2)
    elif kind in {"BOOK", "WRITABLE_BOOK", "PAPER"}:
        d.polygon([(2,3),(7,4),(7,13),(2,12)], fill=(230,220,180,255), outline=(255,255,245,255))
        d.polygon([(8,4),(13,3),(13,12),(8,13)], fill=(195,177,133,255), outline=(255,255,245,255))
        d.line((7,4,7,13), fill=(80,52,29,255))
        d.line((3,6,6,7), fill=(97,68,36,255))
    elif kind in {"COMPASS", "NETHER_STAR", "END_CRYSTAL"}:
        d.ellipse((2,2,13,13), fill=(27, 38, 66, 255), outline=(180, 176, 224, 255))
        d.polygon([(9,3),(7,8),(4,12),(9,9)], fill=(239, 65, 77, 255), outline=(255,255,255,255))
        d.line((8,8,12,4), fill=(85, 198, 255,255))
    elif kind in {"CHAIN", "NAME_TAG", "LINK"}:
        d.ellipse((1,4,8,11), outline=(174, 172, 240, 255), width=2)
        d.ellipse((7,2,14,9), outline=(174, 172, 240, 255), width=2)
        d.line((5,8,10,5), fill=(210,204,255,255), width=2)
    elif kind in {"SPYGLASS", "SEARCH"}:
        d.ellipse((2,1,10,9), outline=(182, 183, 228, 255), width=2)
        d.line((9,8,14,14), fill=(211, 159, 94, 255), width=3)
    elif kind in {"HOPPER", "SORT"}:
        d.polygon([(1,2),(14,2),(10,7),(10,10),(6,13),(6,7)], fill=(86, 92, 114, 255), outline=(180, 180, 211, 255))
    elif kind in {"COMMAND_BLOCK", "COMMAND"}:
        d.rectangle((2,2,13,13), fill=(102, 66, 145, 255), outline=(218, 135, 255, 255))
        d.rectangle((4,4,11,11), fill=(40, 27, 71, 255), outline=(150, 92, 208, 255))
        d.line((5,6,8,8), fill=(255,255,255,255), width=1)
        d.line((8,8,5,10), fill=(255,255,255,255), width=1)
        d.line((8,10,11,10), fill=(255,255,255,255), width=1)
    elif kind in {"HUD", "BEACON"}:
        d.rectangle((2,3,13,12), fill=(28, 98, 98, 255), outline=(111, 255, 245, 255))
        d.rectangle((4,5,11,10), fill=(50, 194, 202, 230))
        d.polygon([(6,3),(8,0),(10,3)], fill=(225, 150, 255, 255))
    elif kind in {"ARROW_LEFT", "ARROW_RIGHT", "ARROW"}:
        if kind == "ARROW_LEFT":
            d.polygon([(3,8),(9,2),(9,5),(14,5),(14,10),(9,10),(9,13)], fill=(229, 208, 255, 255))
        elif kind == "ARROW_RIGHT":
            d.polygon([(13,8),(7,2),(7,5),(2,5),(2,10),(7,10),(7,13)], fill=(229, 208, 255, 255))
        else:
            d.polygon([(3,8),(9,2),(9,5),(14,5),(14,10),(9,10),(9,13)], fill=(220,220,240,255))
    elif kind in {"PURPLE_PANE", "PURPLE_STAINED_GLASS_PANE"}:
        d.rectangle((1,1,14,14), fill=(69, 24, 126, 140), outline=(163, 83, 255, 245))
        d.line((2,2,13,13), fill=(193, 137, 255, 120))
    elif kind in {"GRAY_STAINED_GLASS_PANE", "BLACK_STAINED_GLASS_PANE", "BLUE_STAINED_GLASS_PANE"}:
        shade=(63,70,85,180) if kind.startswith("GRAY") else (23,20,40,180) if kind.startswith("BLACK") else (23,63,112,180)
        d.rectangle((1,1,14,14), fill=shade, outline=(107,111,143,230))
    elif kind in {"NETHER_STAR", "STAR"}:
        pts=[]
        for i in range(10):
            a=-math.pi/2+i*math.pi/5
            rad=7 if i%2==0 else 3
            pts.append((8+int(math.cos(a)*rad),8+int(math.sin(a)*rad)))
        d.polygon(pts, fill=(239,220,255,255), outline=(153,111,255,255))
        d.rectangle((7,7,8,8), fill=(255,255,255,255))
    elif kind in {"ENDER_PEARL", "ENDER_EYE"}:
        d.ellipse((2,1,13,14), fill=(20,142,133,255), outline=(86,255,222,255))
        d.ellipse((4,3,11,12), fill=(5,62,76,255), outline=(29,200,177,255))
        d.rectangle((5,4,7,5), fill=(157,255,235,255))
    elif kind == "OAK_FENCE_GATE":
        for xx in (3,6,9,12): d.rectangle((xx,2,xx+1,13), fill=(143,87,43,255), outline=(72,43,24,255))
        d.rectangle((2,4,13,6), fill=(194,137,72,255), outline=(78,48,24,255))
        d.rectangle((2,9,13,11), fill=(194,137,72,255), outline=(78,48,24,255))
    elif kind == "ENDER_CHEST":
        d.rectangle((1,4,14,13), fill=(18,46,57,255), outline=(76,226,217,255))
        d.rectangle((3,2,12,5), fill=(12,74,83,255), outline=(57,199,200,255))
        d.rectangle((6,7,10,10), fill=(3,17,25,255), outline=(55,210,186,255))
        d.rectangle((11,7,12,9), fill=(220,187,58,255))
    elif kind in {"LIME_DYE", "EMERALD_DYE", "GREEN_DYE"}:
        d.polygon([(5,1),(11,2),(14,7),(9,14),(4,12),(2,6)], fill=(61,220,84,255), outline=(173,255,145,255))
    elif kind in {"RED_DYE", "ORANGE_DYE", "YELLOW_DYE", "GRAY_DYE"}:
        cc={"RED_DYE":(211,45,65,255),"ORANGE_DYE":(236,142,48,255),"YELLOW_DYE":(248,205,57,255),"GRAY_DYE":(145,148,160,255)}[kind]
        d.polygon([(5,1),(11,2),(14,7),(9,14),(4,12),(2,6)], fill=cc, outline=(230,230,240,255))
    elif kind in {"IRON_PICKAXE", "PICKAXE"}:
        d.line((4,5,12,13), fill=(133,86,47,255), width=3)
        d.line((2,4,8,2,14,3,12,6,7,6), fill=(174,184,198,255), width=2)
    elif kind in {"MAP", "FILLED_MAP"}:
        d.polygon([(2,3),(6,2),(10,4),(14,2),(14,12),(10,14),(6,12),(2,14)], fill=(202,182,118,255), outline=(245,224,160,255))
        d.line((6,3,6,11), fill=(93,156,91,255), width=1); d.line((10,5,10,13), fill=(71,143,201,255), width=1)
    elif kind in {"LANTERN", "BEACON"}:
        d.rectangle((4,4,12,13), fill=(156,93,36,255), outline=(255,175,70,255))
        d.rectangle((6,6,10,11), fill=(255,202,74,255), outline=(255,242,146,255))
        d.rectangle((5,2,11,3), fill=(80,74,80,255)); d.line((8,0,8,2),fill=(167,151,172,255))
    elif kind == "BARRIER":
        d.ellipse((1,1,14,14), fill=(210,35,53,255), outline=(255,135,145,255))
        d.line((4,4,11,11),fill=(255,255,255,255),width=2); d.line((11,4,4,11),fill=(255,255,255,255),width=2)
    elif kind == "REDSTONE_TORCH":
        d.line((8,5,8,14), fill=(139,86,44,255), width=3); d.polygon([(8,0),(12,3),(9,6),(5,4)],fill=(242,49,55,255),outline=(255,155,120,255))
    else:
        # Generic blue-purple utility icon.
        d.rectangle((3,3,12,12), fill=(42, 50, 88, 255), outline=(145, 121, 255, 255))
        d.rectangle((6,6,9,9), fill=(215, 185, 255, 255))
    return im.resize((size, size), Image.Resampling.NEAREST)


def draw_slot_frame(canvas: Image.Image, x: int, y: int, scale: int, selected: bool = False, tint: str = "vanilla") -> None:
    d = ImageDraw.Draw(canvas, "RGBA")
    w = 18 * scale
    h = 18 * scale
    if tint == "purple":
        base, light, dark = (29,18,58,255), (139,73,226,255), (5,5,17,255)
    elif tint == "blue":
        base, light, dark = (12,23,51,255), (63,113,185,255), (3,7,20,255)
    else:
        base, light, dark = (41,42,47,255), (102,103,111,255), (12,13,17,255)
    d.rectangle((x,y,x+w-1,y+h-1), fill=base)
    d.line((x,y,x+w-1,y), fill=light, width=max(1,scale//3))
    d.line((x,y,x,y+h-1), fill=light, width=max(1,scale//3))
    d.line((x,y+h-1,x+w-1,y+h-1), fill=dark, width=max(1,scale//3))
    d.line((x+w-1,y,x+w-1,y+h-1), fill=dark, width=max(1,scale//3))
    d.rectangle((x+scale,y+scale,x+w-scale-1,y+h-scale-1), fill=(24,25,31,255))
    if selected:
        # Represent the source code's enchant-glint for selected/unlocked cards as a static violet rim.
        d.rectangle((x-2,y-2,x+w+1,y+h+1), outline=(193,92,255,220), width=max(1,scale//2))
        d.rectangle((x-4,y-4,x+w+3,y+h+3), outline=(138,60,255,90), width=max(1,scale//2))


def draw_item(canvas: Image.Image, item_id: str, x: int, y: int, size: int, state: str | None = None, glow: bool = False) -> None:
    img = get_icon(item_id, state)
    if img is None:
        img = make_vanilla_icon(item_id.upper(), size)
    else:
        img = img.resize((size, size), Image.Resampling.NEAREST)
    if glow:
        halo = Image.new("RGBA", (size+24, size+24), (0,0,0,0))
        hd = ImageDraw.Draw(halo)
        hd.rectangle((6,6,size+17,size+17), outline=(194,82,255,120), width=6)
        halo = halo.filter(ImageFilter.GaussianBlur(8))
        canvas.alpha_composite(halo, (x-12, y-12))
    canvas.alpha_composite(img, (x, y))


def draw_centered(draw: ImageDraw.ImageDraw, xy: tuple[int,int], text: str, f: ImageFont.FreeTypeFont, fill: tuple[int,int,int,int]) -> None:
    x,y=xy
    bbox=draw.textbbox((0,0), text, font=f)
    draw.text((x-(bbox[2]-bbox[0])//2, y-(bbox[3]-bbox[1])//2), text, font=f, fill=fill, stroke_width=0)


def draw_tooltip(canvas: Image.Image, x: int, y: int, width: int, lines: list[tuple[str, tuple[int,int,int,int], bool]], max_h: int = 330) -> None:
    f_reg=font(19)
    f_bold=font(20, True)
    line_h=25
    height=min(max_h, 14 + line_h*len(lines) + 12)
    x=max(14,min(x,CANVAS_W-width-14))
    y=max(14,min(y,CANVAS_H-height-14))
    d=ImageDraw.Draw(canvas,"RGBA")
    # Native tooltip approximation: black translucent card with double gold-brown outline.
    d.rounded_rectangle((x+3,y+4,x+width+3,y+height+4), radius=5, fill=(0,0,0,90))
    d.rounded_rectangle((x,y,x+width,y+height), radius=4, fill=(13,6,18,247), outline=(39,24,33,255), width=3)
    d.rectangle((x+3,y+3,x+width-3,y+height-3), outline=(89,67,68,220), width=1)
    yy=y+9
    for txt,col,bold in lines:
        f=f_bold if bold else f_reg
        if txt:
            d.text((x+12,yy),txt,font=f,fill=col)
        yy += line_h


def main() -> None:
    cfg=yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    source=LAYOUT.read_text(encoding="utf-8")
    layout={name:parse_array(source,name) for name in ("CARD_SLOTS","QUICK_INFO_SLOTS","DETAIL_SLOTS","SEPARATOR_SLOTS","CATEGORY_SLOTS","HEADER_SLOTS","FOOTER_SLOTS")}
    unlocks=cfg["unlocks"]
    categories=cfg["categories"]
    assert len(unlocks)==75, f"Expected 75 configured unlocks, got {len(unlocks)}"
    assert len(layout["CARD_SLOTS"])==12
    assert set(sum(layout.values(),[]))==set(range(54))
    assert IA_BG.exists(), "ItemsAdder background not found; run generate_itemsadder_gui_background.py"

    # An explicit sample state only for the visualization; the real player's state is loaded at runtime.
    sample_states={
        "tpa":"unlocked", "tpaccept":"unlocked", "tpdeny":"locked", "home":"locked",
        "sethome":"ready", "warp":"locked", "balance":"ready", "enderchest":"locked",
        "chatcolour":"unavailable", "nickcolour":"insufficient", "workbench":"unlocked", "ignore":"unlocked"
    }
    selected_id="chatcolour"
    selected=unlocks[selected_id]
    sample_balance=250
    # Build a dimmed in-game background, not a fake live screenshot.
    if BG_PATH.exists():
        with Image.open(BG_PATH) as bg:
            bg=bg.convert("RGB").resize((CANVAS_W,CANVAS_H),Image.Resampling.LANCZOS)
        bg=bg.filter(ImageFilter.GaussianBlur(2.3)).convert("RGBA")
        tint=Image.new("RGBA",bg.size,(0,0,13,98))
        bg=Image.alpha_composite(bg,tint)
    else:
        bg=Image.new("RGBA",(CANVAS_W,CANVAS_H),(14,10,28,255))
    canvas=bg
    d=ImageDraw.Draw(canvas,"RGBA")
    # Mild vignette to match an opened vanilla inventory over the 3D world.
    vignette=Image.new("RGBA",canvas.size,(0,0,0,0)); vd=ImageDraw.Draw(vignette)
    vd.rectangle((0,0,CANVAS_W,CANVAS_H),fill=(0,0,0,55))
    canvas=Image.alpha_composite(canvas,vignette)

    # Real 176x222 ItemsAdder font image background, scaled to a representative GUI scale.
    with Image.open(IA_BG) as tex:
        texture=tex.convert("RGBA").resize((PANEL_W,PANEL_H),Image.Resampling.NEAREST)
    canvas.alpha_composite(texture,(PANEL_X,PANEL_Y))
    d=ImageDraw.Draw(canvas,"RGBA")
    # Add restrained outer glow around the textured inventory panel.
    glow=Image.new("RGBA",(PANEL_W+56,PANEL_H+56),(0,0,0,0)); gd=ImageDraw.Draw(glow)
    gd.rounded_rectangle((18,18,PANEL_W+37,PANEL_H+37),radius=16,outline=(151,55,255,150),width=5)
    glow=glow.filter(ImageFilter.GaussianBlur(13))
    canvas.alpha_composite(glow,(PANEL_X-28,PANEL_Y-28))
    canvas.alpha_composite(texture,(PANEL_X,PANEL_Y))
    d=ImageDraw.Draw(canvas,"RGBA")

    # Title from settings.menu-title; colors are approximated but title content is real.
    title="✦ WARRIORLAND  »  PŘÍKAZY"
    title_font=font(23,True)
    d.text((PANEL_X+18,PANEL_Y+7),title,font=title_font,fill=(228,208,255,255),stroke_width=1,stroke_fill=(51,21,90,255))

    # Actual category IDs/slots from config.yml and MenuLayout.java.
    # Use actual category Material values from config.yml; only command cards use custom RP models.
    category_kind={category_id: str(category.get("icon", "ENDER_EYE")).upper() for category_id, category in categories.items()}
    for category_id, category in categories.items():
        slot=int(category["slot"])
        r,c=divmod(slot,9)
        sx=PANEL_X+(7+c*18)*SCALE; sy=PANEL_Y+(17+r*18)*SCALE
        selected_category=(category_id=="all")
        draw_slot_frame(canvas,sx,sy,SCALE,selected=selected_category,tint="purple" if selected_category else "vanilla")
        draw_item(canvas, category_kind.get(category_id, "ENDER_EYE"), sx+3, sy+3, 48, glow=selected_category)

    # Header actions from MenuManager.renderHeader; all slots match source code.
    header_items={
        1:("COMMAND_BLOCK",None),2:("SPYGLASS",None),3:("HOPPER",None),4:("COMPASS",None),
        5:("BOOK",None),6:("GOLD_INGOT",None),7:(selected_id,"unavailable"),8:("COMMAND_BLOCK",None)
    }
    for slot,(kind,asset) in header_items.items():
        r,c=divmod(slot,9); sx=PANEL_X+(7+c*18)*SCALE; sy=PANEL_Y+(17+r*18)*SCALE
        tint="purple" if slot in (5,7) else "vanilla"
        selected_slot=(slot==7)
        draw_slot_frame(canvas,sx,sy,SCALE,selected=selected_slot,tint=tint)
        if asset:
            draw_item(canvas,asset,sx+3,sy+3,48,glow=selected_slot)
        else:
            draw_item(canvas,kind,sx+3,sy+3,48,glow=(slot==6))

    # The first page is exactly the 12 definitions in config.yml order (default sort mode).
    definitions=list(unlocks.items())[:len(layout["CARD_SLOTS"])]
    if len(definitions)!=12:
        raise AssertionError("Default config order must yield 12 first-page cards")
    card_slots=layout["CARD_SLOTS"]
    for index, (unlock_id, definition) in enumerate(definitions):
        slot=card_slots[index]; r,c=divmod(slot,9)
        sx=PANEL_X+(7+c*18)*SCALE; sy=PANEL_Y+(17+r*18)*SCALE
        state=sample_states.get(unlock_id,"locked")
        is_selected=unlock_id==selected_id
        draw_slot_frame(canvas,sx,sy,SCALE,selected=is_selected,tint="purple" if is_selected else ("blue" if state=="unlocked" else "vanilla"))
        draw_item(canvas,unlock_id,sx+3,sy+3,48,state=state,glow=(is_selected or state=="unlocked" or state=="ready"))

    # Right detail panel from renderDetails: these are separate native slots whose lore appears on hover.
    detail_items={
        15:("BARRIER",None),16:("CHAIN",None),17:("COMPASS",None),
        24:("BOOK",None),25:("WRITABLE_BOOK",None),26:("MAP",None),
        33:("GOLD_INGOT",None),34:("EMERALD",None),35:("CHAIN",None),
        42:("BARRIER",None),43:("BARRIER",None),44:("PURPLE_PANE",None)
    }
    for slot,(kind,asset) in detail_items.items():
        r,c=divmod(slot,9); sx=PANEL_X+(7+c*18)*SCALE; sy=PANEL_Y+(17+r*18)*SCALE
        tint="purple" if c>=6 else "vanilla"
        draw_slot_frame(canvas,sx,sy,SCALE,tint=tint)
        draw_item(canvas,asset or kind,sx+3,sy+3,48,glow=(slot==43 and selected_id=="chatcolour"))

    # Four quick guide cells plus footer/navigation. Names/lore are native hover tooltips.
    quick={38:"IRON_PICKAXE",39:"GOLD_INGOT",40:"EMERALD",41:"BEACON"}
    for slot,icon_key in quick.items():
        r,c=divmod(slot,9); sx=PANEL_X+(7+c*18)*SCALE; sy=PANEL_Y+(17+r*18)*SCALE
        draw_slot_frame(canvas,sx,sy,SCALE,tint="blue" if slot==41 else "vanilla")
        draw_item(canvas,icon_key,sx+3,sy+3,48,glow=(slot==41))
    footer={45:"GOLD_INGOT",46:"ARROW_LEFT",47:"COMPASS",48:"PAPER",49:"NAME_TAG",50:"ARROW_RIGHT",51:"BOOK",52:"LANTERN",53:"BARRIER"}
    for slot,kind in footer.items():
        r,c=divmod(slot,9); sx=PANEL_X+(7+c*18)*SCALE; sy=PANEL_Y+(17+r*18)*SCALE
        tint="purple" if slot in (46,50) else "vanilla"
        draw_slot_frame(canvas,sx,sy,SCALE,tint=tint)
        draw_item(canvas,kind,sx+3,sy+3,48,glow=(slot in (46,50)))

    # Vanilla player inventory below the 54 top slots; it remains visible in a chest inventory.
    for r, logical_y in enumerate((139,157,175,197)):
        for c in range(9):
            sx=PANEL_X+(7+c*18)*SCALE
            sy=PANEL_Y+logical_y*SCALE
            draw_slot_frame(canvas,sx,sy,SCALE,tint="vanilla")

    # Keep a clean copy so a second preview can show the task-tooltip state instead of the card tooltip.
    canvas_without_tooltip = canvas.copy()
    # Example tooltip for the selected /chatcolour card, generated from actual config values.
    # Progress 0/12 and 250 PP are explicitly example values, not claims about a live player.
    cost=selected["cost"]
    alias_list=selected.get("commands",[])
    task=selected.get("tasks",[{}])[0]
    task_amount=task.get("amount",0)
    task_description=task.get("description","")
    desc=selected.get("description","")
    # The tooltip wraps to a standard short item-lore width, matching MenuManager's 34 chars approx.
    wrap=lambda text, n=39: [text[i:i+n] for i in range(0,len(text),n)] if len(text)>n else [text]
    tooltip_lines=[
        ("[NEDOSTUPNÉ] /chatcolour",(255,85,85,255),True),
        (selected.get("name","Barevný chat"),(245,245,245,255),False),
    ]
    for line in wrap(desc,42): tooltip_lines.append((line,(170,170,170,255),False))
    tooltip_lines += [("",(170,170,170,255),False),(f"Cena: {cost} PP",(255,214,85,255),False),
                      ("Úkoly: 0/1 splněno",(190,190,190,255),False),
                      ("Chybí plugin:",(255,85,85,255),False),("- ChatColor2",(255,85,85,255),False)]
    if len(alias_list)>1: tooltip_lines.append((f"Aliasů: {len(alias_list)-1}",(210,145,255,255),False))
    tooltip_lines += [("",(180,180,180,255),False),("Vybráno — detail vpravo",(210,145,255,255),False)]
    # Place tooltip beside the hovered chatcolour card as Minecraft does; it can cover nearby slots.
    chat_slot=card_slots[[key for key,_ in definitions].index(selected_id)]
    rr,cc=divmod(chat_slot,9)
    hover_x=PANEL_X+(7+cc*18)*SCALE+50
    hover_y=PANEL_Y+(17+rr*18)*SCALE+32
    draw_tooltip(canvas,hover_x,hover_y,390,tooltip_lines)
    # Mouse cursor near the selected card.
    mx=PANEL_X+(7+cc*18)*SCALE+43; my=PANEL_Y+(17+rr*18)*SCALE+35
    d=ImageDraw.Draw(canvas,"RGBA")
    d.polygon([(mx,my),(mx+2,my+27),(mx+8,my+20),(mx+15,my+32),(mx+20,my+29),(mx+13,my+17),(mx+22,my+17)], fill=(245,245,245,255), outline=(10,10,15,255))

    # Explanatory caption sits outside the inventory so the image can't be mistaken for a live capture.
    d=ImageDraw.Draw(canvas,"RGBA")
    caption="NÁHLED KÓDU + RP  •  ITEMSADDER SKIN ZAPNUTÝ  •  54 SLOTŮ  •  NEŽIVÝ NÁHLED"
    cap_font=font(18,True)
    cap_w=d.textbbox((0,0),caption,font=cap_font)[2]
    cx=(CANVAS_W-cap_w)//2
    d.rounded_rectangle((cx-18,CANVAS_H-60,cx+cap_w+18,CANVAS_H-20),radius=9,fill=(7,5,20,220),outline=(147,68,245,220),width=2)
    d.text((cx,CANVAS_H-52),caption,font=cap_font,fill=(232,219,255,255))
    OUT.parent.mkdir(parents=True,exist_ok=True)
    canvas.convert("RGB").save(OUT,quality=95,optimize=True)
    # A separate zoom crop makes the real slot map and actual pack icons easier to inspect.
    zoom_path = ROOT / "docs/source-preview-detail.png"
    crop_box = (max(0, PANEL_X-18), max(0, PANEL_Y-18), min(CANVAS_W, PANEL_X+PANEL_W+70), min(CANVAS_H-58, PANEL_Y+PANEL_H+18))
    crop = canvas.crop(crop_box).convert("RGB")
    crop = crop.resize((int(crop.width*1.45), int(crop.height*1.45)), Image.Resampling.LANCZOS)
    crop.save(zoom_path, quality=95, optimize=True)
    # Second source-faithful state: hover the real slot 25 (WRITABLE_BOOK) to show actual task lore.
    task_canvas = canvas_without_tooltip.copy()
    task_slot = 25
    tr, tc = divmod(task_slot, 9)
    task_sx = PANEL_X + (7 + tc*18)*SCALE
    task_sy = PANEL_Y + (17 + tr*18)*SCALE
    task_mx, task_my = task_sx + 43, task_sy + 35
    task_lines = [
        ("ÚKOLY A POSTUP", (231,210,255,255), True),
        ("POŽADOVANÉ ÚKOLY", (210,145,255,255), True),
        (task_description, (235,235,235,255), False),
        ("----------  0%", (255,214,85,255), False),
        (f"0 / {task_amount}", (245,245,245,255), False),
        ("Postup se ukládá podle UUID hráče.", (165,165,175,255), False),
    ]
    draw_tooltip(task_canvas, task_mx+18, task_my+18, 390, task_lines, max_h=260)
    td = ImageDraw.Draw(task_canvas, "RGBA")
    td.polygon([(task_mx,task_my),(task_mx+2,task_my+27),(task_mx+8,task_my+20),(task_mx+15,task_my+32),(task_mx+20,task_my+29),(task_mx+13,task_my+17),(task_mx+22,task_my+17)], fill=(245,245,245,255), outline=(10,10,15,255))
    task_out = ROOT / "docs/source-preview-task-progress.png"
    task_canvas.convert("RGB").save(task_out, quality=95, optimize=True)
    print(f"PASS source-faithful GUI preview: {OUT.relative_to(ROOT)} ({CANVAS_W}x{CANVAS_H})")
    print(f"PASS zoomed source preview: {zoom_path.relative_to(ROOT)}")
    print(f"PASS task-progress tooltip preview: {task_out.relative_to(ROOT)}")
    print("NOTE: preview assumes settings.itemsadder-textured-gui=true, custom icon RP loaded, and an illustrative 250 PP demo account.")
    print("NOTE: live ownership/progress comes from players.yml and PlayerPoints; this is not a capture of a running client.")

if __name__ == "__main__":
    main()
