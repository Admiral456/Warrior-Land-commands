#!/usr/bin/env python3
"""Generate deterministic Minecraft-like 64px command icons for the optional resource pack."""
from __future__ import annotations
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import math

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "resource-pack/assets/warriorland/textures/item/command_icons"
SIZE = 64

# Palette: dark outline, warm highlights, violet accent, and Minecraft-like item colors.
INK = (16, 18, 39, 255)
INK2 = (37, 35, 73, 255)
WHITE = (246, 246, 255, 255)
GOLD = (255, 190, 36, 255)
GOLD_HI = (255, 235, 108, 255)
PURPLE = (178, 58, 255, 255)
CYAN = (52, 242, 222, 255)
GREEN = (39, 244, 102, 255)
RED = (245, 54, 74, 255)
BLUE = (62, 151, 255, 255)
BROWN = (137, 76, 39, 255)
TAN = (233, 177, 109, 255)
STONE = (130, 134, 158, 255)


def poly(d, points, fill, outline=INK, width=2):
    d.polygon(points, fill=fill)
    if outline:
        d.line(points + [points[0]], fill=outline, width=width, joint="curve")


def rect(d, box, fill, outline=INK, width=2):
    d.rectangle(box, fill=fill, outline=outline, width=width)


def line(d, points, fill, width=3):
    d.line(points, fill=fill, width=width, joint="curve")


def base_glow(color):
    im = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    glow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((13, 11, 51, 51), fill=(*color[:3], 74))
    return glow.filter(ImageFilter.GaussianBlur(7))


def draw_cube(d, top=(179, 223, 225, 255), left=(43, 112, 129, 255), right=(29, 76, 100, 255), pattern="plain"):
    poly(d, [(15, 22), (32, 12), (50, 22), (32, 33)], top, INK, 2)
    poly(d, [(15, 22), (32, 33), (32, 53), (15, 42)], left, INK, 2)
    poly(d, [(32, 33), (50, 22), (50, 42), (32, 53)], right, INK, 2)
    if pattern == "craft":
        for x, y in [(22, 23), (28, 18), (35, 23), (41, 22)]:
            rect(d, (x, y, x+3, y+2), TAN, None, 1)
        line(d, [(20, 29), (27, 33), (27, 43)], (230, 166, 78, 255), 2)
        line(d, [(38, 37), (44, 33)], (230, 166, 78, 255), 2)
    elif pattern == "chest":
        rect(d, (22, 25, 43, 29), GOLD, INK, 1)
        rect(d, (29, 30, 35, 43), GOLD_HI, INK, 1)
        rect(d, (28, 35, 36, 40), (74, 235, 202, 255), INK, 1)
    elif pattern == "books":
        rect(d, (21, 23, 27, 39), (225, 70, 82, 255), INK, 1)
        rect(d, (29, 25, 35, 42), (53, 120, 233, 255), INK, 1)
        rect(d, (37, 23, 43, 38), (236, 186, 55, 255), INK, 1)
    elif pattern == "market":
        rect(d, (20, 24, 44, 28), GREEN, INK, 1)
        for x in (23, 30, 37): rect(d, (x, 31, x+4, 36), GOLD_HI, INK, 1)
    elif pattern == "stone":
        for x, y in [(19,26),(28,22),(36,29),(23,35),(34,40)]: rect(d,(x,y,x+7,y+4),STONE,INK,1)


def draw_house(d, variant="home", accent=RED):
    # House with blocky roof, walls, windows and door.
    poly(d, [(10, 30), (31, 12), (54, 29), (49, 34), (31, 21), (15, 35)], accent, INK, 2)
    rect(d, (17, 30, 47, 49), (242, 218, 166, 255), INK, 2)
    rect(d, (21, 34, 28, 41), (79, 196, 255, 255), INK, 1)
    rect(d, (36, 34, 43, 41), (79, 196, 255, 255), INK, 1)
    rect(d, (29, 39, 36, 49), BROWN, INK, 1)
    rect(d, (34, 43, 35, 44), GOLD_HI, None, 1)
    if variant == "sethome":
        poly(d, [(8, 11), (17, 16), (8, 21)], GOLD, INK, 1)
        line(d, [(4, 16), (10, 16)], GOLD_HI, 2)
    elif variant == "delete":
        line(d, [(19, 27), (43, 46)], RED, 4); line(d, [(43, 27), (19, 46)], RED, 4)
    elif variant == "main":
        poly(d, [(31, 2), (35, 8), (42, 9), (37, 14), (39, 21), (31, 17), (24, 21), (26, 14), (21, 9), (28, 8)], GOLD_HI, INK, 1)
    elif variant == "expand":
        line(d, [(7, 26), (15, 18), (15, 23)], GREEN, 3); line(d, [(55, 26), (47, 18), (47, 23)], GREEN, 3)
    elif variant == "contract":
        line(d, [(7, 19), (15, 27), (10, 27)], RED, 3); line(d, [(55, 19), (47, 27), (52, 27)], RED, 3)
    elif variant == "subzone":
        rect(d, (20, 28, 43, 45), None, CYAN, 2); line(d, [(31,28),(31,45)], CYAN, 2)
    elif variant == "market":
        rect(d, (18, 25, 46, 30), GREEN, INK, 1); line(d, [(22,25),(22,21),(42,21),(42,25)], GOLD, 2)
    elif variant == "shop":
        rect(d, (28, 35, 36, 41), GOLD_HI, INK, 1)


def draw_pearl(d, color=CYAN, variant="pearl"):
    d.ellipse((13, 12, 51, 50), fill=(19, 38, 69, 255), outline=INK, width=2)
    d.ellipse((17, 15, 47, 45), fill=color, outline=(9, 22, 42, 255), width=3)
    d.ellipse((22, 19, 42, 39), fill=(*color[:3], 255), outline=WHITE, width=1)
    d.ellipse((22, 17, 30, 25), fill=WHITE, outline=None)
    d.ellipse((29, 29, 40, 40), fill=(30, 55, 79, 210), outline=None)
    if variant == "accept":
        line(d, [(35, 39), (40, 44), (51, 31)], GREEN, 5)
    elif variant == "deny":
        line(d, [(36, 32), (50, 46)], RED, 5); line(d, [(50,32),(36,46)], RED,5)
    elif variant == "back":
        line(d, [(42, 6), (31, 6), (31, 3)], GOLD_HI, 3); line(d, [(31,6),(38,13)], GOLD_HI, 3)


def draw_chat(d, rainbow=True):
    poly(d, [(12, 14), (52, 14), (52, 40), (35, 40), (25, 51), (25, 40), (12, 40)], WHITE, INK, 3)
    inside = d
    cols = [(255, 75, 75, 255), (255, 165, 50, 255), (255, 235, 70, 255), (60, 220, 93, 255), (65, 158, 255, 255), (187, 70, 255, 255)] if rainbow else [CYAN]
    for i, c in enumerate(cols):
        x0 = 16 + i * (31 / len(cols)); x1 = 16 + (i + 1) * (31 / len(cols))
        rect(inside, (int(x0), 18, int(x1), 29), c, None, 1)
    rect(inside, (16, 32, 48, 36), (150, 91, 238, 255), None, 1)
    line(inside, [(18, 43), (24, 43), (24, 47)], INK2, 2)


def draw_tag(d, rainbow=False, rename=False):
    color = (255, 207, 137, 255)
    poly(d, [(13, 41), (36, 14), (48, 13), (50, 25), (27, 49)], color, INK, 3)
    poly(d, [(18, 39), (37, 18), (43, 17), (44, 23), (25, 44)], (242, 190, 117, 255), None, 1)
    d.ellipse((39, 16, 45, 22), fill=(26, 35, 61, 255), outline=INK, width=1)
    if rainbow:
        for i, c in enumerate([(255, 50, 73, 255), (255, 180, 38, 255), (250, 238, 65, 255), (41, 233, 112, 255), (40, 180, 255, 255), (180, 70, 255, 255)]):
            line(d, [(22+i, 38-i//2), (30+i, 29-i//2)], c, 3)
    elif rename:
        line(d, [(20, 28), (36, 42)], PURPLE, 3)


def draw_book(d, open_book=False, paper=False):
    if open_book:
        poly(d, [(9, 21), (29, 17), (32, 20), (32, 48), (12, 46)], (235, 226, 189, 255), INK, 2)
        poly(d, [(32, 20), (36, 17), (55, 21), (53, 46), (32, 48)], WHITE, INK, 2)
        line(d, [(32, 21), (32, 47)], PURPLE, 2)
        for y in (28, 34, 40):
            line(d, [(15, y), (27, y-2)], (125, 137, 172, 255), 1)
            line(d, [(37, y-2), (49, y)], (125, 137, 172, 255), 1)
    elif paper:
        poly(d, [(18, 10), (42, 10), (49, 18), (49, 52), (18, 52)], WHITE, INK, 2)
        poly(d, [(42, 10), (42, 18), (49, 18)], (191, 197, 221, 255), INK, 1)
        for y in (25, 31, 37, 43): line(d, [(23, y), (43, y)], BLUE, 2)
    else:
        poly(d, [(17, 16), (31, 12), (31, 51), (17, 47)], (207, 66, 75, 255), INK, 2)
        poly(d, [(31, 12), (47, 16), (47, 47), (31, 51)], (246, 222, 167, 255), INK, 2)
        line(d, [(22, 25), (27, 23)], GOLD_HI, 2); line(d, [(36, 24), (42, 26)], GOLD_HI, 2)


def draw_coins(d, stack=True, green=False):
    color = GREEN if green else GOLD
    positions = [(11,37,27,49),(25,30,41,47),(39,37,55,49)] if stack else [(19,26,45,51)]
    for x0,y0,x1,y1 in positions:
        rect(d, (x0, y0, x1, y1), color, INK, 2)
        d.ellipse((x0, y0-5, x1, y0+4), fill=GOLD_HI if not green else (125,255,177,255), outline=INK, width=2)
        d.arc((x0+3,y0-3,x1-3,y0+2), 180, 355, fill=(255,255,210,255), width=2)
    if stack:
        rect(d, (22, 25, 36, 37), color, INK, 2)
        d.ellipse((22, 20, 36, 29), fill=GOLD_HI if not green else (125,255,177,255), outline=INK, width=2)


def draw_clock(d, type_="clock", color=CYAN):
    d.ellipse((11, 11, 53, 53), fill=(21, 28, 55, 255), outline=INK, width=3)
    d.ellipse((15, 15, 49, 49), fill=color, outline=WHITE, width=1)
    d.ellipse((20, 20, 44, 44), fill=(22, 39, 71, 255), outline=INK, width=1)
    line(d, [(32, 22), (32, 33), (41, 38)], GOLD_HI, 3)
    d.ellipse((29, 30, 35, 36), fill=WHITE, outline=INK, width=1)
    if type_ == "afk":
        d.arc((17, 17, 47, 47), 210, 335, fill=PURPLE, width=3)
    elif type_ == "ping":
        line(d, [(16, 8), (23, 14), (28, 6), (35, 14), (43, 8)], RED, 3)


def draw_anvil(d):
    poly(d, [(13, 26), (22, 18), (43, 18), (52, 27), (44, 32), (20, 32)], (168, 174, 191, 255), INK, 3)
    poly(d, [(20, 32), (44, 32), (40, 40), (24, 40)], (110, 118, 142, 255), INK, 2)
    poly(d, [(26, 40), (38, 40), (42, 49), (22, 49)], (81, 87, 112, 255), INK, 2)
    line(d, [(22, 23), (43, 23)], (225, 229, 241, 255), 2)


def draw_tool(d, kind="pickaxe"):
    if kind == "pickaxe":
        line(d, [(21, 49), (42, 18)], BROWN, 7); line(d, [(21, 49), (42, 18)], TAN, 3)
        poly(d, [(15, 19), (20, 12), (30, 15), (39, 11), (48, 15), (44, 23), (30, 21), (22, 25)], STONE, INK, 3)
        line(d, [(18, 18), (28, 18)], WHITE, 2)
    elif kind == "axe":
        line(d, [(23, 50), (38, 17)], BROWN, 7); line(d, [(23, 50), (38, 17)], TAN, 3)
        poly(d, [(31, 14), (49, 11), (55, 22), (43, 30), (36, 24)], STONE, INK, 3)
        line(d, [(44, 16), (49, 21)], WHITE, 2)
    elif kind == "feather":
        poly(d, [(16, 51), (20, 30), (32, 12), (47, 8), (50, 25), (36, 42)], (117, 211, 255, 255), INK, 2)
        line(d, [(17, 51), (37, 22)], WHITE, 2)
        for x,y in [(25,35),(30,30),(35,26),(39,21)]: line(d, [(x,y),(x+6,y+1)], BLUE, 1)
    elif kind == "key":
        d.ellipse((11, 13, 31, 33), fill=GOLD, outline=INK, width=3)
        d.ellipse((17, 19, 25, 27), fill=(15, 22, 43, 255), outline=INK, width=1)
        rect(d, (27, 20, 49, 27), GOLD, INK, 2); rect(d, (40, 25, 46, 34), GOLD, INK, 2)
    else:
        draw_tool(d, "pickaxe")


def draw_map(d):
    poly(d, [(11, 15), (27, 10), (39, 16), (53, 11), (53, 48), (38, 53), (26, 47), (11, 52)], (236, 222, 177, 255), INK, 2)
    poly(d, [(15, 18), (26, 15), (26, 43), (15, 47)], (105, 183, 113, 255), None, 1)
    poly(d, [(31, 17), (37, 20), (37, 48), (31, 44)], (88, 150, 91, 255), None, 1)
    d.ellipse((33, 25, 43, 35), fill=RED, outline=INK, width=2)
    d.ellipse((36, 28, 40, 32), fill=GOLD_HI, outline=None)


def draw_flag(d, color=PURPLE):
    line(d, [(17, 10), (17, 53)], STONE, 4)
    poly(d, [(19, 12), (49, 17), (40, 28), (19, 25)], color, INK, 2)
    line(d, [(20, 15), (43, 19)], WHITE, 2)


def draw_gear(d, color=STONE):
    cx=32; cy=31
    pts=[]
    for i in range(24):
        a=math.pi*2*i/24 - math.pi/2
        r=22 if i%2==0 else 17
        pts.append((int(cx+math.cos(a)*r),int(cy+math.sin(a)*r)))
    poly(d,pts,color,INK,2)
    d.ellipse((24,23,40,39),fill=(25,31,57,255),outline=WHITE,width=2)
    d.ellipse((29,28,35,34),fill=GOLD,outline=INK,width=1)


def draw_helmet(d):
    poly(d, [(17, 32), (17, 23), (24, 14), (40, 14), (47, 23), (47, 32), (42, 38), (22, 38)], STONE, INK, 3)
    rect(d, (19, 30, 45, 39), (87, 95, 119, 255), INK, 2)
    rect(d, (24, 22, 40, 27), BLUE, INK, 1)
    line(d, [(24, 17), (40, 17)], WHITE, 2)


def draw_food(d, kind="steak"):
    poly(d, [(10, 38), (18, 20), (34, 13), (51, 20), (54, 32), (44, 45), (26, 51), (15, 46)], (153, 58, 40, 255), INK, 3)
    poly(d, [(15, 36), (22, 23), (35, 18), (47, 23), (49, 31), (41, 40), (27, 45), (18, 42)], (223, 105, 64, 255), None, 1)
    for x,y in [(24,27),(34,25),(39,33),(27,37)]:
        line(d, [(x,y),(x+6,y-2)], (91, 45, 38, 255), 2)
    if kind == "apple":
        d.ellipse((18,18,44,47),fill=(235,64,62,255),outline=INK,width=3)
        line(d, [(31,19),(34,10)], BROWN, 3)
        poly(d, [(33,14),(43,12),(39,20)], GREEN, INK, 1)


def draw_glass(d, color=CYAN):
    poly(d, [(13, 13), (51, 13), (47, 31), (39, 40), (39, 49), (26, 49), (26, 40), (17, 31)], (111, 220, 255, 125), INK, 3)
    poly(d, [(18, 18), (46, 18), (42, 30), (23, 30)], (*color[:3], 220), None, 1)
    line(d, [(21, 21), (27, 21)], WHITE, 2)
    rect(d, (26, 46, 39, 52), STONE, INK, 1)


def draw_skull(d):
    d.ellipse((17, 11, 47, 39), fill=(218, 221, 232, 255), outline=INK, width=3)
    rect(d, (22, 34, 42, 43), (218, 221, 232, 255), INK, 2)
    d.ellipse((21, 23, 28, 31), fill=INK, outline=None); d.ellipse((36, 23, 43, 31), fill=INK, outline=None)
    poly(d, [(30, 30), (34, 30), (32, 35)], INK, None, 1)
    rect(d, (25, 38, 29, 45), WHITE, INK, 1); rect(d, (31, 38, 35, 45), WHITE, INK, 1); rect(d, (37, 38, 41, 45), WHITE, INK, 1)


def draw_icon(key: str) -> Image.Image:
    im = Image.new("RGBA", (SIZE, SIZE), (0,0,0,0))
    # soft color haze, then a single crisp pixel-art object over it
    color = PURPLE if any(s in key for s in ("warp", "nick", "chat", "suicide")) else CYAN
    im = Image.alpha_composite(im, base_glow(color))
    d = ImageDraw.Draw(im)

    if key in {"home", "sethome", "delhome", "listhomes", "residence_create", "residence_subzone", "residence_setmain", "residence_shop", "residence_market"}:
        variant = {"sethome":"sethome","delhome":"delete","residence_subzone":"subzone","residence_setmain":"main","residence_market":"market","residence_shop":"shop"}.get(key,"home")
        draw_house(d, variant, GOLD if key == "residence_market" else (PURPLE if key.startswith("residence_") else RED))
        if key == "delhome": line(d, [(14,14),(49,49)], RED, 4)
    elif key in {"tpa", "tpaccept", "tpdeny", "back", "residence_tp", "residence_rt", "spawn", "jump", "unstuck"}:
        if key in {"jump", "unstuck"}: draw_tool(d,"feather")
        elif key == "spawn": draw_map(d)
        else: draw_pearl(d, PURPLE if key in {"residence_rt"} else CYAN, {"tpaccept":"accept","tpdeny":"deny","back":"back"}.get(key,"pearl"))
        if key == "residence_tp": draw_house(d,"home",RED)
    elif key in {"chatcolour"}:
        draw_chat(d, True)
    elif key in {"nick", "nickcolour", "residence_rename"}:
        draw_tag(d, key == "nickcolour", key == "residence_rename")
    elif key in {"balance", "balancetop", "pay", "residence_market"}:
        draw_coins(d, True, key == "pay")
        if key == "balancetop": poly(d, [(32,4),(37,12),(46,12),(40,19),(42,26),(32,21),(22,26),(24,19),(18,12),(27,12)], GOLD_HI, INK, 1)
    elif key in {"workbench", "recipe", "residence_shop", "kit", "enderchest"}:
        draw_cube(d, (56,151,132,255) if key=="enderchest" else (184,134,83,255), (139,81,41,255), (94,48,38,255) if key!="enderchest" else (14,76,91,255), "craft" if key in {"workbench","recipe"} else "chest" if key in {"enderchest","kit"} else "market")
    elif key in {"ignore"}:
        draw_book(d, paper=True); d.ellipse((35,30,55,50),fill=RED,outline=INK,width=2); line(d,[(39,34),(51,46)],WHITE,3); line(d,[(51,34),(39,46)],WHITE,3)
    elif key in {"msg","reply","mail","rules","list","itemdb","playtime"}:
        if key in {"msg","reply","mail"}: draw_book(d, open_book=key=="reply", paper=key=="mail")
        elif key=="itemdb": draw_cube(d, (174,139,88,255),(121,77,43,255),(88,50,33,255),"books")
        elif key=="list":
            d.ellipse((22,11,42,31),fill=(241,190,148,255),outline=INK,width=2); poly(d,[(13,51),(15,36),(23,30),(40,30),(49,37),(51,51)],BLUE,INK,2)
        else: draw_clock(d, "clock", PURPLE if key=="playtime" else BLUE)
    elif key in {"feed", "heal"}:
        draw_food(d,"apple" if key=="heal" else "steak")
    elif key in {"anvil", "repair"}:
        draw_anvil(d)
        if key=="repair": line(d,[(10,14),(22,26)],GREEN,3); line(d,[(22,14),(10,26)],GREEN,3)
    elif key in {"stonecutter", "grindstone", "smithingtable", "loom", "cartographytable", "residence_set", "residence_padd", "residence_pdel"}:
        if key=="stonecutter": draw_tool(d,"axe")
        elif key=="grindstone": draw_cube(d,STONE,(100,102,127,255),(70,76,99,255),"stone")
        elif key=="smithingtable": draw_cube(d,(171,111,67,255),(107,62,46,255),(67,48,45,255),"craft")
        elif key=="loom": draw_cube(d,(169,98,120,255),(101,59,82,255),(75,42,66,255),"books")
        elif key=="cartographytable": draw_map(d)
        elif key=="residence_set": draw_gear(d,GOLD)
        elif key=="residence_padd": draw_house(d); line(d,[(43,8),(43,23)],GREEN,4); line(d,[(36,15),(50,15)],GREEN,4)
        else: draw_house(d); line(d,[(36,15),(50,15)],RED,4)
    elif key in {"disposal", "condense", "more", "residence_limits", "residence_expand", "residence_contract"}:
        if key=="disposal": draw_glass(d,RED)
        elif key=="condense": draw_cube(d,STONE,(103,110,130,255),(75,81,98,255),"stone")
        elif key=="more":
            poly(d,[(17,12),(47,12),(42,28),(37,34),(37,50),(27,50),(27,34),(22,28)],STONE,INK,3); rect(d,(25,15,39,21),GOLD,INK,1)
        elif key=="residence_limits": draw_cube(d,(180,145,93,255),(119,81,45,255),(86,53,32,255),"books")
        else:
            draw_house(d,"expand" if key.endswith("expand") else "contract",RED if key.endswith("contract") else GREEN)
    elif key in {"near", "compass", "depth", "getpos", "residence_info", "residence_current", "residence_select", "residence_tpset"}:
        if key in {"getpos","residence_info"}: draw_map(d)
        elif key == "residence_select": draw_tool(d,"axe")
        elif key == "residence_tpset": draw_pearl(d,GOLD)
        elif key == "near":
            d.ellipse((11,11,53,53),fill=(22,45,72,255),outline=INK,width=3); d.ellipse((17,17,47,47),fill=CYAN,outline=WHITE,width=2); line(d,[(32,17),(32,47)],INK2,2); line(d,[(17,32),(47,32)],INK2,2); d.ellipse((27,27,37,37),fill=GOLD,outline=INK,width=1)
        else: draw_gear(d, BLUE if key=="depth" else PURPLE)
    elif key in {"seen", "ptime", "pweather", "afk", "motd", "ping", "suicide", "hat", "balancetop"}:
        if key in {"seen","ptime","afk"}: draw_clock(d,"afk" if key=="afk" else "clock", PURPLE if key=="afk" else CYAN)
        elif key=="pweather": draw_glass(d,BLUE)
        elif key=="motd": draw_flag(d,GOLD)
        elif key=="ping": draw_clock(d,"ping",RED)
        elif key=="suicide": draw_skull(d)
        elif key=="hat": draw_helmet(d)
        else: draw_coins(d)
    elif key in {"residence_message", "residence_list", "residence_unstuck", "residence_rt", "residence_pdel", "residence_padd"}:
        if key=="residence_message": draw_chat(d,False)
        elif key=="residence_list": draw_book(d,open_book=True)
        elif key=="residence_unstuck": draw_tool(d,"feather")
        elif key=="residence_rt": draw_pearl(d,PURPLE)
        else: draw_house(d)
    else:
        # fallback is still a proper pixel-art glyph, never an empty/duplicate token icon
        draw_gear(d, PURPLE if len(key)%2 else CYAN)
        d.text((23, 25), key[:1].upper(), font=None, fill=WHITE, stroke_width=1, stroke_fill=INK)

    # Small common pixel glint reinforces the game-item style without placing a frame around every icon.
    d.rectangle((8, 11, 10, 13), fill=(255,255,255,190))
    d.rectangle((52, 44, 54, 46), fill=(*PURPLE[:3], 180))
    return im


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    state_suffixes = ("_unlocked", "_ready", "_insufficient", "_locked", "_unavailable")
    ids = sorted(p.stem for p in (ROOT / "resource-pack/assets/warriorland/items/command_icons").glob("*.json")
                 if not p.stem.endswith(state_suffixes))
    for key in ids:
        draw_icon(key).save(OUT / f"{key}.png", optimize=True)
    print(f"Generated {len(ids)} deterministic 64x64 command icons at {OUT}")

if __name__ == "__main__":
    main()
