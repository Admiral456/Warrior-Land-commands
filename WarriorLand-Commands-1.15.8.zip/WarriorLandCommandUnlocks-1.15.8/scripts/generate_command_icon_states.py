#!/usr/bin/env python3
"""Generate status-aware variants of each 64px item icon for the optional Paper resource pack."""
from __future__ import annotations
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "resource-pack/assets/warriorland"
TEXTURES = PACK / "textures/item/command_icons"
ITEM_MODELS = PACK / "items/command_icons"
MODELS = PACK / "models/item/command_icons"
STATES = {
    "unlocked": (40, 238, 112, 255),
    "ready": (255, 193, 42, 255),
    "insufficient": (246, 145, 50, 255),
    "locked": (146, 150, 190, 255),
    "unavailable": (255, 54, 78, 255),
}
INK = (12, 13, 31, 255)
WHITE = (255, 255, 255, 255)


def draw_variant(source: Image.Image, state: str, color: tuple[int, int, int, int]) -> Image.Image:
    base = source.convert("RGBA")
    glow = Image.new("RGBA", base.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.rounded_rectangle((2, 2, 61, 61), radius=9, outline=(*color[:3], 180), width=5)
    glow = glow.filter(ImageFilter.GaussianBlur(4))
    out = Image.alpha_composite(glow, base)
    d = ImageDraw.Draw(out)
    d.rounded_rectangle((2, 2, 61, 61), radius=9, outline=color, width=2)
    # A compact pixel badge makes the state understandable even when the icon is scaled down.
    d.polygon([(44, 43), (57, 43), (62, 49), (62, 58), (57, 63), (47, 63), (42, 58), (42, 48)], fill=INK, outline=color)
    if state == "unlocked":
        d.line([(46, 53), (50, 57), (58, 47)], fill=WHITE, width=3)
        d.line([(46, 53), (50, 57), (58, 47)], fill=color, width=1)
    elif state in {"ready", "insufficient"}:
        d.ellipse((46, 46, 59, 59), fill=color, outline=INK, width=1)
        d.ellipse((49, 49, 56, 56), outline=WHITE, width=1)
        d.line([(50, 52), (55, 52)], fill=INK, width=1)
        d.line([(52, 50), (52, 55)], fill=INK, width=1)
    elif state == "locked":
        d.arc((48, 46, 57, 55), 180, 360, fill=WHITE, width=2)
        d.rounded_rectangle((46, 51, 59, 59), radius=2, fill=color, outline=INK, width=1)
        d.point((52, 54), fill=INK)
    else:
        d.line([(52, 46), (52, 53)], fill=WHITE, width=3)
        d.point((52, 57), fill=WHITE)
    return out


def main() -> None:
    ITEM_MODELS.mkdir(parents=True, exist_ok=True)
    MODELS.mkdir(parents=True, exist_ok=True)
    keys = sorted(path.stem for path in ITEM_MODELS.glob("*.json") if not any(path.stem.endswith("_" + s) for s in STATES))
    made = 0
    for key in keys:
        source_path = TEXTURES / f"{key}.png"
        item_base_path = ITEM_MODELS / f"{key}.json"
        model_base_path = MODELS / f"{key}.json"
        if not source_path.is_file() or not item_base_path.is_file() or not model_base_path.is_file():
            raise SystemExit(f"Missing base icon model/texture for {key}")
        base_image = Image.open(source_path).convert("RGBA")
        for state, color in STATES.items():
            name = f"{key}_{state}"
            draw_variant(base_image, state, color).save(TEXTURES / f"{name}.png", optimize=True)
            (ITEM_MODELS / f"{name}.json").write_text(json.dumps({"model": {"type": "minecraft:model", "model": f"warriorland:item/command_icons/{name}"}}, indent=2) + "\n", encoding="utf-8")
            (MODELS / f"{name}.json").write_text(json.dumps({"parent": "minecraft:item/generated", "textures": {"layer0": f"warriorland:item/command_icons/{name}"}}, indent=2) + "\n", encoding="utf-8")
            made += 1
    print(f"Generated {made} status-aware icon variants for {len(keys)} base command icons ({', '.join(STATES)}).")

if __name__ == "__main__":
    main()
