#!/usr/bin/env python3
"""Export the player-facing web catalogue from the authoritative Paper config."""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "src/main/resources/config.yml"
PLUGIN = ROOT / "src/main/resources/plugin.yml"
OUTPUT = ROOT / "web/data/catalog.json"
PACK_ICONS = ROOT / "resource-pack/assets/warriorland/textures/item/command_icons"
WEB_ICONS = ROOT / "web/assets/command-icons"


def main() -> None:
    config = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    plugin = yaml.safe_load(PLUGIN.read_text(encoding="utf-8"))
    gradle = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
    version_match = re.search(r'^version\s*=\s*"([^"]+)"', gradle, re.MULTILINE)
    if not version_match:
        raise SystemExit("Could not read project version from build.gradle.kts")
    project_version = version_match.group(1)
    raw_unlocks = config.get("unlocks") or {}
    unlocks = []
    for unlock_id, definition in raw_unlocks.items():
        item = {
            "id": str(unlock_id),
            "name": definition.get("name", unlock_id),
            "description": definition.get("description", ""),
            "category": definition.get("category", "utility"),
            "icon": definition.get("icon", "PAPER"),
            "cost": int(definition.get("cost", 0)),
            "taskReward": int(definition.get("task-reward", 0)),
            "commands": list(definition.get("commands") or []),
            "requiredPlugins": list(definition.get("required-plugins") or []),
            "tasks": list(definition.get("tasks") or []),
        }
        unlocks.append(item)

    result = {
        "version": project_version,
        "categories": config.get("categories") or {},
        "unlocks": unlocks,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    # Keep web and in-game preview icon assets in sync with the same generated art.
    WEB_ICONS.mkdir(parents=True, exist_ok=True)
    for old_png in WEB_ICONS.glob("*.png"):
        old_png.unlink()
    source_icons = list(PACK_ICONS.glob("*.png"))
    for icon in source_icons:
        shutil.copy2(icon, WEB_ICONS / icon.name)
    print(f"Exported {len(unlocks)} unlocks and {len(source_icons)} icons to web/ (plugin {result['version']}).")


if __name__ == "__main__":
    main()
