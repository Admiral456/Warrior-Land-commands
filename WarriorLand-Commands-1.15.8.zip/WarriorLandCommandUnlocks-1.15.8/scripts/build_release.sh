#!/usr/bin/env bash
# Reproducible local release path for Paper-only WarriorLand Command Unlocks.
# Requires JDK 21, Gradle 9.2.1, Python, PyYAML, Pillow, and network access to Maven repositories.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python scripts/generate_resource_pack_icons.py
python scripts/generate_command_icon_states.py
python scripts/generate_itemsadder_gui_background.py
python scripts/render_source_preview.py
python scripts/export_web_catalog.py
python scripts/validate_web_preview.py
python scripts/validate_project.py
python scripts/validate_server_only.py
gradle clean test build --warning-mode all

JAR="build/libs/WarriorLandCommandUnlocks-1.15.8.jar"
PACK="WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip"
IA_ADDON="WarriorLandCommandUnlocks-ItemsAdder-Addon-1.15.8.zip"
WEB_SITE="WarriorLand-Web-1.15.8.zip"
test -s "$JAR"
jar tf "$JAR" | grep -x 'plugin.yml' >/dev/null
jar tf "$JAR" | grep -x 'config.yml' >/dev/null
jar tf "$JAR" | grep -x 'cz/warriorland/commandunlocks/TutorialChoiceMutationPolicy.class' >/dev/null
jar tf "$JAR" | grep -x 'cz/warriorland/commandunlocks/ResourcePackIconPolicy.class' >/dev/null
jar tf "$JAR" | grep -x 'cz/warriorland/commandunlocks/HudStatusPolicy.class' >/dev/null
jar tf "$JAR" | grep -x 'cz/warriorland/commandunlocks/CommandCardVisualPolicy.class' >/dev/null
jar tf "$JAR" | grep -x 'cz/warriorland/commandunlocks/MenuQuickActionPolicy.class' >/dev/null
jar tf "$JAR" | grep -x 'cz/warriorland/commandunlocks/ItemsAdderConstructorPolicy.class' >/dev/null
unzip -p "$JAR" plugin.yml | grep -F "version: '1.15.8'" >/dev/null
unzip -p "$JAR" config.yml | grep -F 'hud-status-bar: true' >/dev/null
unzip -p "$JAR" config.yml | grep -F 'use-resource-pack-icons: false' >/dev/null
unzip -p "$JAR" config.yml | grep -F 'allow-unverified-manual-resource-pack-icons: false' >/dev/null
unzip -p "$JAR" config.yml | grep -F 'itemsadder-title-offset: 0' >/dev/null
unzip -p "$JAR" config.yml | grep -F 'itemsadder-texture-offset: 0' >/dev/null
if jar tf "$JAR" | grep -E 'ClientUiBridge|ClientActionRateLimiter|fabric\.mod\.json' >/dev/null; then
  echo 'Client-side mod or plugin-message bridge must not be included in the server JAR.' >&2
  exit 1
fi
rm -f "$PACK"
(cd resource-pack && zip -qr "../$PACK" .)
test -s "$PACK"
rm -f "$IA_ADDON"
(cd itemsadder-addon && zip -qr "../$IA_ADDON" README.md contents)
test -s "$IA_ADDON"
rm -f "$WEB_SITE"
(cd web && zip -qr "../$WEB_SITE" .)
test -s "$WEB_SITE"
unzip -l "$IA_ADDON" | grep -F 'contents/warriorland_unlocks/config.yml' >/dev/null
unzip -l "$IA_ADDON" | grep -F 'command_menu_background.png' >/dev/null
sha256sum "$JAR" "$PACK" "$IA_ADDON" "$WEB_SITE"
