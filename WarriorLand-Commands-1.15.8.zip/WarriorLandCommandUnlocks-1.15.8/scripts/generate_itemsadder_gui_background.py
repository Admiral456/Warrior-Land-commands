#!/usr/bin/env python3
"""Generate a restrained neon-purple background for the optional ItemsAdder inventory skin.

The image intentionally keeps the 54 top-inventory item faces transparent so Paper still renders
real item stacks and slot interaction. It is a background skin, not a client-side custom screen.
"""
from pathlib import Path
import math
import random
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "itemsadder-addon/contents/warriorland_unlocks/resourcepack/assets/warriorland_unlocks/textures/font/command_menu_background.png"
W, H = 176, 222
random.seed(1158)

im = Image.new("RGBA", (W, H), (5, 7, 20, 255))
pix = im.load()
for y in range(H):
    for x in range(W):
        edge = min(x, W - 1 - x, y, H - 1 - y)
        vio = max(0.0, 1.0 - math.sqrt((x - 18)**2 + (y - 180)**2) / 112.0)
        blue = max(0.0, 1.0 - math.sqrt((x - 145)**2 + (y - 20)**2) / 108.0)
        center = max(0.0, 1.0 - abs(x - 88) / 110.0) * max(0.0, 1.0 - abs(y - 100) / 160.0)
        noise = random.randint(-2, 2)
        pix[x, y] = (
            max(0, min(255, 4 + int(10 * vio) + int(2 * center) + noise)),
            max(0, min(255, 6 + int(2 * vio) + int(2 * blue) + noise)),
            max(0, min(255, 19 + int(20 * vio) + int(15 * blue) + int(4 * center) + noise)),
            246,
        )

d = ImageDraw.Draw(im, "RGBA")
# Clipped neon frame inspired by the reference image.
frame = [(9, 0), (W-10, 0), (W-1, 9), (W-1, H-10), (W-10, H-1), (9, H-1), (0, H-10), (0, 9), (9, 0)]
d.line(frame, fill=(168, 68, 255, 255), width=2, joint="curve")
d.line([(10, 2), (W-11, 2)], fill=(215, 126, 255, 150), width=1)
d.line([(2, 10), (2, H-11)], fill=(85, 70, 255, 170), width=1)
d.line([(W-3, 10), (W-3, H-11)], fill=(115, 74, 255, 170), width=1)
d.line([(10, H-3), (W-11, H-3)], fill=(180, 50, 255, 170), width=1)

# Tiny pixel skyline across the header strip; it remains above the first slot row.
skyline = [(12,14),(12,11),(15,11),(15,7),(18,7),(18,12),(21,12),(21,9),(24,9),(24,13),
           (29,13),(29,8),(32,8),(32,4),(35,4),(35,13),(40,13),(40,10),(43,10),(43,6),(46,6),(46,13),
           (54,13),(54,9),(57,9),(57,5),(60,5),(60,13),(67,13),(67,10),(70,10),(70,7),(73,7),(73,13),
           (86,13),(86,8),(89,8),(89,4),(92,4),(92,12),(96,12),(96,7),(99,7),(99,13),
           (106,13),(106,9),(109,9),(109,5),(112,5),(112,13),(119,13),(119,10),(122,10),(122,6),(125,6),(125,13),
           (139,13),(139,9),(142,9),(142,5),(145,5),(145,13),(151,13),(151,10),(154,10),(154,7),(157,7),(157,13)]
d.polygon(skyline, fill=(22, 18, 61, 210))
for x, y in [(20,10),(34,7),(44,9),(59,8),(71,11),(90,6),(110,8),(123,7),(143,8),(155,10)]:
    d.rectangle((x, y, x+1, y+1), fill=(197, 88, 255, 180))
# Blue/violet divider rails corresponding to sidebar, cards, and detail columns.
for x, c in [(25,(123,72,255,130)), (43,(86,69,190,100)), (115,(91,75,199,100)), (133,(175,72,255,150))]:
    d.line((x, 17, x, 124), fill=c, width=1)
# Horizontal separators and fine pixel glints in the empty slot gutters.
for row in range(1, 6):
    yy = 17 + row * 18 - 1
    d.line((3, yy, W-4, yy), fill=(104, 57, 188, 120), width=1)
for col in range(1, 9):
    xx = 7 + col * 18 - 1
    d.line((xx, 17, xx, 124), fill=(87, 58, 162, 100), width=1)
# Subtle dark panels between rows: greenish-blue center and purple detail rail.
d.rectangle((44, 17, 114, 124), fill=(7, 13, 29, 64))
d.rectangle((116, 17, 172, 124), fill=(13, 8, 34, 68))
d.line((116, 18, 116, 123), fill=(161, 75, 255, 160), width=1)
d.line((44, 17, 114, 17), fill=(68, 174, 255, 90), width=1)
# Low-contrast castle silhouette at the bottom of the texture. This is decorative only.
d.rectangle((4, 150, 171, 217), fill=(5, 6, 18, 90))
for x, base, h, w in [(8,201,28,8),(20,211,44,10),(35,210,31,8),(49,215,50,12),(68,212,35,9),
                      (86,217,56,13),(109,212,36,9),(126,216,47,11),(144,210,30,8),(158,216,43,10)]:
    d.rectangle((x, base-h, x+w, base), fill=(13, 12, 39, 215))
    d.rectangle((x+2, base-h+5, x+3, base-h+8), fill=(108, 44, 207, 155))
    if h > 40:
        d.rectangle((x+w-4, base-h+16, x+w-3, base-h+20), fill=(228, 125, 52, 130))
# Decorative top and bottom inset rails.
d.line((7, 16, W-8, 16), fill=(117, 57, 216, 145), width=1)
d.line((7, 127, W-8, 127), fill=(114, 63, 206, 160), width=1)
d.line((8, 218, W-9, 218), fill=(110, 54, 222, 130), width=1)

# Keep the 16x16 face of each of the 54 container slots transparent. The underlying Minecraft
# slot frame and the actual ItemStack still render and remain clickable above this image.
for row in range(6):
    for col in range(9):
        x, y = 7 + col*18, 17 + row*18
        im.paste((0, 0, 0, 0), (x+1, y+1, min(W, x+17), min(H, y+17)))

OUT.parent.mkdir(parents=True, exist_ok=True)
im.save(OUT, optimize=True)
with Image.open(OUT) as check:
    assert check.size == (176, 222) and check.mode == "RGBA"
    alpha = check.getchannel("A")
    assert alpha.getextrema()[0] == 0 and alpha.getextrema()[1] == 255
print(f"PASS ItemsAdder font image: {OUT.relative_to(ROOT)} ({W}x{H}, RGBA)")
