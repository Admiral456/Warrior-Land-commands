# WarriorLand web catalogue — preview

This folder contains the first responsive browser-based WarriorLand command catalogue.

## Open locally

The website uses `fetch()` to read `data/catalog.json`, so serve this folder over HTTP rather than opening `index.html` directly as a `file://` URL. Regenerate the catalogue and synchronize icons from the authoritative config/resource pack with `python scripts/export_web_catalog.py` from the project root.

On Windows, double-click `RUN-WEB-PREVIEW.bat` in the project root. On Linux/macOS, run `./RUN-WEB-PREVIEW.sh`. Or from the project root, use:

```bash
python -m http.server 8080 --directory web
```

Then open `http://localhost:8080`. Stop the local preview with Ctrl+C in its terminal window.

## Included in this preview

- Responsive desktop, tablet and mobile layout.
- Exact read-only catalogue imported from the project's `config.yml` export: 75 unlock definitions and 5 categories.
- Pixel-art command icon states synchronized from the current resource pack into `assets/command-icons/` for the preview (450 PNG files).
- Category navigation, search across command names/aliases/descriptions/dependencies, sorting, status filters and pagination.
- Command detail panel with aliases, required plugins, prices, task requirements and illustrated demo progress.
- Separate Katalog, Moje příkazy and Úkoly views.

## Demo-data boundary

The displayed balance, owned-command states and task progress are clearly illustrative. They are not read from a real player account. The purchase button is intentionally disabled. No login, registration, account-linking, purchase, points mutation or live Minecraft API exists in this web-only milestone.

Next milestone: build the plugin-backed HTTPS API and secure player-account pairing described in `../docs/WEB_GUI_ARCHITECTURE.md` and `../docs/WEB_COMMANDS.md`.
