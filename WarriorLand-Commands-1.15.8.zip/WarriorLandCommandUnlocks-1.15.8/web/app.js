const $ = (selector) => document.querySelector(selector);
const state = {
  catalog: { unlocks: [], categories: {} },
  category: 'all', view: 'all', filter: 'all', page: 0, selectedId: null,
  pageSize: 12, toastTimer: null
};

// Explicitly illustrative profile data. Live account data will arrive from the Paper API later.
const DEMO_PROFILE = {
  balance: 250,
  owned: new Set(['workbench', 'ignore', 'tpa']),
  taskProgress: { 'home:stone': 50, 'home:monsters': 5, 'sethome:materials': 25, 'nick:goal': 5, 'chatcolour:goal': 12, 'tpaccept:crafting': 7, 'tpdeny:monsters': 2, 'warp:crafting': 15, 'warp:community-vote': 1, 'balance:mining': 16, 'enderchest:dangerous-mobs': 5, 'tpa:fishing': 5 }
};
const CATEGORY_META = {
  all: { label: 'Všechny', icon: '▦' },
  teleport: { label: 'Teleportace', icon: '🧭' },
  residence: { label: 'Residence', icon: '⌂' },
  economy: { label: 'Ekonomika', icon: '◈' },
  utility: { label: 'Utility', icon: '⚙' }
};
const TASK_ICONS = {
  BREAK_BLOCK: '⛏', FISH_CAUGHT: '🎣', KILL_MOB: '⚔', CRAFT_ITEM: '🛠',
  VOTE: '✦', JOBS_ACTION: '💎'
};

async function init() {
  try {
    const response = await fetch('data/catalog.json');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    state.catalog = await response.json();
    $('#balance').textContent = DEMO_PROFILE.balance.toLocaleString('cs-CZ');
    renderCategories();
    bindControls();
    render();
  } catch (error) {
    console.error('WarriorLand catalogue failed to load:', error);
    $('#cards').innerHTML = '<div class="empty-state">Katalog se nepodařilo načíst. Otevři web přes lokální HTTP server, ne přímo jako file://.</div>';
  }
}

function bindControls() {
  $('#search').addEventListener('input', () => { state.page = 0; render(); });
  $('#sort').addEventListener('change', () => { state.page = 0; render(); });
  document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => {
    state.view = button.dataset.view;
    state.page = 0;
    document.querySelectorAll('[data-view]').forEach(tab => {
      const active = tab === button;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
    });
    state.filter = 'all';
    updateFilterButtons();
    render();
  }));
  document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
    state.filter = button.dataset.filter;
    state.page = 0;
    updateFilterButtons();
    render();
  }));
  $('#prev').addEventListener('click', () => { if (state.page > 0) { state.page--; render(); } });
  $('#next').addEventListener('click', () => { state.page++; render(); });
  $('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('mobile-open'));
  document.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault(); $('#search').focus();
    }
    if (event.key === 'Escape') { $('#search').blur(); $('#sidebar').classList.remove('mobile-open'); }
  });
}

function renderCategories() {
  const counts = { all: state.catalog.unlocks.length };
  for (const item of state.catalog.unlocks) counts[item.category] = (counts[item.category] || 0) + 1;
  $('#categories').innerHTML = Object.entries(CATEGORY_META).map(([id, meta]) => `
    <button class="category ${state.category === id ? 'active' : ''}" data-category="${id}" aria-pressed="${state.category === id}">
      <span class="ico">${meta.icon}</span><span>${meta.label}</span><span class="count">${counts[id] || 0}</span>
    </button>`).join('');
  document.querySelectorAll('[data-category]').forEach(button => button.addEventListener('click', () => {
    state.category = button.dataset.category;
    state.page = 0;
    renderCategories(); render();
    $('#sidebar').classList.remove('mobile-open');
  }));
}

function taskProgress(item, task) {
  const target = Math.max(1, Number(task.amount || 1));
  const raw = Number(DEMO_PROFILE.taskProgress[`${item.id}:${task.id}`] ?? 0);
  return { current: Math.min(raw, target), target };
}

function getStatus(item) {
  if (DEMO_PROFILE.owned.has(item.id)) return 'owned';
  if (Array.isArray(item.requiredPlugins) && item.requiredPlugins.length) return 'unavailable';
  const tasks = item.tasks || [];
  if (tasks.length && tasks.every(task => { const progress = taskProgress(item, task); return progress.current >= progress.target; })) return 'ready';
  return 'locked';
}

function getFilteredItems() {
  const query = $('#search').value.trim().toLocaleLowerCase('cs');
  let items = state.catalog.unlocks.filter(item => {
    const categoryMatch = state.category === 'all' || item.category === state.category;
    const status = getStatus(item);
    const filterMatch = state.filter === 'all' || state.filter === status || (state.filter === 'locked' && status === 'locked');
    const text = [item.name, item.id, item.description, ...(item.commands || []), ...(item.requiredPlugins || [])].join(' ').toLocaleLowerCase('cs');
    const searchMatch = !query || text.includes(query);
    const mineMatch = state.view !== 'mine' || status === 'owned';
    return categoryMatch && filterMatch && searchMatch && mineMatch;
  });
  const sort = $('#sort').value;
  if (sort === 'price-asc') items.sort((a, b) => a.cost - b.cost || a.name.localeCompare(b.name, 'cs'));
  if (sort === 'price-desc') items.sort((a, b) => b.cost - a.cost || a.name.localeCompare(b.name, 'cs'));
  if (sort === 'name') items.sort((a, b) => a.name.localeCompare(b.name, 'cs'));
  return items;
}

function render() {
  const items = getFilteredItems();
  const pages = Math.max(1, Math.ceil(items.length / state.pageSize));
  state.page = Math.min(state.page, pages - 1);
  const visible = items.slice(state.page * state.pageSize, (state.page + 1) * state.pageSize);
  const tasksMode = state.view === 'tasks';
  $('#cards').hidden = tasksMode;
  $('#taskList').hidden = !tasksMode;
  $('#filterRow').hidden = tasksMode;
  $('.pagination').hidden = tasksMode;
  $('#viewTitle').textContent = state.view === 'mine' ? 'Moje příkazy' : state.view === 'tasks' ? 'Tvoje úkoly' : (state.category === 'all' ? 'Všechny příkazy' : CATEGORY_META[state.category].label);
  $('#viewSubtitle').textContent = state.view === 'mine' ? 'Přehled příkazů označených jako odemčené.' : state.view === 'tasks' ? 'Úkoly, které jsou součástí odemykání příkazů.' : 'Prozkoumej katalog a vyber si, co chceš odemknout.';
  $('#catalogCount').textContent = state.view === 'tasks' ? String(countTasks()) : String(items.length);
  $('#resultCount').textContent = `${items.length} výsledků`;
  $('#page-label').textContent = `STRÁNKA ${state.page + 1} / ${pages}`;
  $('#prev').disabled = state.page === 0;
  $('#next').disabled = state.page >= pages - 1;
  if (tasksMode) { renderTasks(); renderDetail(); return; }
  $('#cards').innerHTML = visible.length ? visible.map(renderCard).join('') : emptyMessage();
  $('#cards').querySelectorAll('[data-id]').forEach(card => card.addEventListener('click', () => {
    state.selectedId = card.dataset.id;
    render();
  }));
  if (!visible.some(item => item.id === state.selectedId)) state.selectedId = visible[0]?.id || null;
  $('#cards').querySelectorAll('[data-id]').forEach(card => card.classList.toggle('selected', card.dataset.id === state.selectedId));
  renderDetail();
}

function renderCard(item) {
  const status = getStatus(item);
  const command = item.commands?.[0] || item.id;
  const stateText = status === 'owned' ? '✓ ODEMČENO' : status === 'unavailable' ? '⚠ ZÁVISLOST CHYBÍ' : `<span class="mini-coin">◉</span> ${item.cost} BODŮ`;
  const statusIcon = status === 'owned' ? 'unlocked' : status === 'unavailable' ? 'unavailable' : status === 'ready' ? 'ready' : 'locked';
  return `<button class="command-card ${status} ${state.selectedId === item.id ? 'selected' : ''}" data-id="${escapeAttr(item.id)}" aria-pressed="${state.selectedId === item.id}">
    <span class="card-topline"><span class="card-id">WL / ${escapeHtml(item.id.toUpperCase())}</span><i class="card-status-dot"></i></span>
    <img class="item-icon" src="assets/command-icons/${encodeURIComponent(item.id)}_${statusIcon}.png" alt="" loading="lazy" onerror="this.onerror=null;this.src='assets/command-icons/${encodeURIComponent(item.id)}.png'">
    <strong>/${escapeHtml(command)}</strong>
    <p>${escapeHtml(item.description || item.name)}</p>
    <span class="state ${status}">${stateText}</span>
  </button>`;
}

function renderDetail() {
  const item = state.catalog.unlocks.find(entry => entry.id === state.selectedId);
  if (!item) {
    $('#detail').innerHTML = '<div class="detail-empty"><span>✧</span><b>Nic k zobrazení</b><small>Uprav hledání nebo vyber jinou kategorii příkazů.</small></div>';
    return;
  }
  const status = getStatus(item);
  const category = CATEGORY_META[item.category]?.label || item.category;
  const aliases = (item.commands || []).slice(1).map(command => `/${command}`).join(', ') || 'Žádné';
  const requirements = item.requiredPlugins?.length ? item.requiredPlugins.join(', ') : 'Žádné';
  const tasks = item.tasks || [];
  const stateCopy = status === 'owned' ? ['✓', 'PŘÍKAZ ODEMČEN', 'Tato funkce je v ukázkovém profilu odemčená.'] : status === 'unavailable' ? ['!', 'ZÁVISLOST CHYBÍ', 'Pro tento příkaz je potřeba požadovaný plugin.'] : status === 'ready' ? ['◉', 'PŘIPRAVENO K ODEMKENÍ', 'Požadované úkoly jsou v ukázkovém profilu splněné.'] : ['⌑', 'PŘÍKAZ ZAMČEN', 'Splň požadované úkoly a odemkni příkaz za body.'];
  const detailIconState = status === 'owned' ? 'unlocked' : status === 'unavailable' ? 'unavailable' : status === 'ready' ? 'ready' : 'locked';
  $('#detail').innerHTML = `
    <div class="detail-top">
      <div class="detail-icon-wrap"><img class="detail-icon" src="assets/command-icons/${escapeAttr(item.id)}_${detailIconState}.png" alt="" onerror="this.onerror=null;this.src='assets/command-icons/${escapeAttr(item.id)}.png'"></div>
      <div class="detail-title"><h2>/${escapeHtml(item.commands?.[0] || item.id)}</h2><span class="pill">⚙ ${escapeHtml(category)}</span></div>
    </div>
    <p class="description">${escapeHtml(item.description || item.name)}</p>
    <div class="info-row"><span class="info-icon">↗</span><span class="label">Alias</span><strong>${escapeHtml(aliases)}</strong></div>
    <div class="info-row"><span class="info-icon">✣</span><span class="label">Požadované pluginy</span><strong>${escapeHtml(requirements)}</strong></div>
    <div class="info-row"><span class="info-icon">◉</span><span class="label">Cena</span><strong class="gold">${Number(item.cost).toLocaleString('cs-CZ')} bodů</strong></div>
    <div class="info-row"><span class="info-icon">◈</span><span class="label">Odměna za úkoly</span><strong class="gold">${Number(item.taskReward || 0).toLocaleString('cs-CZ')} bodů</strong></div>
    <div class="tasks">
      <div class="tasks-head"><h3>POŽADOVANÉ ÚKOLY (${tasks.length})</h3><span>POSTUP HRÁČE · DEMO</span></div>
      ${tasks.length ? tasks.map(task => renderTaskProgress(item, task)).join('') : '<div class="task"><span class="task-icon">✦</span><span class="task-name">Tento příkaz nemá dodatečné úkoly.</span></div>'}
    </div>
    <div class="detail-state ${status}"><span class="state-symbol">${stateCopy[0]}</span><div><strong>${stateCopy[1]}</strong><small>${stateCopy[2]}</small></div></div>
    <div class="detail-action"><button type="button" disabled>${status === 'owned' ? '✓ PŘÍKAZ JE ODEMČENÝ' : status === 'unavailable' ? 'ZÁVISLOST NENÍ DOSTUPNÁ' : status === 'ready' ? `✦ PŘIPRAVENO · ${item.cost} BODŮ` : `🔒 ODEMKNOUT ZA ${item.cost} BODŮ`}</button><small>Nákup se aktivuje po napojení webu na zabezpečené API serveru. Tato ukázka nic nestrhává.</small></div>`;
}

function renderTaskProgress(item, task) {
  const { current, target } = taskProgress(item, task);
  const percent = Math.round((current / target) * 100);
  return `<div class="task"><span class="task-icon">${TASK_ICONS[task.type] || '◆'}</span><span class="task-name">${escapeHtml(task.description || task.name || task.type || 'Úkol')}</span><span class="progress"><i style="width:${percent}%"></i></span><small>${current} / ${target}</small></div>`;
}

function renderTasks() {
  const query = $('#search').value.trim().toLocaleLowerCase('cs');
  const unlocks = state.catalog.unlocks.filter(unlock => {
    const categoryMatch = state.category === 'all' || unlock.category === state.category;
    const searchable = [unlock.name, unlock.id, ...(unlock.commands || []), ...(unlock.tasks || []).map(task => task.description || task.type)].join(' ').toLocaleLowerCase('cs');
    return categoryMatch && (!query || searchable.includes(query));
  });
  const entries = [];
  for (const unlock of unlocks) {
    for (const task of unlock.tasks || []) {
      const { current, target } = taskProgress(unlock, task);
      entries.push({ unlock, task, target, current });
    }
  }
  const unique = new Map();
  entries.forEach(entry => {
    const key = `${entry.task.id}:${entry.task.type}:${entry.task.amount}:${entry.task.description}`;
    if (!unique.has(key)) unique.set(key, entry);
  });
  const list = [...unique.values()];
  $('#taskList').innerHTML = list.length ? list.map(({unlock, task, target, current}) => {
    const percent = Math.round(current / target * 100);
    return `<article class="task-entry"><span class="task-large-icon">${TASK_ICONS[task.type] || '◆'}</span><div><b>${escapeHtml(task.description || task.name || task.type)}</b><p>Odemčení: /${escapeHtml(unlock.commands?.[0] || unlock.id)}</p></div><span class="task-amount">${percent === 100 ? 'SPLNĚNO' : `${percent} %`}</span><div class="task-full-progress"><span class="progress"><i style="width:${percent}%"></i></span><small>${current} / ${target}</small></div></article>`;
  }).join('') : '<div class="empty-state">V katalogu zatím nejsou definované žádné úkoly.</div>';
}

function countTasks() { return state.catalog.unlocks.filter(item => state.category === 'all' || item.category === state.category).reduce((total, item) => total + (item.tasks?.length || 0), 0); }
function emptyMessage() { return '<div class="empty-state">Žádný příkaz neodpovídá zvoleným filtrům. Zkus jiné hledání nebo kategorii.</div>'; }
function updateFilterButtons() { document.querySelectorAll('[data-filter]').forEach(button => button.classList.toggle('active', button.dataset.filter === state.filter)); }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
function escapeAttr(value) { return escapeHtml(value).replace(/`/g, '&#96;'); }

init();
