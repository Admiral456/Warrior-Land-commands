# WarriorLand Command Unlocks 1.15.8 — GUI a nákupní tok (1.15.8)

## Platforma

Tato verze je **čistý Paper plugin bez klientského módu**. Hlavní GUI a tutorial jsou běžné 54/27slotové inventáře. Volitelný resource pack pouze mění item modely ikon; nemění GUI screen, pozadí inventáře ani zobrazování textů.

## Hlavní katalog

- 54 slotů (6×9), kategorie na levé straně, 12 karet na stránku (4×3), detail, čtyři rychlé nápovědy a spodní navigace.
- Výběr karty naplní pravý detail: hlavní příkaz, aliasy, popis, cenu, úkoly/progres, stav vlastnictví a požadované pluginy.
- Kliknutí na nákup otevře samostatné 27slotové potvrzení. Až potvrzovací kliknutí provede transakci. Storno/zavření body neodečítá.
- Kliknutí a přetažení předmětů do/z vlastního GUI jsou blokovány. Hráč nemůže přes GUI přenášet itemy.

## Tutorial Ano/Ne

Při prvním `/prikazy` se zobrazí 27slotový prompt. Odpověď se ukládá na UUID hráče do `players.yml` (`players.<uuid>.preferences.tutorial-enabled`). Ano otevře šest kroků; Ne otevře katalog. `/prikazy tutorial` průvodce spustí vždy; `/prikazy tutorial reset` smaže uloženou volbu a otevře prompt znovu.

1. Úvod do obchodu.
2. Kategorie.
3. Karty a barvy stavů.
4. Detail, aliasy, pluginy a úkoly.
5. PlayerPoints a dvoufázový nákup.
6. Shrnutí a znovuspuštění návodu.

Pokud `players.yml` nejde uložit, plugin zapíše varování. Návod se i tak otevře, ale volba se nemusí zachovat po restartu.

## Nákup

```text
Otevři /prikazy
  → vyber kategorii
  → vyber položku
  → ověř aliasy, úkoly, cenu a požadované pluginy
  → otevři potvrzení
  → server znovu ověří vlastnictví, požadavky, zůstatek a integrace
  → LuckPerms udělí uzly
  → PlayerPoints odečte cenu
  → vlastnictví se trvale uloží
  → při selhání se spustí kompenzační cesta a diagnostika
```

Server zůstává autoritou pro cenu, úkoly a vlastnictví. V klientovi není žádná vlastní logika, protože klientský mod není součástí tohoto řešení.

## Omezení vzhledu

Standardní Minecraft inventář zobrazuje jeden item v každém slotu a jeho název/lore v tooltipu. Resource pack může dodat vlastní vzhled itemů, ale nedokáže přidat libovolná textová pole, vlastní celoobrazovkové pozadí nebo animované panely. Proto je zde cílem čitelný, tematicky stylizovaný inventář s vlastními ikonami, nikoli tvrzení, že se standardní inventář chová jako klientsky kreslené GUI.


## HUD a resource pack (1.15.8)

- Dokončení úkolu může zobrazit rate-limitovaný action bar s názvem úkolu, aktuálním postupem a osmisegmentovým pruhem. Přepínač `settings.hud-task-progress` je oddělený od title oznámení a lze jej vypnout, pokud action bar využívá jiný plugin.
- Serverový resource pack se přidává přes Paper `Player.addResourcePack` do klientského stacku (nezahazuje packy jiných pluginů) a nabízí se jen při platné HTTPS URL. Stav se páruje podle UUID odvozeného z URL + SHA-1; `SUCCESSFULLY_LOADED` z jiného packu nemůže aktivovat vlastní ikony. Při odmítnutí, chybě, discardu nebo změně URL/hash se pro hráče použijí vanilla ikony, dokud se aktuální pack nepotvrdí.
- Resource-pack acceptance prompt je krátký prostý text nastavitelný přes `settings.resource-pack-prompt`. URL musí být ASCII/RFC 1738 encoded; například znaky s diakritikou v cestě musí být percent-enkódované.


## BossBar HUD bez Fabricu (1.15.8)

Volitelná horní informační lišta je vytvořená standardním Paper `BossBar` s fialovým segmentovým stylem. Každý hráč má vlastní lištu s aktuálním zůstatkem PP, počtem vlastněných funkcí a počtem splněných úkolů; průběh lišty vyjadřuje podíl odemčených funkcí. Lišta se aktualizuje každé 2 sekundy a hned po nákupu/odměně. Plugin nepřepisuje scoreboard třetích stran.

Výchozí zapnutí řídí `settings.hud-status-bar`; hráč může osobní volbu trvale změnit příkazy `/prikazy hud on|off`, případně zobrazit stav příkazem `/prikazy hud status`. Výslovná volba hráče má přednost před globálním výchozím nastavením. Title/sound/particle oznámení a action-bar progress jsou nastavitelné samostatně.


## ItemsAdder texturované pozadí (volitelné)

Pokud je na serveru ItemsAdder, může hlavní 54slotové menu použít `TexturedInventoryWrapper` s glyph `warriorland_unlocks:command_menu_background`. Nastavení `settings.itemsadder-textured-gui` je výchozí `false`, takže plugin zůstává plně funkční bez této závislosti. Obsah se instaluje z `itemsadder-addon/contents/warriorland_unlocks`, načte přes `/iareload` a zahrne do distribuovaného packu přes `/iazip`. Při nekompatibilním API/holderu nebo chybějící font image se automaticky použije vanilla fallback. Tato vrstva upravuje texturu inventáře a mezery; stále nejde o neomezené vlastní celoobrazovkové UI.


## ItemsAdder texture API compatibility (1.15.8)

- The optional textured-inventory wrapper now prefers the public offset-aware `TexturedInventoryWrapper` constructors and keeps legacy signatures as a compatibility fallback.
- `FontImageWrapper.exists()` is checked before opening the menu; missing content falls back to a normal Paper inventory.
- `settings.itemsadder-title-offset` and `settings.itemsadder-texture-offset` are bounded pixel offsets for per-version alignment. Adjust them only after inspecting the menu on a staging server.
