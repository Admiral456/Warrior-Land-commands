# Testovací plán WarriorLand Command Unlocks 1.15.8

## Server-only a tutorial

- [ ] Spusť `python scripts/validate_project.py` a `python scripts/validate_server_only.py`.
- [ ] Ověř, že ZIP neobsahuje `ClientMod/`, Fabric metadata, `ClientUiBridge` ani plugin-message kanály.
- [ ] Na čistém hráčském UUID spusť `/prikazy`; prompt Ano/Ne se zobrazí právě jednou.
- [ ] Zvol Ano; ověř uložení `players.<uuid>.preferences.tutorial-enabled: true` a projdi všech šest kroků pomocí Zpět, Další, Přeskočit, Zavřít.
- [ ] Restartuj test server; další `/prikazy` prompt znovu neukáže. `/prikazy tutorial` otevře návod znovu.
- [ ] Zvol Ne u nového UUID; volba se uloží jako false a další `/prikazy` otevře katalog přímo.
- [ ] `/prikazy tutorial reset` vymaže preference a při příštím otevření znovu nabídne Ano/Ne.
- [ ] Zkus rychle klikat během tutorialu; itemy se nesmí přesouvat do/ze serverového GUI.

## GUI a funkčnost

- [ ] Hlavní GUI vykreslí 12 karet na stránku bez kolizí; navigace kategorií, stránkování, Moje body a detail fungují.
- [ ] Každá karta zobrazuje příkaz, popis, cenu, stav, progres úkolů a chybějící závislosti.
- [ ] První klik na nákup otevře 27slotové potvrzení; storno a zavření nemění PlayerPoints.
- [ ] Otestuj úspěšný nákup, dvojklik, opakovaný nákup, nedostatek PP, nesplněné úkoly, již vlastněné odemčení a chybějící plugin.
- [ ] Restartuj server a ověř trvalé vlastnictví i postup úkolů.
- [ ] Ověř, že při nedostupném PlayerPoints/LuckPerms nebo poškozeném `players.yml` se plugin chová bezpečně.
- [ ] Ověř příkazové aliasy, namespaced varianty a příkazy poskytované skutečnými verzemi EssentialsX/Residence/SetHome/ChatColor2/MyCommand.

## Volitelný resource pack

- [ ] Ověř strukturu packu a JSON souborů přes `python scripts/validate_server_only.py`.
- [ ] Na testovacím klientovi Minecraft Java 1.21.10 načti `WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip`; ověř zobrazení vlastních ikon.
- [ ] Teprve po úspěšném načtení nastav `settings.use-resource-pack-icons: true`.
- [ ] S packem vypnutým musí GUI používat normální vanilla/ItemsAdder ikony.
- [ ] Bez resource packu při zapnutém přepínači očekávej missing item model; dokumentace musí administrátora varovat.

## Sestavení

- [ ] S JDK 21 a Gradle 9.2.1 spusť `gradle clean test build --warning-mode all`.
- [ ] Ověř vznik `build/libs/WarriorLandCommandUnlocks-1.15.8.jar`.
- [ ] V JARu je `plugin.yml`, `config.yml`, `TutorialHolder.class` a není `ClientUiBridge.class`.
- [ ] Proveď skutečný test na kopii Paper 1.21.10; statická validace není náhradou běžícího serveru.

## Serverový HUD
- [ ] Ověř úspěšný nákup: zobrazí se title oznámení a volitelný zvuk.
- [ ] Dokonči úkol s odměnou a ověř title + zvýšení PlayerPoints pouze po úspěšném uložení markeru.
- [ ] Zkus opakovaně použít zamčený příkaz; HUD varování se nesmí spamovat rychleji než cooldown.
- [ ] Ověř, že při úspěšném nákupu jsou vidět krátké částice kolem hráče a po vypnutí `settings.hud-particles` se nespustí.
- [ ] Nastav `settings.hud-notifications: false` a ověř vypnutí title/sound overlay; s `settings.hud-notification-sounds: false` se mají vypnout pouze zvuky.

## Resource pack 1.15.8

- [ ] S prázdnou `resource-pack-url` nesmí plugin nic automaticky odesílat.
- [ ] Neplatná HTTP URL nebo SHA-1 nesmí spustit distribuci a má vyvolat srozumitelné varování.
- [ ] S platnou HTTPS URL se pack po připojení nabídne s nastaveným volitelným/povinným režimem.
- [ ] Potvrď, že `addResourcePack` vrství pack vedle packů od ItemsAdderu/ostatních pluginů a že reload nepoužívá `clearResourcePacks`.
- [ ] Změň URL/hash při připojeném hráči; starý WarriorLand pack se odebere, nový se nabídne bez odpojení a stará čekající join nabídka se nesmí odeslat.
- [ ] Přepni `resource-pack-force` z false na true; už načtenému hráči se pack znovu nenabízí, ale hráčům bez potvrzeného načtení se nabídne znovu.
- [ ] Po `SUCCESSFULLY_LOADED` se pro hráče používají vlastní item modely; při `DECLINED`, `FAILED_DOWNLOAD` nebo `FAILED_RELOAD` se vrátí vanilla ikony.
- [ ] Zkontrolovat, že hráč, který pack odmítne při `resource-pack-force: false`, může na serveru normálně hrát.
- [ ] V nastavení force režimu se ujisti, že administrátor opravdu chce požadovat resource pack; testuj nejprve na kopii serveru.


### Nové regresní testy 1.15.8

- [ ] Simuluj selhání zápisu preference tutorialu; v paměti se musí obnovit předchozí hodnota.
- [ ] Při prázdné URL musí custom ikony zůstat vypnuté, pokud `allow-unverified-manual-resource-pack-icons` není explicitně `true`.
- [ ] Ověř, že automatická URL aktivuje custom ikony jen po `SUCCESSFULLY_LOADED` pro stejné ID packu.


## BossBar HUD (1.15.8)

- [ ] Ověř, že po přihlášení se zobrazí fialová segmentová BossBar lišta se zůstatkem, počtem odemčení a splněných úkolů.
- [ ] `/prikazy hud off` skryje pouze WarriorLand lištu; `/prikazy hud on` ji obnoví a volba přetrvá restart.
- [ ] `/prikazy hud status` odpovídá skutečnému stavu a `/prikazy admin status` zobrazuje počet aktivních lišt.
- [ ] Nákup a odměna aktualizují hodnoty okamžitě, úkolový action bar je rate-limitovaný a lze jej vypnout.
- [ ] Ověř soužití s pluginem, který vlastní scoreboard/bossbar. WarriorLand nesmí nastavovat ani nahrazovat hráčský scoreboard.
- [ ] Změna `settings.hud-status-bar` přes `/prikazy admin reload` aktualizuje hráče bez explicitní preference; explicitní volba hráče zůstane zachována.


## Rychlá lišta a stavové ikony (1.15.8)

- [ ] Klikni na slot 38 a ověř otevření tutorialu o úkolech.
- [ ] Klikni na slot 39 a ověř bodový přehled; zůstatek musí souhlasit s PlayerPoints.
- [ ] Klikni na slot 40 a ověř otevření vysvětlení stavových barev.
- [ ] Klikni na slot 41 a ověř zapnutí/vypnutí BossBaru, uložení volby a okamžitou změnu ikony.
- [ ] V resource packu ověř všech pět variant karet pro stejné příkazy (odemčeno, připraveno, málo bodů, zamčeno, chybí plugin).
- [ ] Bez resource packu ověř vanilla fallback a bez chybějících textur.


## ItemsAdder GUI skin (volitelně; staging server)

- [ ] Bez ItemsAdderu a s `itemsadder-textured-gui: false` musí `/prikazy` fungovat stejně jako předtím.
- [ ] Nainstaluj `itemsadder-addon/contents/warriorland_unlocks`, spusť `/iareload` a `/iazip`; ověř, že ItemsAdder reportuje `command_menu_background`.
- [ ] Distribuuj kombinovaný ItemsAdder pack a ověř, že klient jej načetl.
- [ ] Nastav `itemsadder-textured-gui: true` a `itemsadder-font-image: 'warriorland_unlocks:command_menu_background'`; otevři hlavní menu a zkontroluj rámování, transparentní sloty a čitelnost karet.
- [ ] Proklikni kategorie, karty, detail, stránkování, body, tutorial i potvrzení nákupu; zkontroluj, že `MenuHolder` zůstává na inventory holderu.
- [ ] Záměrně vypni ItemsAdder nebo přejmenuj font-image ID; plugin musí přejít na vanilla inventář s jedním srozumitelným varováním, nikoli spadnout.
- [ ] Vypni `itemsadder-textured-gui` a znovu ověř fallback bez změn stavu hráče.


### ItemsAdder constructor compatibility (1.15.8)

- [x] JUnit policy tests cover the current offset-aware varargs and single-texture constructor forms plus two legacy fallbacks and rejection of incompatible signatures.
- [ ] On staging with the server's real ItemsAdder version, verify `FontImageWrapper.exists()` for `warriorland_unlocks:command_menu_background`.
- [ ] Inspect the 54-slot GUI, tune `itemsadder-title-offset` / `itemsadder-texture-offset` if needed, and re-test category clicks, page controls, purchase confirmation, and HUD without changing any unrelated resource-pack settings.
- [ ] Confirm the vanilla inventory fallback works when ItemsAdder is disabled or the font image is absent.


## Zdrojový náhled GUI (1.15.8)

- [ ] Spusť `python scripts/render_source_preview.py`; výstupem je `docs/source-preview.png`.
- [ ] Ověř, že náhled používá pořadí položek z `config.yml`, sloty z `MenuLayout.java` a modely z resource packu.
- [ ] Ber jej jako zdrojovou rekonstrukci, nikoli jako náhradu screenshotu ze staging serveru.
