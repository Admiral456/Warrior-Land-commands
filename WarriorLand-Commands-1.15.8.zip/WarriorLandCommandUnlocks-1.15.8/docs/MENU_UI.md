# WarriorLand Command Unlocks — mapa rozhraní (1.15.8)

Tento dokument popisuje skutečné sloty Bukkit/Paper inventáře. Není vyžadován klientský mód.

## Hlavní obchod (54 slotů, 6×9)

```text
Řada 0: [Vše] [Příkazy] [Jak odemykat] [Katalog] [Kategorie] [Návod] [Body] [Vybraná položka] [Příkaz]
Řada 1: [Teleport] [Odděl.] [Karta 1] [Karta 2] [Karta 3] [Karta 4] [Stav] [Příkazy] [Aliasy]
Řada 2: [Residence] [Odděl.] [Karta 5] [Karta 6] [Karta 7] [Karta 8] [Popis] [Úkoly] [Progres]
Řada 3: [Ekonomika] [Odděl.] [Karta 9] [Karta 10] [Karta 11] [Karta 12] [Závislosti] [Cena/stav] [Nákup]
Řada 4: [Utility] [Odděl.] [Úkoly] [PlayerPoints] [Stavy] [Jak koupit] [Závislosti] [Nákupní detail] [Další informace]
Řada 5: [Moje body] [Předchozí] [Kategorie] [Stránka] [Výběr] [Další] [Nápověda] [Stavy] [Zavřít]
```

Přesná mapa je definována v `MenuLayout.java`; JUnit test `MenuLayoutTest` kontroluje, že všechny 54 slotů jsou jedinečně rozděleny mezi kategorie, hlavičku, karty, rychlé nápovědy, detail, oddělovače a navigaci.

## Prompt tutorialu (27 slotů)

- Slot 4: úvod a vysvětlení.
- Slot 11: Ano — uloží volbu a otevře první stránku návodu.
- Slot 15: Ne — uloží volbu a otevře katalog.
- Slot 22: krátký příkazový návod a reset volby.

## Stránky tutorialu (27 slotů)

- Slot 4: číslo/název kroku.
- Slot 11: stručný kontext.
- Slot 13: ilustrační item.
- Slot 15: postupné vysvětlení.
- Slot 18: zpět; slot 22: přeskočit; slot 26: další/dokončit; slot 8: zavřít.

## Potvrzení nákupu (27 slotů)

První akce v detailu pouze otevře potvrzovací inventář. Nákup proběhne až kliknutím na potvrzení. Zavření ani storno nemění zůstatek.

## Volitelný resource pack

Resource pack pro Minecraft Java 1.21.10 dodává 75 vlastních pixelových ikon přes item models. Zapíná se konfigurací `settings.use-resource-pack-icons: true` až poté, co je pack distribuován a načten. Bez něj zůstávají výchozí vanilla/ItemsAdder ikony. Pack nemění obrazovku inventáře ani textový rendering.


## Rychlá lišta (1.15.8)

- Slot 38: úkoly vybraného příkazu; klik otevře krok tutorialu o úkolech.
- Slot 39: zůstatek, body získané z úkolů a utracené body; klik otevře „Moje body“.
- Slot 40: legenda zelené/zlaté/šedé/červené; klik otevře výklad stavů.
- Slot 41: individuální BossBar HUD; klik uloženou volbu přepne a okamžitě překreslí lištu.
- Slot 5 v hlavičce otevře tutorial.

Stavové varianty vlastních ikon fungují pouze tehdy, když hráč načetl nakonfigurovaný resource pack a `settings.use-resource-pack-icons: true`; jinak se bezpečně používají vanilla/ItemsAdder ikony.


## Náhled z kódu a resource packu (1.15.8)

![Source-based GUI preview](source-preview.png)

[Zvětšený detail slotů a skutečného tooltipu](source-preview-detail.png)
[Tooltip s průběhem úkolu (ukázkový stav 0/12)](source-preview-task-progress.png)

`source-preview.png` je sestaven skriptem `scripts/render_source_preview.py`. Skript načítá výchozí katalog z `src/main/resources/config.yml`, pozice z `MenuLayout.java` a skutečné PNG ikony z `resource-pack/assets/warriorland/textures/item/command_icons/`. V ukázce je pro názornost vybrán `/chatcolour`; skutečný stav vlastnictví a postup úkolů se v běžícím pluginu načítá z `players.yml` a PlayerPoints.

**Nejde o snímek běžící hry.** V běžném Paper inventáři nelze mít pod ikonami trvale vykreslené všechny názvy, ceny a popisy jako na referenčním obrázku; název a lore jsou tooltip při najetí. Resource pack změní item ikony, volitelný ItemsAdder skin podklad inventáře. Nezmění standardní rozložení klientské obrazovky.
