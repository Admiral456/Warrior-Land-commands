# WarriorLand Command Unlocks — Web GUI architecture (proposal / implementation plan)

## Decision

The approved direction is a browser-based player interface with a completely new WarriorLand visual/resource asset set. Keep the existing Paper plugin as the authoritative game backend. Do not add Fabric, Forge, a client mod, or a second system that independently owns purchases or unlock state.

The latest available source baseline is **1.15.8** (Paper 1.21.10, Java 21). This milestone adds a first static web UI preview under `web/`; it does not yet claim to provide a live server API or production purchases.

## Target architecture

```text
Player browser (responsive SPA)
  GET /                         static web app
  GET /api/v1/session           linked player + session state
  GET /api/v1/catalog           public catalog and display metadata
  GET /api/v1/me                balance, unlocks, progress, HUD preference
  POST /api/v1/link/complete    redeem one-time in-game link code
  POST /api/v1/purchases        request purchase by unlock ID
  POST /api/v1/preferences/hud  update HUD preference
                 |
                 | HTTPS, same-origin, HttpOnly session cookie
                 v
WarriorLand Paper plugin (authoritative)
  WebApiServer -> WebAuthService -> WebController
                                 -> existing UnlockRegistry
                                 -> existing PlayerDataStore
                                 -> PlayerPointsHook
                                 -> TaskService
                                 -> refactored PurchaseService
                                 -> LuckPermsHook
```

### In-game command contract

| Command | Player-facing behavior |
|---|---|
| `/web register` | Starts first-time Minecraft-account linking and returns a private, single-use pairing code plus the configured HTTPS address. The code expires after 5 minutes. |
| `/web` | Sends a clickable link to the authenticated player's own command catalogue. If not linked, explains `/web register`. |
| `/web open` | Explicit alias for `/web`; opens the same personal catalogue link. |

The server cannot force-launch a browser from Minecraft. The plugin therefore sends a clickable chat component that the player chooses to open. The destination URL is derived from the server's configured public base URL; it must not be hard-coded to an invented domain. The web page resolves the current account from its secure session cookie, never from a UUID supplied by the browser.

### Hosting

- Preferred first deployment: static files served by the plugin's embedded web server, behind HTTPS reverse proxy (Caddy / hosting proxy / Cloudflare Tunnel where permitted).
- Bind the embedded listener to loopback by default, not `0.0.0.0`; only expose it through the HTTPS proxy. Configure host, port, public base URL and allowed origin explicitly.
- If the hosting provider cannot expose a reverse proxy/tunnel, host the static SPA separately and allow exactly one configured HTTPS origin in CORS. Never use wildcard CORS with credentialed sessions.
- No console endpoint, RCON endpoint, arbitrary command endpoint, or administrative control surface is part of this player API.

## Identity and session security

1. Player runs `/web register` while online. This is the only registration/pairing command; the player does not create a second password-based identity.
2. Plugin creates a cryptographically random, single-use pairing code (at least 128 bits of entropy), stores only its hash, binds it to the player's UUID, and expires it after 5 minutes. The code is shown privately to that player and is not written to public chat or logs.
3. Player opens the configured HTTPS web URL and submits the code. Server consumes it atomically; a code cannot be reused or rebound. The web account is thereby linked to the authenticated Minecraft UUID.
4. After successful registration, `/web` (same action as `/web open`) sends a clickable link directly to the player's personal command catalogue. It does not expose UUIDs or put a long-lived bearer token into the URL. The browser receives an opaque random session token in a `Secure; HttpOnly; SameSite=Strict` cookie.
5. If the player has not registered, `/web` explains that `/web register` is required. If a link/session is already active, `/web register` reports that the account is linked and directs the player to `/web`; an intentional re-link/recovery flow must revoke the previous session safely.
6. Sessions expire (suggested 12 hours idle / 7 days absolute), can be revoked on logout or by admin, and are rate-limited per IP and account. A later `/web logout` command may revoke all web sessions for that UUID.
7. Every mutation validates Origin/Host, CSRF protection, session, online player status, request size, and rate limit. Return generic authentication errors; never reveal whether a UUID exists.

## Purchase correctness

- Web UI sends only an `unlockId`; it never sends a price, permission node, balance, task-completion flag, command string, or player UUID as authority.
- Server resolves the current `UnlockDefinition` from `UnlockRegistry`, checks dependency availability, task readiness, current PlayerPoints balance, already-owned state, pending purchase state and LuckPerms result.
- Reuse/refactor the existing `PurchaseService` transaction. The existing save-before-success and refund/permission-cleanup protections must remain the single purchase path for both web and in-game entry points.
- Initial web purchases require the linked player to be online. This avoids ambiguous offline account state and makes the existing PlayerPoints/LuckPerms transaction easier to preserve. Offline purchase support is a later explicit feature, not a shortcut.
- Duplicate requests carry an idempotency key and are rejected/returned as the original result; double-clicks must never double-charge.
- Web API must never execute arbitrary player-provided commands. Unlock grants only the configured permission nodes for the configured definition.

## API contract (v1)

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/session` | Return authenticated player summary or 401 |
| POST | `/api/v1/link/complete` | Redeem one-time pairing code |
| POST | `/api/v1/logout` | Revoke current session |
| GET | `/api/v1/catalog` | Return configured definitions, categories and server availability |
| GET | `/api/v1/me` | Return own balance, unlock IDs, task progress and preferences |
| POST | `/api/v1/purchases` | Body `{ "unlockId": "...", "idempotencyKey": "..." }` |
| PATCH | `/api/v1/preferences/hud` | Body `{ "enabled": true }` |

All API responses use a stable envelope `{ "ok": boolean, "data": ..., "error": { "code": "...", "message": "..." } }`. Do not return LuckPerms internals, file paths, stack traces, secret values, or other players' records.

## Threading and persistence

- HTTP handlers run off the Paper main thread and must not directly call Bukkit APIs.
- Copy/validate request data on the HTTP thread, then dispatch Bukkit-dependent work using the Paper scheduler. Complete the HTTP response asynchronously after the result is available.
- Keep disk writes and existing `PlayerDataStore` durability semantics. Do not block the main server thread on network I/O.
- Use a bounded executor, request timeout, body-size cap and graceful shutdown. Stop accepting requests before plugin services are torn down.
- Use polling initially (2–5 seconds while a page is open). WebSocket/SSE is optional later; it is not required for correctness.

## New visual/resource assets

Create a new, original WarriorLand identity instead of carrying forward the previous placeholder icon set. The current first frontend milestone temporarily reuses the project's present resource-pack icon PNGs to keep all 75 commands illustrated; the replacement art set is not yet complete:

- Visual language: midnight navy / indigo, neon violet borders, restrained cyan highlights, gold currency, green unlocked state, red dependency warning.
- Website asset set: responsive logo, coin token, category glyphs, 75 command icons, and UI status symbols. Use SVG for scalable interface symbols and PNG/WebP for pixel-art item illustrations.
- Minecraft resource pack: Java 1.21.10-compatible item model definitions and original pixel-art command icons; use stable namespaced IDs. The website and Minecraft pack share source artwork where practical, but each output is exported in its correct format.
- Avoid requiring ItemsAdder for the web UI. ItemsAdder can remain an optional legacy in-game integration until the browser UI is fully deployed and the old inventory UI is intentionally retired.
- Generate a manifest and validate every referenced texture/model, dimensions, duplicate IDs, missing files and pack metadata in CI. Publish the website assets and Minecraft resource-pack ZIP as separate artifacts.

## Migration plan

1. **Web preview (completed 2026-10-30):** static responsive SPA is implemented under `web/`; it reads a generated 75-entry catalogue from the authoritative Paper configuration. It includes categories, search, sorting, status filters, pagination, command details, task list and sample profile views. Demo balance and statuses are explicitly placeholders. `scripts/validate_web_preview.py` checks the exported data, source parity, icon files and JavaScript syntax.
2. **Backend foundation:** implement embedded HTTP server, config migration, pairing codes, hashed sessions, API DTOs and tests. Keep it disabled by default until HTTPS/public URL are configured.
3. **Read-only live mode:** connect `/catalog`, `/session`, `/me`; compare API output against existing registry/data store and add integration tests.
4. **Purchase integration:** refactor purchase transaction so inventory and web entry points call one server-authoritative service; test insufficient points, dependency missing, task incomplete, double submit, permission grant failure, save failure and refund.
5. **New art pack:** produce original icon master assets, export web assets and Minecraft pack, validate pack and run client tests on 1.21.10.
6. **Staging and release:** deploy behind HTTPS, test on a copy of the real Paper server, verify backups and rollback, then enable the API in production.

## Acceptance criteria

- Web catalog contains the exact configured 75 unlocks and never hardcodes a second price/catalog source.
- Player A cannot view or mutate Player B's data by changing a UUID, unlock ID, URL or request body.
- No purchase can bypass dependency/task/balance/ownership checks or charge twice.
- HTTP work never blocks the Paper tick thread; malformed requests and server shutdown do not leak threads.
- No web endpoint exposes console/RCON/arbitrary command execution.
- All authenticated traffic uses HTTPS; no production credential or session token is stored in browser localStorage.
- Resource-pack validation passes and a player without the pack receives safe vanilla fallbacks in the legacy in-game menu during migration.
