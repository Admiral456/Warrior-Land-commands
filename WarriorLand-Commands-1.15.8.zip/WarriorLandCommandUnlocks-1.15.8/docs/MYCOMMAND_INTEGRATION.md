# Integrace MyCommand 5.7.4 s WarriorLand Command Unlocks 1.14.9

## Doporučené rozdělení odpovědnosti

MyCommand už je součástí zamýšlené serverové sestavy. Používej ho jako **definici jednoduchých vlastních příkazů** (textové nápovědy, aliasy, neprivilegované zkratky a pohodlné kombinace příkazů). WarriorLand Command Unlocks zůstává **jediným systémem odemykání, úkolů, PlayerPoints a evidence vlastnictví**.

Nekopíruj do MyCommand příkazy `/chatcolour` ani `/nickcolour`: ty má WarriorLand záměrně implementované nativně. `/chatcolour` bezpečně předává volání ChatColor2 a `/nickcolour` validuje barvu i jméno před předáním do EssentialsX. Nedělej ani druhé definice `/workbench`, `/ignore`, `/nick`, `/chatcolor`, `/home` apod.; poskytují je jiné pluginy a dvojitá registrace by vytvořila nejednoznačné chování.

## Povinné podmínky pro příkaz, který bude prodávaný/odemykatelný

1. Definuj ho v `plugins/MyCommand/commands/examples.yml` (nebo v jiném YAML souboru, který MyCommand načítá z této složky).
2. Nastav `register: true`. MyCommand tím zaregistruje skutečný Bukkit příkaz; jeho oficiální dokumentace upozorňuje, že po přidání registrovaného příkazu je potřeba restart serveru.
3. Nastav `permission-required: true` a explicitní `permission-node`.
4. Stejný permission node musí být uveden v `permissions` u odpovídajícího `unlocks.<id>` ve WarriorLand `config.yml`. Pak jej WarriorLand přidělí přes LuckPerms až po ověřeném nákupu. Před nákupem zamčený příkaz blokuje také `CommandGateListener`.
5. Přidej stejný název pod `commands` v odemčení. WarriorLand při startu načítá seznam příkazů a automaticky mapuje dostupné registrované aliasy.
6. Restartuj server a v konzoli zkontroluj, že MyCommand příkaz zaregistroval a WarriorLand jej zahrnul do ochrany. Pak testuj na kopii serveru jako běžný hráč bez OP.

## Příklad 1: definice v MyCommand

Zkopíruj následující blok jako položku v `plugins/MyCommand/commands/examples.yml`:

```yaml
wltips:
  command: /wltips
  type: TEXT
  text:
    - '&5&lWARRIORLAND &8» &dTipy hráče'
    - '&7Plň úkoly, získávej PlayerPoints a odemykej příkazy přes &e/prikazy&7.'
    - '&7V detailu každé funkce najdeš cenu, podmínky a stav.'
  register: true
  command_description: 'Krátké tipy k systému WarriorLand'
  permission-required: true
  permission-node: warriorland.unlocks.custom.wltips
  permission-error: '&cNejdřív si tento příkaz odemkni v &e/prikazy&c.'
```

Toto je pouze šablona, zatím není automaticky přidána do výchozího katalogu 75 položek.

## Příklad 2: odpovídající odemčení

Přidej pod `unlocks:` do `plugins/WarriorLandCommandUnlocks/config.yml` následující sekci. Jde o samostatný příklad; ID `custom_wltips` musí být v celém katalogu jedinečné.

```yaml
  custom_wltips:
    required-plugins:
      - MyCommand
    name: Tipy WarriorLandu
    description: Otevře krátkou nápovědu k serverovým funkcím.
    category: utility
    icon: BOOK
    cost: 25
    task-reward: 5
    commands:
      - wltips
    permissions:
      - warriorland.unlocks.custom.wltips
    tasks:
      - id: craft-torches
        type: CRAFT_ITEM
        amount: 5
        description: Vyrob 5 pochodní
        materials:
          - TORCH
```

Katalog je při startu validován. Nespouštěj nákup, dokud je v konzoli chyba konfigurace nebo příkaz není registrovaný.

## Čemu se při prodejných Custom příkazech vyhnout

Nezpřístupňuj bez dalšího bezpečnostního návrhu příkazy, které spouštějí libovolné `RUN_CONSOLE` / `RUN_AS_OPERATOR`, `ADD_PERMISSION`, `CALL_URL` nebo přijímají od hráče argumenty a skládají z nich privilegovaný příkaz. Taková definice může dát hráči nepřímou cestu k administrátorským akcím. Pro nákup používej jednoduché `TEXT`, bezpečný alias nebo pevně definovanou neprivilegovanou akci; parametry s dopadem na server musí být validované a nikdy nesmějí umožnit hráči dodat vlastní konzolový příkaz.

## Verze a kompatibilita

Dodané `MyCommand.jar` je podle vlastního `plugin.yml` verze **5.7.4** s `api-version: 1.13`; jeho dokumentace uvádí verze Minecraftu včetně 1.21 a 26.1, ale vydání 5.7.4 je datované 4. červencem 2023. Protože cílový server používá Paper 1.21.10, musí se přesná dodaná kopie ověřit restartem i testovacími příkazy na kopii WarriorLandu. WarriorLand má MyCommand jako `softdepend`, aby se příkazová mapa načetla až po něm, pokud se MyCommand úspěšně zapne.

Odkazy: [MyCommand — SpigotMC](https://www.spigotmc.org/resources/mycommand.22272/) · [Konfigurace a příklady — oficiální dokumentace](https://dev.bukkit.org/projects/mycommand/pages/configuration-and-example)
