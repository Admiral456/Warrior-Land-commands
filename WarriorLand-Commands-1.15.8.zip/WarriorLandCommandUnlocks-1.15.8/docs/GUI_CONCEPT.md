# GUI koncept 1.15.8 — čistě Paper

Cíl je co nejčitelnější inventářové rozhraní v tmavém/fialovém stylu, které nevyžaduje klientský mód: 54slotový katalog, 12 karet, levé kategorie, pravý detail, cenu, úkoly a stav. Volitelný resource pack zajišťuje pixel-art ikony příkazů, ale nepřidává vlastní obrazovku ani panely mimo běžný inventář.

Referenční PNG jsou koncepční obrázky, nikoli screenshoty z běžícího Paper GUI. Standardní inventář nemá trvale viditelný text uvnitř slotů; názvy a lore se zobrazují standardně přes item tooltip.


## Zdrojový náhled 1.15.8

`source-preview.png` generuje `scripts/render_source_preview.py` z aktuálního katalogu, 54slotové mapy a reálných ikon resource packu. Vybraným příkladem je `/chatcolour`; jeho cena 110 PP a požadovaný plugin ChatColor2 pocházejí z konfigurace. Průběh `0/12` je pouze demonstrace nového hráče.

Tento náhled je přiblížení rozložení standardního Paper inventáře, nikoli falešný screenshot ze serveru. Bez klientského módu nelze přesně reprodukovat plovoucí karty s nepřetržitě viditelnými texty z reference.
