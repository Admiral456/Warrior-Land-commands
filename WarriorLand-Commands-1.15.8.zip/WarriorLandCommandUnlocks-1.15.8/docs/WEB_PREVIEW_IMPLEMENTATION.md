# WarriorLand Web — first frontend milestone

## Scope completed

This milestone implements the browser UI only, as requested. It does not add or alter Paper commands, pairing, HTTP endpoints, purchases, account storage or server behavior.

### Website

- Responsive browser layout for desktop, tablet and mobile.
- WarriorLand midnight / indigo / violet style, gold currency, neon state accents and Minecraft-world atmosphere background.
- Exact catalog loaded from `web/data/catalog.json` (75 entries; category counts: teleport 11, residence 22, economy 3, utility 39).
- 450 existing pixel-art base and state images synchronized under `web/assets/command-icons/`, so the page can be deployed as a static web folder without reading the Minecraft resource pack at runtime.
- Category navigation, free-text search, sort by cost/name, state filters, 12-card pagination and selectable command detail.
- Katalog, Moje příkazy and Úkoly views.
- Alias list, required plugins, cost, task reward and task progress in the detail panel.

Catalogue and icon export can be regenerated with `python scripts/export_web_catalog.py`; validation is `python scripts/validate_web_preview.py`. The exporter reads the authoritative Paper `config.yml` and Gradle version, and synchronizes generated resource-pack icons.

### Preview-only state

The balance (250), owned commands and task progress are deliberately hard-coded sample data in `web/app.js`. They are clearly labelled DEMO. This is not linked to any player's real data. The purchase control is disabled and shows that server API integration is a later milestone.

### Local preview

From the project root:

```bash
python -m http.server 8080 --directory web
```

Open `http://localhost:8080`. Windows users can double-click `RUN-WEB-PREVIEW.bat`; Linux/macOS users can run `./RUN-WEB-PREVIEW.sh`.

## Verification performed

- `node --check web/app.js` — PASS.
- HTML parser — PASS.
- Catalog count — 75 entries.
- Category counts — 11 / 22 / 3 / 39.
- Required icon files for all 75 IDs (`base`, `locked`, `unlocked`, `unavailable`) — PASS.
- Static server HTTP checks for `index.html`, catalog JSON and a representative PNG — HTTP 200.

A full cross-browser visual acceptance test and integration with the production Minecraft server have not been performed in this milestone.
