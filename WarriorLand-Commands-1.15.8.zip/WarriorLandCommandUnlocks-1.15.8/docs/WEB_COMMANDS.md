# WarriorLand Web — in-game command contract

## Player commands

### `/web register`
Starts secure first-time account linking. Only players can use it. The plugin must generate a cryptographically secure single-use pairing token with at least 128 bits of entropy, bind it to the invoking player's UUID, store only its hash, and expire it after five minutes. Show the token privately to the invoking player with the configured HTTPS web address. Never log the raw token. Repeated registration must not silently create multiple active links or invalidate an existing session without an explicit recovery flow.

### `/web` and `/web open`
Both send a clickable chat link to the player's personal command catalogue. The plugin must require an existing link/session and otherwise tell the player to run `/web register`. Because Minecraft cannot force a browser to open, use an Adventure `ClickEvent.openUrl` component and a clear fallback URL in chat.

## Configuration

Add `settings.web.enabled` (default `false`) and `settings.web.public-url` (default empty). Refuse registration and access links unless enabled and the public URL is a valid HTTPS origin/base URL. Never invent a production domain. Do not accept arbitrary destinations from a player command.

## Security requirements

- One-time token: >=128 bits entropy, short expiry, atomic one-time consume, hash at rest.
- Link is bound to the executing player's UUID, not a typed username.
- No UUID or persistent bearer credential in the URL.
- Session cookie: `Secure; HttpOnly; SameSite=Strict`; store only session hash server-side.
- Rate-limit register attempts and code redemption. Do not disclose whether another UUID is registered.
- No arbitrary command, console, RCON, permission-node or price mutation endpoint.
- Purchase requests must continue through the existing server-side `PurchaseService`.

## Implementation status

This document defines the agreed command behavior. The current web folder is a static, read-only UI preview; no live pairing/API implementation is included yet.
