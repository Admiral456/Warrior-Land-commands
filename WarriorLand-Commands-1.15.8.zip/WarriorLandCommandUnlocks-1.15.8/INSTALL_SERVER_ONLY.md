# Instalace WarriorLand Command Unlocks 1.15.8 — čistě Paper

## 1. Sestavení

Požadavky: JDK 21, Gradle 9.2.1 a přístup k repozitářům Maven pro Paper API.

```bash
python -m pip install PyYAML Pillow
bash scripts/build_release.sh
```

Výstup: `build/libs/WarriorLandCommandUnlocks-1.15.8.jar`. Zdrojový ZIP obsahuje i volitelný resource pack; ten se sestavuje zvlášť do `WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip` (CI jej zveřejní jako samostatný artefakt).

## 2. Instalace pluginu

1. Zkopíruj serverový JAR do složky `plugins/`.
2. Ujisti se, že jsou nainstalované a zapnuté PlayerPoints a LuckPerms.
3. Ověř všechny externí příkazy a permission nodes vůči skutečným verzím EssentialsX, Residence, SetHome, ChatColor2, VotingPlugin, ItemsAdder, Jobs Reborn a MyCommand.
4. Restartuj Paper. Nepoužívej `/reload`.
5. Hráč otevře `/prikazy`; při prvním otevření zvolí Ano/Ne. Volba se uloží do `players.yml`.

## 3. Tutorial

- `/prikazy` — hlavní katalog, při první návštěvě otevře prompt.
- `/prikazy tutorial` — šestistránkový tutorial kdykoli znovu.
- `/prikazy tutorial reset` — vymaže uloženou volbu a zobrazí prompt znovu.
- Ano otevře návod; Ne otevře katalog bez návodu. Volba se ukládá per-player podle UUID. Pokud zápis do `players.yml` selže, plugin zapíše varování a oznámí stav v logu.
- Nativní HUD efekt úspěšného nákupu/odměny používá standardní titul, zvuk a volitelné částice. `settings.hud-task-progress` zapíná rate-limitovaný progress úkolu v action baru; vypni jej, pokud action bar používá jiný plugin.


## 3. Serverový HUD bez módu

- `settings.hud-status-bar: true` zapne fialovou segmentovou BossBar lištu se zůstatkem PlayerPoints, počtem odemčených příkazů a splněných úkolů. Lišta se obnovuje každé dvě sekundy a po nákupu/odměně. Nenahrazuje scoreboard jiného pluginu.
- `/prikazy hud on` zapne lištu a uloží volbu pro hráče; `/prikazy hud off` ji vypne; `/prikazy hud status` zobrazí stav. Volba je uložena podle UUID do `players.yml`. Výslovná preference hráče má přednost před serverovým výchozím nastavením.
- `settings.hud-notifications`, `settings.hud-notification-sounds`, `settings.hud-particles` a `settings.hud-task-progress` ovládají samostatně titulky, zvuky, částice a akční řádek s postupem úkolu. Vypni `hud-task-progress`, pokud akční řádek používá jiný plugin.

## 4. Volitelný resource pack

Pack cílí na Minecraft Java 1.21.10 a obsahuje vlastní ikony příkazů (item modely). Není to klientský mod.

1. Doporučeno: nahraj `WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip` na HTTPS hosting s přímým odkazem. Ruční instalace je také možná, ale plugin bez URL nedokáže ověřit, kdo pack načetl.
2. Ověř, že pack hráči skutečně vidí (např. testovacím příkazem s modelem v inventáři).
3. V `plugins/WarriorLandCommandUnlocks/config.yml` nastav `settings.resource-pack-url`, odpovídající SHA-1 a `settings.use-resource-pack-icons: true`, potom použij `/prikazy admin reload`. Pro ruční pack bez URL zůstávají vanilla ikony aktivní. Výslovné `settings.allow-unverified-manual-resource-pack-icons: true` je nouzový, neověřený režim — server nepozná, kdo má pack skutečně načtený.
4. Pokud někdo resource pack nepoužije, může se mu v kartách při zapnuté volbě zobrazit chybějící model. Proto nech nastavení vypnuté, pokud pack není povinně distribuován.

Resource pack mění jen vlastní ikonky itemů. Paper API `Player.addResourcePack(UUID, url, hash, prompt, force)` jej přidá do vrstveného seznamu packů klienta místo nahrazení již přidaných packů od jiných pluginů. Není možné pomocí něj změnit inventář na volně vykreslované celoobrazovkové UI; pro takový typ GUI by byl nutný klientský mód, který tento serverový projekt záměrně nevyžaduje.

## 5. Ověření po instalaci

- `/prikazy admin status` — PlayerPoints, LuckPerms, katalog, stav nákupů a počet hráčů, kteří načetli přesně aktuální resource pack.
- Zkus prvotní prompt i obě odpovědi, restart serveru a ověř, že se volba opakuje jen po `/prikazy tutorial reset`.
- Projdi všech šest stránek tutorialu a ověř Zpět, Další, Přeskočit a Zavřít.
- Na kopii serveru otestuj nákup, storno, nedostatek bodů, dvojklik, chybějící plugin a přetrvání vlastnictví po restartu.

## Volitelné automatické nabídnutí resource packu

Nahraj `WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip` na HTTPS hosting s přímým odkazem. V `plugins/WarriorLandCommandUnlocks/config.yml` nastav například:

```yaml
settings:
  resource-pack-url: 'https://example.org/packs/WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip'
  resource-pack-sha1: 'VLOZ_40_HEX_ZNAKU_SHA1'
  resource-pack-prompt: 'WarriorLand: vlastní pixelové ikony pro menu příkazů.'
  resource-pack-force: false
  use-resource-pack-icons: true
  allow-unverified-manual-resource-pack-icons: false
```

Hodnotu SHA-1 spočítáš pro ZIP příkazem `sha1sum WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip`. Nahraď ukázkovou URL i hash skutečnými hodnotami. URL musí být HTTPS a ASCII/RFC 1738 encoded; diakritické znaky v cestě nejprve percent-enkóduj. `resource-pack-prompt` je obyčejný krátký text v dialogu Minecraftu a neinterpretuje barvicí kódy. `resource-pack-force: true` použij jen tehdy, pokud chceš balíček povinně vynutit; při `false` mohou hráči nabídku odmítnout a uvidí vanilla ikony.

## Volitelný ItemsAdder skin inventáře

Tento krok není nutný pro fungování pluginu a nevyžaduje klientský mód.

1. Rozbal samostatný `WarriorLandCommandUnlocks-ItemsAdder-Addon-1.15.8.zip` do `plugins/ItemsAdder/` (nebo zkopíruj `itemsadder-addon/contents/warriorland_unlocks` ze zdrojového ZIPu do `plugins/ItemsAdder/contents/`).
2. Spusť `/iareload` a `/iazip` podle dokumentace nainstalované verze ItemsAdderu.
3. Ujisti se, že hráči dostanou kombinovaný ItemsAdder resource pack. Neposílej celý ItemsAdder pack přes WarriorLandův vlastní resource-pack URL, pokud už ho doručuje jiný plugin.
4. Na testovací kopii přidej do `plugins/WarriorLandCommandUnlocks/config.yml`:

   ```yaml
   settings:
     itemsadder-textured-gui: true
     itemsadder-font-image: 'warriorland_unlocks:command_menu_background'
   ```

5. Restartuj server nebo použij podporovaný plugin reload. Ověř `/prikazy`, detail, stránkování, tutorial i potvrzení nákupu. Pokud se API nebo font-image nenačte, plugin zaloguje varování a použije vanilla GUI. Pro vypnutí nastav `itemsadder-textured-gui: false`.

ItemsAdder umí font images používat v GUI, ale přesné vykreslení musíš ověřit s konkrétní verzí ItemsAdderu a jeho kombinovaným resource packem. Viz [ItemsAdder Font Images](https://wiki.itemsadder.com/adding-content/font-images/font-images/) a [GUI backgrounds](https://wiki.itemsadder.com/adding-content/font-images/guis/).

