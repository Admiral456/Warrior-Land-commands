# WarriorLand Command Unlocks — volitelný ItemsAdder GUI skin

Tento doplněk není povinný. Základní Paper inventář, nákupy, úkoly a HUD fungují bez ItemsAdderu i bez klientského módu.

## Instalace

1. Ověř, že na testovacím Paper serveru už běží kompatibilní ItemsAdder.
2. Zkopíruj složku `contents/warriorland_unlocks` do `plugins/ItemsAdder/contents/`.
3. Načti obsah příkazem `/iareload` a znovu sestav kombinovaný resource pack příkazem `/iazip` podle dokumentace tvé verze ItemsAdderu.
4. Doruč ItemsAdder resource pack klientům přes existující serverovou konfiguraci ItemsAdderu. Hráči nepotřebují Fabric ani jiný klientský mód.
5. Ve `plugins/WarriorLandCommandUnlocks/config.yml` zapni:

   ```yaml
   settings:
     itemsadder-textured-gui: true
     itemsadder-font-image: 'warriorland_unlocks:command_menu_background'
     itemsadder-title-offset: 0
     itemsadder-texture-offset: 0
   ```

   Pokud je titul nebo pozadí po načtení posunuté, uprav pouze tyto pixelové offsety a znovu ověř menu na staging serveru. Nejdřív ověř, že `FontImageWrapper.exists()` pro nastavené ID vrací `true`.

6. Restartuj testovací server nebo použij podporovaný reload pluginu. Ověř otevření `/prikazy`, klikání na karty, detail, stránkování a potvrzení nákupu.

## Bezpečný fallback

WarriorLand používá reflexivní napojení na `TexturedInventoryWrapper`, takže ItemsAdder není tvrdou compile-time závislostí. Preferuje aktuální konstruktorové varianty s explicitním `titleOffset` a `textureOffset`, ale podporuje i starší veřejné signatury. Pokud třída API nebo font image chybí, `FontImageWrapper.exists()` vrátí nepravdu nebo výsledek nemá očekávanou velikost/holder, plugin zapíše varování a otevře běžný Paper inventář. `itemsadder-textured-gui` je ve výchozím nastavení `false` — zapni jej až po instalaci obsahu a testu na staging serveru.

Texture má 176×222 px, což je v limitu ItemsAdder/Minecraft 256×256 pro font image. Slotová okna zůstávají průhledná, aby se textury/předměty GUI nepřekrývaly s obrázkem pozadí. Toto je vzhledová vrstva pro normální chest GUI, nikoli klientský mod ani plnohodnotné vlastní rozhraní bez omezení vanilla inventáře.
