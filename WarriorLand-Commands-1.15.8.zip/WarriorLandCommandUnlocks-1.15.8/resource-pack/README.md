# WarriorLand Command Unlocks — volitelný resource pack

Tento pack poskytuje pixelové modely/ikony pro položky katalogu v Java Edition 1.21.10 (pack format 69.0). **Neobsahuje klientský kód a nevyžaduje Fabric, Forge ani jiný mód.**

## Instalace

1. Zabal obsah této složky do ZIPu (CI vytváří `WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip`).
2. Hráči jej načtou v Minecraftu přes Resource Packs, nebo jej administrátor nabídne jako serverový resource pack přes HTTPS.
3. Až bude resource pack načtený, nastav v `plugins/WarriorLandCommandUnlocks/config.yml` `settings.use-resource-pack-icons: true`.
4. Při automatické distribuci nastav HTTPS URL, SHA-1, krátký `resource-pack-prompt` a `resource-pack-force: false`; potom použij bezpečný reload konfigurace.
5. `/prikazy admin status` ukáže, kolik hráčů načetlo přesně pack s aktuální URL/hash konfigurací.

Resource-pack request používá vlastní ID odvozené od URL a SHA-1, takže status eventy jiných resource-pack pluginů se ignorují. Na Paperu se používá `Player.addResourcePack`, který přidává WarriorLand pack do klientského stacku a nenahrazuje packy od ItemsAdderu nebo jiných pluginů. Při změně URL/hash na reloadu plugin odebere jen předchozí WarriorLand pack ID a online hráčům nabídne novou verzi. URL musí být HTTPS a ASCII (mezinárodní cesta potřebuje percent-encoding). Pokud je nastavená automatická `resource-pack-url`, plugin ukáže custom modely jen hráčům, kteří potvrdí načtení aktuálního packu. Při ruční distribuci bez URL plugin nemůže ověřit, kdo má pack opravdu nainstalovaný; zapnutí `use-resource-pack-icons` v tomto režimu předpokládá, že pack mají všichni hráči, jinak se může zobrazit missing model. Proto je volba ve výchozím stavu `false`. Ikony ovlivňují vzhled předmětů v inventáři; **nevytvářejí vlastní celoobrazovkové pozadí, plovoucí karty ani vlastní HUD**. To standardní Paper inventory GUI bez klientského módu neumí.


Bez automatické HTTPS nabídky server neumí spolehlivě zjistit, zda každý klient ručně načetl tento pack. Plugin proto ve výchozím stavu zobrazí vanilla ikony. Pro automatické ověření nakonfiguruj `settings.resource-pack-url` a `settings.resource-pack-sha1`.
