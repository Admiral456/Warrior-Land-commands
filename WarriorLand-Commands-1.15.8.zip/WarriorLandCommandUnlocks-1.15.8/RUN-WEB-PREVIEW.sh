#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
echo "WarriorLand Web Preview: http://127.0.0.1:8080"
python3 -m http.server 8080 --directory web
