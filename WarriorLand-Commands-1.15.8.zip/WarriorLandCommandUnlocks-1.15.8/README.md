# WarriorLand Command Unlocks

## Funkce aktuální verze 1.15.8

**Serverový plugin pro Minecraft Java 1.21.10 / Paper API a Java 21. Bez klientských módů.** Veškerá logika odemykání, úkolů, PlayerPoints, LuckPerms a nákupů běží na serveru. GUI je tvořené běžnými inventáři Paperu; volitelný resource pack mění pouze ikony karet, nepřidává klientský kód a není povinný.

### Náhled podle skutečného zdrojového kódu

![Zdrojová rekonstrukce GUI s ikonami resource packu](docs/source-preview.png)

[Zvětšený výřez inventáře a tooltipu](docs/source-preview-detail.png)
[Náhled detailu úkolu a skutečného průběhu](docs/source-preview-task-progress.png)

V `docs/source-preview.png` je generovaná rekonstrukce z výchozího `config.yml`, skutečné mapy slotů `MenuLayout.java` a ikon z resource packu. Není to screenshot živého serveru; ukazuje reálné omezení Paper inventáře: názvy a lore jednotlivých předmětů se zobrazují až po najetí kurzorem. Ukázkové zůstatky a odemčení v náhledu jsou pouze demo stav, nikoli údaje konkrétního hráče. Náhled odpovídá konfiguraci, kde jsou zapnuté `settings.itemsadder-textured-gui: true` a `settings.use-resource-pack-icons: true`, a hráč pack skutečně načetl. Ve výchozí konfiguraci jsou tyto volby bezpečně vypnuté, dokud správce nenastaví distribuci packu a neinstaluje ItemsAdder obsah. Náhled obnovíš příkazem `python scripts/render_source_preview.py`.

### Samostatný webový katalog (první frontend milník)

Součástí zdrojového projektu je nyní responzivní webové rozhraní v adresáři `web/`. Zobrazuje stejný katalog 75 příkazů, umožňuje hledání, třídění, filtrování, stránkování a prohlížení detailů včetně úkolů. Obsahuje samostatné pohledy Katalog, Moje příkazy a Úkoly. Zůstatek 250 bodů, tři odemčené ukázkové příkazy a postup úkolů jsou pouze demo data; nákupy a přihlášení jsou záměrně vypnuté, dokud nebude hotové zabezpečené serverové API.

Lokální náhled spustíš dvojklikem na `RUN-WEB-PREVIEW.bat` (Windows), případně příkazem `python -m http.server 8080 --directory web` a otevřením `http://localhost:8080`. Podrobnosti jsou v [web/README.md](web/README.md) a [docs/WEB_PREVIEW_IMPLEMENTATION.md](docs/WEB_PREVIEW_IMPLEMENTATION.md).

### Hlavní funkce

- `/prikazy` (aliasy `/odemykani`, `/unlock`, `/odemykat`) otevírá katalog. Při prvním otevření se nabídne inventářová volba **Ano / Ne** pro tutorial. Volba se ukládá do `plugins/WarriorLandCommandUnlocks/players.yml`.
- `/prikazy tutorial` otevře šestistránkový návod v běžném inventáři. `/prikazy tutorial reset` znovu zobrazí volbu Ano/Ne. Tutorial vysvětluje kategorie, karty a stavové barvy, detail, úkoly, body, potvrzení nákupu a chybějící závislosti.
- Nativní Paper HUD bez módu: volitelná fialová segmentová BossBar lišta se zůstatkem PP, počtem odemčených příkazů a dokončených úkolů. `/prikazy hud on|off|status` ovládá trvalou osobní volbu. Lišta nezasahuje do scoreboardu jiných pluginů.
- Nativní HUD oznámení pro odměnu, úspěšný nákup a použití zamčeného příkazu pomocí vanilla title/sound overlay a volitelných částic. Rate-limitovaný action-bar zobrazuje průběh úkolu; `settings.hud-task-progress` jej vypne, aby nekolidoval s jiným action barem.
- Výchozí katalog má 75 definic odemčení a 101 unikátních normalizovaných selektorů v pěti kategoriích. Skutečné aliasy stejné funkce sdílejí jednu platbu.
- 54slotový katalog: kategorie vlevo, 12 karet na stránku, detail a podmínky, spodní rychlá nápověda a stránkování. Samostatné 27slotové potvrzení nákupu.
- Úkoly `BREAK_BLOCK`, `FISH_CAUGHT`, `KILL_MOB`, `CRAFT_ITEM`, `VOTE` a `JOBS_ACTION`, trvalý postup podle UUID a volitelné jednorázové odměny v PlayerPoints.
- Ochrana příkazů a aliasů včetně namespaced variant, administrátorský bypass a bezpečný režim při chybě nutné ekonomické/permission závislosti nebo dat.
- Transakční nákup přes PlayerPoints a LuckPerms, blokování duplicitních nákupů a pokusy o kompenzaci při selhání zápisu/oprávnění.
- Vlastní `/chatcolour` (předává do ChatColor2) a `/nickcolour` (bezpečná cesta přes EssentialsX). Požadované pluginy musí být aktivní; jinak je nákup zablokovaný.
- Volitelné integrace VotingPlugin, ItemsAdder a Jobs Reborn. Příkazy, permission nodes i dostupnost externích funkcí je nutné ověřit podle konkrétních verzí serverových pluginů.
- Integrace MyCommand: příklady jednoduchého vlastního příkazu `wltips`, kde MyCommand a odemčení používají stejný permission node.

### Volitelný ItemsAdder skin inventáře bez módu

Pokud už na WarriorLandu používáš ItemsAdder, přidal jsem samostatný obsahový doplněk `WarriorLandCommandUnlocks-ItemsAdder-Addon-1.15.8.zip`. Definuje texturované pozadí `warriorland_unlocks:command_menu_background` a umožňuje hlavnímu Paper inventáři použít grafickou vrstvu přes ItemsAdder API. Není to povinná závislost a je ve výchozím nastavení vypnutá.
Verze 1.15.8 vybírá moderní `TexturedInventoryWrapper` konstruktor s explicitními pixel offsety, pokud je dostupný, kontroluje existenci glyphu a při chybě zachová vanilla inventář. Zarovnání lze doladit přes `settings.itemsadder-title-offset` a `settings.itemsadder-texture-offset`. Automatický test ItemsAdder runtime nenahrazuje — přesnou polohu je nutné ověřit s verzí ItemsAdder instalovanou na WarriorLandu.

Pro instalaci zkopíruj `contents/warriorland_unlocks` do `plugins/ItemsAdder/contents/`, spusť `/iareload` a `/iazip`, zajisti distribuci kombinovaného resource packu a teprve potom zapni `settings.itemsadder-textured-gui: true`. Pokud API nebo font image chybí, plugin se bezpečně vrátí k běžnému inventáři. ItemsAdder font images lze používat pro GUI a vlastní glyphy ([oficiální dokumentace](https://wiki.itemsadder.com/adding-content/font-images/font-images/), [GUI pozadí](https://wiki.itemsadder.com/adding-content/font-images/guis/)).

Tato vrstva vylepšuje rámečky a mezery bez Fabricu, ale standardní 54slotový inventář stále omezuje trvale viditelný text a rozmístění karet. Pro přesné ověření zarovnání je nutný test s konkrétní verzí ItemsAdderu na staging serveru.

### Vzhled a resource pack

Rychlá spodní lišta v GUI je nyní funkční: Úkoly otevřou příslušný krok tutorialu, Moje body otevře statistiky, Legenda vysvětlí stavové barvy a položka HUD přepíná BossBar. Volitelný resource pack obsahuje navíc samostatné zelené, zlaté, oranžové, šedé a červené varianty ikon podle skutečného stavu odemčení.

Standardní Paper inventář nemůže vykreslit libovolné plovoucí karty, vlastní celoobrazovkové pozadí, trvale viditelný text uvnitř slotu nebo vlastní animovaný HUD tak jako klientský mód. Tento projekt **klientský mód nepoužívá**. Pro nejlepší možný vzhled je k dispozici volitelný resource pack `WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip`, který obsahuje vlastní pixelové ikony příkazů pro item modely. Resource pack mění pouze modely ikon; texty a popisy používají standardní Paper inventář.

Resource pack je standardně vypnutý v konfiguraci. Zapni `settings.use-resource-pack-icons: true` až poté, co pack načteš u hráčů. Pack doporučujeme doručovat přes HTTPS z konfigurace, aby plugin mohl ověřit úspěšné načtení u každého hráče. Pokud jej distribuuješ pouze ručně, plugin neumí načtení ověřit a ve výchozím bezpečném režimu ponechá vanilla ikony. Automatická nabídka používá vlastní stabilní ID packu, kontrolu jeho skutečného výsledku a krátký text v potvrzovacím dialogu. Paper `addResourcePack` přidává pack do stacku klienta, místo aby nahrazoval resource packy jiných pluginů. Při změně URL/hash při reloadu se odstraní jen stará WarriorLand pack ID a nová verze se nabídne i hráčům, kteří už jsou online; opožděná nabídka už nepoužije zastaralou adresu. Stav eventu od cizího resource-pack pluginu se do našeho rozhodování nezapočítá. Nepotřebuje Fabric/Forge ani žádný klientský mod.

Příklad volitelné automatické nabídky v `plugins/WarriorLandCommandUnlocks/config.yml` (URL a SHA-1 nahraď skutečnými hodnotami):

```yaml
settings:
  resource-pack-url: 'https://example.org/packs/WarriorLandCommandUnlocks-ResourcePack-1.15.8.zip'
  resource-pack-sha1: 'VLOZ_40_HEX_ZNAKU_SHA1'
  resource-pack-prompt: 'WarriorLand: vlastní pixelové ikony pro menu příkazů.'
  resource-pack-force: false
  use-resource-pack-icons: true
  allow-unverified-manual-resource-pack-icons: false
  hud-task-progress: true
```

Příkaz `/prikazy admin status` ukazuje, kolik hráčů načetlo resource pack s aktuální URL a hashem. Ikony se při automatické distribuci zapnou jen hráčům, kteří úspěšně načetli právě tento pack; při chybě nebo odmítnutí se vykreslí vanilla ikony.

### Požadavky

- Paper pro Minecraft Java 1.21.10 a Java 21.
- PlayerPoints a LuckPerms pro běžný ekonomický/purchase flow.
- Další pluginy pro příkazy, které mají být odemykány (např. EssentialsX, Residence, ChatColor2, VotingPlugin, ItemsAdder, Jobs Reborn a případně MyCommand).
- Resource pack je volitelný.

### Sestavení

Lokálně můžeš spustit `bash scripts/build_release.sh` (vyžaduje JDK 21, Gradle 9.2.1, Python balíčky PyYAML/Pillow a dostupné Maven repozitáře). Alternativně nahraj zdrojový ZIP do GitHub repozitáře, pushni commit a otevři **Actions → Build WarriorLand Command Unlocks**. CI používá JDK 21 a Gradle 9.2.1, spouští validační skripty i JUnit a ukládá JAR pluginu, ZIP resource packu, volitelný ItemsAdder addon a test reporty.

Lokálně ve složce projektu spusť:

```bash
python -m pip install PyYAML
python scripts/validate_project.py
python scripts/validate_server_only.py
gradle clean test build --warning-mode all
```

Výsledný plugin JAR je `build/libs/WarriorLandCommandUnlocks-1.15.8.jar`. Zdrojový balíček není produkční JAR; JAR je považován za ověřený až po úspěšném sestavení a testu.

### Instalace na Paper

1. Zkopíruj `WarriorLandCommandUnlocks-1.15.8.jar` do `plugins/`.
2. Ověř, že běží PlayerPoints a LuckPerms a že externí příkazy poskytují očekávané pluginy.
3. Restartuj server; nepoužívej `/reload`.
4. Spusť `/prikazy`. Při prvním otevření zvol Ano nebo Ne.
5. Návod znovu spustíš přes `/prikazy tutorial`; novou volbu zobrazíš přes `/prikazy tutorial reset`.
6. Pro ověřenou aktivaci vlastních ikon hostuj ZIP přes přímou HTTPS URL, nastav URL a SHA-1, restartuj/použij reload a zapni `settings.use-resource-pack-icons: true`. Ruční distribuce bez URL vyžaduje explicitní `settings.allow-unverified-manual-resource-pack-icons: true`; tento režim je neověřený a nemůže zaručit, že mají pack načtený všichni hráči.

### Administrace

- `/prikazy body` — skutečný zůstatek PlayerPoints.
- `/prikazy seznam` — výpis odemčení.
- `/prikazy admin status` — stav integrací, konfigurace, nákupů a čekajících kompenzací.
- `/prikazy admin reload` — bezpečný reload konfigurace, pokud neprobíhá nákup/kompenzace.

Výchozí ceny a úkoly jsou konfigurovatelná výchozí nastavení. Před produkčním nasazením ověř všech 75 položek proti reálným příkazům a permission nodes konkrétních instalovaných pluginů.


## Serverový HUD bez klientského módu

Plugin používá běžný Paper/Bukkit `BossBar` jako volitelnou trvalou informační lištu nahoře na obrazovce. Zobrazuje PlayerPoints, počet odemčených příkazů a dokončených úkolů. Lišta nikdy nenahrazuje cizí scoreboard. Hráč ji může přepnout příkazy `/prikazy hud on`, `/prikazy hud off` a zkontrolovat `/prikazy hud status`; volba se ukládá podle UUID do `players.yml`.

HUD efekty používají vanilla title, action bar, zvuky a částice. Nevyžadují Fabric ani jiný klientský mód. Resource pack je volitelný a slouží pouze k vlastním ikonám v inventářovém GUI.
