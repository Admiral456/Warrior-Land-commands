## 1.15.8

- Přidán generátor zdrojového náhledu GUI: čte skutečný `config.yml`, mapu slotů `MenuLayout.java` a ikony z resource packu. Náhled se označuje jako rekonstrukce, nikoli screenshot živého Minecraftu.
- Vylepšena ItemsAdder font-image textura: výraznější fialový rámeček, jemné noční/královské barevné vrstvy a lépe čitelné oddělení slotových oblastí; transparentní okna slotů zůstávají zachována.
- Do validačního průchodu přidána kontrola zdrojového náhledu, používaných modelů a shody rozvržení s 54slotovým inventářem.
- Katalog, ceny, úkoly, oprávnění, HUD, tutorial a nákupní tok zůstávají beze změny. Řešení nadále nevyžaduje klientský mód.

### Web preview milestone (2026-10-30)

- Připraven samostatný responzivní webový katalog WarriorLand v `web/`; desktop, tablet i mobilní rozvržení.
- Web načítá existujících 75 definic z `web/data/catalog.json`; nový paralelní zdroj cen a definic nevzniká.
- Přidána navigace kategorií, hledání, řazení, filtrování podle stavu, stránkování, detail příkazu, aliasy, závislosti a požadované úkoly.
- Přidány pohledy Katalog, Moje příkazy a Úkoly.
- Do webových assetů zkopírováno 450 stavových pixel-art ikon a noční pozadí; web při nasazení nepotřebuje číst soubory mimo složku `web/`.
- Zůstatek, odemčené příkazy a postup úkolů jsou výslovně demo data. Nákup zůstává záměrně vypnutý. Nejsou implementovány registrace, propojení účtů ani API; to přijde až po dokončení webového frontendu.
- Podrobnosti a ověřovací kroky: `docs/WEB_PREVIEW_IMPLEMENTATION.md`.

## 1.15.7
- Opravena kompatibilita ItemsAdder GUI s aktuálním API: nově se preferují dokumentované konstruktorové varianty s `titleOffset` a `textureOffset`; starší veřejné signatury zůstávají podporované jako fallback.
- Před vytvořením inventáře se ověřuje `FontImageWrapper.exists()`. Chybějící glyph/API způsobí srozumitelné varování a bezpečný přechod na vanilla inventář místo pádu menu.
- Přidány konfigurační hodnoty `settings.itemsadder-title-offset` a `settings.itemsadder-texture-offset` pro doladění zarovnání texturovaného inventáře na konkrétní verzi ItemsAdderu; staré konfigurace se doplní bez přepsání administrátorských hodnot.
- Zpřísněn fallback ikon: samotná neexistence listeneru resource packu už není důkaz načtení vlastních modelů. Bez ověření se používají vanilla ikony.
- Přidáno pět JUnit regresních testů výběru ItemsAdder konstruktoru (moderní varargs, moderní single-texture, legacy, texture-only a nepodporované typy).
- Přidána volitelná ItemsAdder texturovaná inventářová vrstva přes `TexturedInventoryWrapper` a `FontImageWrapper`; default je vypnutý a při chybě API/assetu se bezpečně vrací běžné Paper GUI.
- Přibalen samostatný ItemsAdder content addon `warriorland_unlocks:command_menu_background` s průhlednou 176×222 font-image texturou a instalačním návodem.
- Nový generátor i validátor kontrolují rozměry, alfa kanál, namespace a shodu ID glyphu s konfigurací; CI sestaví a publikuje i samostatný ItemsAdder addon ZIP.
- Zachováno Paper-only řešení, 75 odemčení / 101 unikátních selektorů, ceny, úkoly, PlayerPoints/LuckPerms, tutorial a HUD.
- ItemsAdder vrstva je volitelná: musí se nejprve nainstalovat do `plugins/ItemsAdder/contents`, provést `/iareload` a `/iazip`, zajistit distribuci kombinovaného resource packu a až pak povolit v konfiguraci. Runtime zarovnání je třeba ověřit na testovacím serveru.
- Kompletní Gradle/JUnit build a živý Paper/ItemsAdder test zatím nebyly v tomto prostředí provedeny; zdrojové balíčky nejsou vydávány za hotové produkční JARy.
## 1.14.8

- Přidán volitelný osm kroků dlouhý interaktivní tutorial: při prvním otevření vlastního GUI se hráč rozhodne Ano/Ne; preference se uloží lokálně do `config/warriorland_unlocks_client.json`.
- Tutorial pomocí spotlight efektu ztmaví okolí a zvýrazní právě probíranou část: hlavičku/PP, kategorie, barevné karty, hledání/řazení, detail a aliasy, úkoly/progres a potvrzení nákupu. Ovládá se myší i klávesnicí a lze jej kdykoli znovu spustit přes `/prikazy tutorial` nebo tlačítko `?`.
- Přidán jednorázový serverový `tutorialRequested` signál pro explicitní příkaz, vanilla chatový fallback a automatické CI kontroly tutorial kontraktu i geometrie promptu/calloutu.
- Doplňky HUD: jemné pulzující zvýraznění vybrané karty a pohybující se pixelové jiskry v spotlightu; efekt neovlivňuje cenu ani stav příkazu.
- Výchozí katalog, ceny a odměny nebyly měněny.

- Doladěn skutečný klientský GUI layout podle referenčního obrázku: rám zabírá přibližně 90 % šířky a 83 % výšky viewportu, aby zůstala viditelná část herního světa a HUD.
- Kategorie nyní používají přirozené české názvy místo zbytečně velkých verzálek; zůstatek v hlavičce ukazuje čisté číslo jako na předloze a ceny na kartách zobrazují především částku vedle ikony.
- Zvětšeny ikony karet na běžných velikostech GUI a upraven jejich vertikální odstup od názvů a popisů.
- Přidán čitelný prázdný stav pro vyhledávání bez výsledků s tlačítkem pro vymazání filtru nebo návrat ke všem příkazům.
- Během transakce má vybraná karta i detail samostatný modrý stav „NÁKUP SE ZPRACOVÁVÁ“; nákupní akce se zneaktivní a klient neodesílá další navigační mutace, dokud server nákup nevyhodnotí.
- Opraveno obnovení stavu po rychlém odmítnutí nákupu. Server nyní kontroluje rozpracování a čekající kompenzaci oprávnění podle konkrétního hráče, nikoli globálního počtu nákupů na serveru.
- Aktualizovány automatické kontroly rozložení, prázdného výsledku, zámku transakce a bezpečného obnovení stavu.
- Serverová verze 1.14.8, Fabric klient 1.6.0. Kompletní Gradle/JUnit build a živý Paper/Fabric test stále musí proběhnout v CI a testovacím prostředí.

## 1.14.6

- Upraveny breakpointy GUI podle skutečných Minecraft GUI-scaled rozměrů: na běžném 768×512 logickém viewportu zůstává viditelný levý sidebar, katalog 4×3 i pravý detail.
- Přidáno stránkování úkolů v pravém panelu pomocí šipek a kolečka myši; hráč se dostane i k požadavkům nad první dva úkoly.
- Kolečko myši nad katalogem mění stránku a klikatelné tlačítko × v hledání vymaže aktuální filtr.
- Karty příkazů a hlavní CTA používají pixelově zkosené rámečky; stav hover je čitelnější a vybraný příkaz má výraznější zlatý/fialový okraj.
- Hlavička používá novou textově čistou noční panorama texturu vytvořenou z atmosférické hradní ilustrace; text, ceny a stavy zůstávají dynamické.
- Rozšířeny statické UI/protokolové kontroly a model geometrie viewportů, včetně 768×512 a dalších běžných GUI-scaled velikostí.
- Serverový zdroj je 1.14.6; Fabric klientský mod je 1.4.0.

## 1.14.5
- Initial catalog view now prioritizes the 4×3 command-card grid, with no redundant section labels or permanently open search row; search is opened from the header or `/` and still filters server-side.
- Added a dedicated voxel-castle skyline texture in the header, ambient pixel texture for command cards, a live WARRIORLAND wordmark, a points shortcut, and compact search/sort controls.
- Removed the tip box from the left-side art so the castle illustration remains unobstructed; category and detail panels now start closer to the top, improving the resemblance to the approved reference layout.
- Selected cards get a visible violet halo plus gold focus border; owned/ready/unavailable states retain distinct green/gold/red treatments on top of a textured background.
- Client mod bumped to 1.3.0; server/client package versions and CI artifact assertions are synchronized.
- Static validation and Java parsing pass; full Paper/Fabric compilation and in-game visual verification still require CI and a real test client/server.

## 1.14.4
- Přidána serverová ochrana klientského GUI proti zahlcení: per-player token bucket s kapacitou 40 tokenů a průběžným doplňováním během 1 000 ms, striktní UTF-8 dekódování, limit velikosti zprávy a úklid stavu při odpojení.
- Klientské hledání používá debounce 4 herní tick-y místo odeslání každého stisku klávesy zvlášť.
- Doplněno ovládání klávesnicí: Tab/Shift+Tab přes interaktivní prvky, Enter/Space pro aktivaci, šipky pro výběr karet, Escape pro zavření detailu nebo zrušení potvrzení. Fokus má viditelný obrys.
- Přidáno kompaktní rozložení pro menší okna: postranní kategorie se přesunou do voliče, detail se na úzkém nebo nízkém okně otevře jako samostatný pohled, výška karet se počítá podle dostupného místa a kompaktní detail/body/potvrzení zachovají ovládání bez překrývání textu.
- Přidána JUnit sada `ClientActionRateLimiterTest` pro limit, nezávislost hráčů, přesnou hranici okna a čištění stavu.
- Klientský Fabric mod je verzován jako 1.2.0; serverový projekt je 1.14.4.

## 1.14.3
- Přidán volitelný klientský Fabric mod pro Minecraft Java 1.21.10 s vlastním vykreslovaným UI: stálé názvy příkazů, krátké popisy, ceny, stavy, kategorie, stránkování, detailní panel, přehled PlayerPoints a dvoufázové potvrzení.
- Přidán serverový `ClientUiBridge`; klient posílá pouze navigační akce a ID položky. Server zůstává autoritou pro cenu, úkoly, závislosti, vlastnictví, LuckPerms, PlayerPoints a zápis dat.
- `/prikazy` automaticky otevře klientské GUI, pokud klient mod oznámil; hráči bez modu používají kompatibilní záložní Bukkit inventář.
- Obnovení otevřeného GUI po změně postupu / nákupu funguje i pro klientský mod.
- Ověřeny strukturální pravidla YAML/katalogu a mapa 54 slotů serverového fallbacku. Kompletní Gradle/JUnit build a živý Paper + Fabric runtime test vyžadují CI a testovací server; v tomto prostředí nebyly provedeny.

## 1.14.1

- Přepracováno GUI pro přehlednější procházení: z 16 na 12 příkazů na stránku (čtyři příkazy ve třech řadách), zachováno 54slotové inventářové okno.
- Přidány čtyři krátké nápovědné položky pro úkoly, PlayerPoints, stavy a průběh nákupu.
- Názvy karet zobrazují hlavní příkaz; lidský název a popis jsou přesunuté do strukturovaného, zalamovaného tooltipu.
- Zkráceny titulky detailu, sjednoceny stavové popisky a nahrazeny některé fontově citlivé symboly čitelnějším textem.
- Výchozí název GUI zkrácen na `WL • Příkazy`; dokumentace, validační skript, CI a regresní testy aktualizovány na nový layout.
- Tato změna zlepšuje texty a rozložení standardního Bukkit inventory. Pixelově přesný vzhled koncepčního obrázku vyžaduje resource pack/asset pack a není potvrzen jen zdrojovým kódem.
- **Ověření:** strukturální validátor PASS, Java syntax parse PASS a izolovaný smoke test mapy slotů PASS. Gradle/JUnit build s JDK 21 a test na živém Paper serveru nebyly provedeny.

## 1.14.0

- Přidána čistá `RequiredPluginPolicy` se čtyřmi JUnit regresními testy pro prázdné, chybějící a case-insensitive závislosti.
- GUI teď ukazuje i vlastněnou funkci, jejíž povinný plugin později zmizel, jako nedostupnou — samotné vlastnictví se neztrácí.
- Před nákupem se nyní ověřují konfigurované závislosti `required-plugins`; chybějící nebo vypnutý plugin blokuje prodej a je zobrazen v detailu, kartě i potvrzení.
- Výchozí `chatcolour` vyžaduje `ChatColor2` a `nickcolour` vyžaduje `Essentials`. Závislost se kontroluje znovu po asynchronní fázi LuckPerms, ještě před odečtením PlayerPoints; při změně stavu se nově přidaná oprávnění podle možností kompenzují.
- Migrace existujících `config.yml` doplní jen chybějící pole `required-plugins` pro tyto dvě položky a nepřepíše existující ceny, úkoly, oprávnění ani explicitní konfiguraci závislosti.
- Strukturální validátor a konfigurační JUnit test nyní ověřují deklarace povinných pluginů. Automatický JUnit běh ani reálný Paper runtime test v tomto prostředí nebyl dostupný.

## 1.13.2

- Opraven nesoulad mezi verzí zdrojového projektu, plugin metadaty, JUnit testem, README, Custom dokumentací a cestami/artefakty v GitHub Actions. CI i `plugin.yml` teď odvozují a ověřují jednu verzi.
- Test metadat už neobsahuje zastaralé pevné číslo verze: Gradle předává `project.version` do JUnit.
- Strukturální validátor rozšířen o kontrolu jednotnosti verze vydání, CI cest, metadatového testu, kategorie a slotů menu, aby se tento typ chyby zachytil před zabalením.
- ZIP vydání znovu vytvořen z aktuálního pracovního stromu, včetně `docs/MENU_UI.md`, `docs/menu-layout.png` a `scripts/validate_project.py`; byla kontrolována integrita archivu a SHA-256 finálního souboru.
- Statická inspekce dodaného `ChatColor2-1.17.jar` potvrdila identifikátor pluginu `ChatColor2`, deklaraci `/chatcolor`, všech 20 oprávnění použitých u odemčení a větev podpříkazu `gui` v bytecode. Nejde o živý runtime test.
- **Omezení verifikace:** z důvodu dostupné pouze Javy 21, chybějícího Gradlu a nefunkčního DNS pro stažení nástrojů nebylo možné spustit `gradle clean test build`; nebyl vytvořen ověřený plugin JAR ani proveden test na WarriorLandu.

## 1.13.1

- Nákup z inventářového GUI už neproběhne jediným kliknutím na tlačítko v detailu: nově se otevře samostatná 27-slotová obrazovka s cenou, funkcí, aliasy a akcemi Potvrdit / Zrušit / Zavřít. Teprve potvrzení volá stávající `PurchaseService`; ten znovu ověřuje úkoly, saldo a vlastnictví.
- Přidána `docs/MENU_UI.md` a `docs/menu-layout.png`, které mapují skutečné sloty hlavního 54-slotového menu a 27-slotového potvrzení. PNG je schéma, nikoli screenshot běžícího serveru.
- Přidán `scripts/validate_project.py` pro opakovatelnou kontrolu YAML, katalogu, ID, selectorů/aliasů, kategorií, oprávnění, cen, úkolů a registrovaných Custom příkazů.
- Aktualizována verze v testech, dokumentaci a GitHub Actions artefaktu na 1.13.1.
- **Ověření v tomto prostředí:** Python strukturální validátor prošel (75 položek, 101 unikátních selectorů); dodaný `ChatColor2-1.17.jar` má `plugin.yml` s `/chatcolor` a bytecode `ChatColorCommand` potvrzuje zpracování argumentu `gui`. Gradle/JDK 21 build a runtime na Paper serveru zůstávají neprovedené kvůli chybějícímu Gradle/JDK 21 a nedostupné síti.

## 1.13.0

- Výchozí katalog rozšířen z 8 na 75 samostatných odemčení včetně rozsáhlé sekce Residence/resky. Každá cesta `/res <podpříkaz>` a `/residence <podpříkaz>` se porovnává zvlášť; `/res tp` už nesdílí odemčení s `/res list`.
- Přidány migrace, které při upgradu doplní jen chybějící výchozí odemčení a zachovají vlastní ceny, úkoly, zprávy a dříve vytvořená odemčení. Starou kategorii domovů přesunou do teleportace a uvolněný slot použijí pro Residence.
- Přidána vlastní `/chatcolour` jako britsky psaný vstup do nahraného ChatColor2; `/chatcolour` a `/chatcolor` sdílejí jedno odemčení a delegují skutečnou funkci do ChatColor2. Přidáno i oprávnění pro jeho funkci `clear`.
- Přidána vlastní `/nickcolour <barva> <přezdívka>`: ověřuje seznam povolených barev a bezpečný text přezdívky, potom přes EssentialsX uloží barvu přezdívky. Vyžaduje EssentialsX.
- `/workbench`, `/ignore` a `/nick` zahrnuty jako samostatná odemčení s aliasy detekovanými z příkazové mapy, kde jsou k dispozici.
- Doplněny testy selektorů podpříkazů a ochrany vstupu pro barevnou přezdívku.
- **Ověření:** YAML a statické kontroly proběhly lokálně; kompilace Gradlem/JDK 21 a runtime test na Paper serveru nebyly v tomto prostředí provedeny.

## 1.12.8

- Ochrana příkazů nově automaticky rozpoznává registrované aliasy z příkazové mapy Paper/Bukkit, pokud server dovolí její bezpečné přečtení.
- Explicitní `commands` z configu mají prioritu; aliasy společné více odemčením se automaticky nepřiřazují a v konzoli se objeví varování. Mapování aliasů se obnoví i po zapnutí/vypnutí dalších pluginů.
- Přidány regresní testy pro přiřazování jednoznačných aliasů a odmítnutí nejednoznačných aliasů; `/prikazy admin status` ukazuje počet automaticky chráněných aliasů.
- Verze sestavení, CI artefaktu, metadat a instalační dokumentace jsou sjednoceny na `1.12.8`.

# Změny

## 1.12.7
- GUI aktualizace po změně postupu se slučují do jednoho obnovení na dalším ticku; rychlé události už zbytečně neopakují otevírání inventáře.
- Reload konfigurace je zablokovaný, dokud běží nákup nebo čeká kompenzace oprávnění, aby se nezměnila pravidla uprostřed ekonomické transakce.
- Zpráva při odmítnutém reloadu teď popisuje jak neplatnou konfiguraci, tak rozpracované transakce.
- Verze sestavení, CI artefaktu, testů a instalační dokumentace jsou sjednoceny na `1.12.7`.

## 1.12.6
- Opraveno porovnání názvů profesí Jobs Reborn bez ohledu na velikost písmen; úkol s `jobs: ["Miner"]` nyní odpovídá eventu s názvem `MINER`.
- Nastavení admin/bypass permission nyní odmítá prázdné a neplatné/wildcard hodnoty a použije bezpečný výchozí node.
- Doplněny regresní testy pro Jobs názvy a bezpečné vyhodnocení admin/bypass permissions.
- Verze projektu, kontrola plugin metadata, workflow artefaktu a instalační dokumentace jsou sjednoceny na `1.12.6`.

## 1.12.5
- Oddělena a otestována čistá rozhodovací logika zámku příkazů; zamčený příkaz se odmítne i jako namespaced alias a hráč dostane schválenou zprávu „Tenhle příkaz ještě nemáš odemčený“ s cestou do `/prikazy`.
- Doplněny regresní testy pro extrakci názvu příkazu, aliasy menu, fail-closed režim a oprávnění bypass.
- Přísněji se ověřuje struktura konfigurace při reloadu; chybný seznam filtrů nebo chybějící sekce nesmí potichu změnit starou funkční konfiguraci.
- Testovací plán a instalační dokumentace jsou sjednocené s artefaktem `WarriorLandCommandUnlocks-1.12.5.jar`.
- Verze sestavení, metadata pluginu, CI artefaktu a kontroly konfigurace je `1.12.5`.

## 1.12.4
- Zpevněna kontrola ekonomických operací PlayerPoints a kompenzace při chybě nákupu nebo změny LuckPerms oprávnění.
- Doplněna diagnostika rozpracovaných nákupů a čekajících kompenzací do `/prikazy admin status`.
- Vypínání serveru vypíše konkrétní LuckPerms uzly, které se nepodařilo odebrat, namísto tichého zapomenutí problému.
- Výchozí odemčení příkazů jsou rozdělena podle schválené varianty A; pouze skutečné aliasy stejného příkazu sdílejí cenu a úkoly.

## 1.12.3
- Výchozí odemykání respektuje odsouhlasenou variantu A: `/tpa`, `/tpaccept`, `/tpdeny`, `/home` a `/sethome` mají samostatné ceny, úkoly i LuckPerms nodes. Aliasové dvojice `/balance` + `/bal` a `/enderchest` + `/ec` zůstávají pohromadě jako aliasy téhož příkazu.
- `plugin.yml` nyní deklaruje přesné minimum `api-version: '1.21.10'`, aby odpovídalo cílovému serveru a plugin se nenačítal na starším API.
- Kompenzace rozpracovaných oprávnění při vypínání nemaže čekající záznam před potvrzeným odebráním. Při selhání konzole vypíše UUID hráče a konkrétní LuckPerms nodes pro ruční kontrolu.
- Verze projektu, CI JAR artefaktu, kontroly metadat a instalační dokumentace jsou sjednoceny na `1.12.3`.

## 1.12.2
- Dokončení nákupu má přísnější ochranu proti nečekané chybě ve vlákně serveru: transakce v nejasném stavu zablokuje další nákupy, místo aby se předpokládal bezpečný rollback.
- Při kompenzaci LuckPerms zůstane potvrzení oprávnění evidované až do úspěšného odebrání; `/prikazy admin status` ukazuje rozpracované nákupy a čekající kontroly.
- Kredit PlayerPoints je chráněn proti přetečení celočíselného zůstatku; nečíselné, záporné nebo mimo rozsah vrácené saldo selže bezpečně.
- Reload konfigurace odmítne i stav, kdy sekce `unlocks` existuje, ale po validaci nezůstane žádné použitelné odemčení.
- Listener craftingu bezpečně ignoruje událost bez receptu nebo bez platného výsledku.
- Přidány testy pro ochranu kreditu PlayerPoints a fail-closed chování prázdného registru; návod a testovací plán rozšířeny o nové regresní scénáře.
- Verze projektu, CI artefaktu a dokumentace sjednocena na `1.12.2`.

## 1.12.1
- Opravená migrace zprávy pro zamčený příkaz: migrace zpracuje pouze syntakticky platnou konfiguraci s neprázdnou sekcí `unlocks` a použije bezpečný dočasný soubor s atomickým přejmenováním. Při poškozeném YAML zůstane původní soubor zachován pro bezpečný režim.
- Počáteční validace konfigurace nyní lépe odmítá neplatné počty/ceny a nesprávné filtry, aby chybná položka nemohla nečekaně změnit chování úkolu.
- Sjednocena verze sestavení, CI artefaktu, testovacího plánu a instalačního návodu na `1.12.1`.
- Doplněny kontroly pro potvrzení, že výchozí zpráva opravdu říká „Tenhle příkaz ještě nemáš odemčený“ a obsahuje konkrétní label příkazu.

## 1.12.0
- Při použití zamčeného příkazu se hráči zobrazí zpráva „Tenhle příkaz ještě nemáš odemčený“ a odkaz na `/prikazy`; text je konfigurovatelný a při aktualizaci se bezpečně migruje pouze stará výchozí formulace.
- Doplněny robustnější kontroly transakce nákupu, oprávnění LuckPerms, PlayerPoints a trvalého stavu odemčení.
- Přísnější validace konfigurace a filtračních seznamů úkolů; chybná položka zůstává zamčená namísto náhodného počítání aktivit.
- Rozšířeny unit testy a testovací postup pro zamčené příkazy, trvalost dat a integrace VotingPlugin / Jobs Reborn.


## 1.10.0
- Dokončené úkoly mají nově opravnou cestu pro jednorázovou odměnu: pokud PlayerPoints přechodně odmítne připsání a hráč příkaz následně koupí, odměna se znovu zkontroluje po nákupu nebo při dalším přihlášení/otevření menu.
- Opětovné zpracování nevyplacené odměny neposílá znovu oznámení o odemčení a přeskočí úkoly, jejichž odměna už je potvrzená.
- Přidán samostatný test pravidla opakované kontroly odměn.
- Verze projektu, CI artefaktu a dokumentace sjednocena na `1.10.0`.

## 1.9.0
- Při aktualizaci stávající instalace se původní výchozí hláška pro zamčený příkaz automaticky změní na „Tenhle příkaz ještě nemáš odemčený“. Pokud administrátor používá vlastní text, migrace ho zachová.
- Přidány unit testy bezpečné migrace hlášky pro starý výchozí text, chybějící hodnotu i vlastní úpravu.
- Sestavovací workflow a návod používají Gradle 9.8.2.
- Verze projektu, CI JAR artefaktu a dokumentace sjednocena na `1.9.0`.

## 1.8.0
- Zpráva při použití zamčeného příkazu nyní přímo říká „Tenhle příkaz ještě nemáš odemčený“, zobrazuje příkaz a navádí hráče do `/prikazy`. Text lze nadále upravit v `messages.blocked-command`.
- Rozšířen testovací plán o ověření této hlášky pro běžné i namespaced aliasy.
- Verze projektu, CI artefaktu a dokumentace sjednocena na `1.8.0`.

## 1.7.0
- Ochrana celoživotních statistik bodů před přetečením `long`; při extrémních počtech se hodnota bezpečně nasytí na maximum namísto záporného resetu.
- Plugin se načte do bezpečného režimu, pokud chybí PlayerPoints/LuckPerms nebo nelze bezpečně načíst hráčská data; známé uzamčené příkazy tak nejsou uvolněny pouhým vypnutím pluginu.
- Pokud je `config.yml` nečitelný, nouzově se načtou zabudovaná pravidla jen pro zamknutí známých příkazů a konzole upozorní, že vlastní aliasy mohou vyžadovat ruční opravu.
- Přidán unit test saturující aritmetiky celoživotních statistik a doplněn produkční testovací plán bezpečného režimu.
- Verze zdrojového projektu, JAR artefaktu, CI a dokumentace sjednocena na `1.7.0`.

## 1.6.0
- Jobs Reborn `JobsExpGainEvent` se počítá jen při explicitně nezrušené události s konečnou kladnou hodnotou XP; chybějící příznak z bezpečnostních důvodů znamená odmítnutí akce.
- Přidán izolovaný helper a unit testy pro zamezení falešných Jobs odměn.
- Zpřesněna trvalost snapshotů: přeskočený synchronní zápis se nepovažuje za úspěšný, pokud na disku není potvrzená stejně nová nebo novější verze; atomický přesun používá fallback jen při nepodpořeném atomickém přesunu.
- Normalizace příkazů pracuje se všemi typy whitespace, včetně tabulátoru, a blokuje obcházení zámku přes `/ home` nebo namespaced aliasy.
- Výchozí odemčení domova už nepředpokládá nedoložené `homeplugin.*` nodes; výchozí permission nodes jsou pro EssentialsX a zámek vstupu funguje i při handleru bez permission nodes.
- VotingPlugin nyní zkouší získat UUID i přímo z objektu `getPlayer()`, pokud ho daná verze eventu poskytuje.
- Dále zpřesněn nákupní rollback: cena, stav odemčení a nově přidané LuckPerms nodes se při chybě kompenzují odděleně a neúspěšná kompenzace se vypíše do konzole.
- Verze sestavení, GitHub Actions artefaktu a dokumentace sjednocena na `1.6.0`.

## 1.6.0
- Při neúspěšném uložení nákupu se odebrání LuckPerms omezuje na permission nodes nově přidané konkrétním nákupem; předtím existující přímé uzly se zachovají.
- Kompenzace po chybě zápisu vrací cenu a asynchronně odstraňuje přidané uzly; chyby kompenzace jsou zaznamenány jako kritické, aby je šlo ručně prověřit.
- Přidána ochrana pořadí snapshotů `players.yml`, aby starší asynchronní zápis nemohl přepsat novější změny ani po selhání novějšího zápisu.
- Přidán test pořadí snapshotů a zpřesněna validace celých čísel pro `BigInteger` a `BigDecimal`.
- Verze artefaktu a CI byla sladěna na `1.6.0`.

## 1.4.0
- Reload konfigurace validuje surový YAML před aktivací; při poškozeném/neosahujícím `unlocks` souboru zůstává poslední platná konfigurace aktivní.
- Každé odemčení nyní vyžaduje alespoň jeden úkol, cenu a platný LuckPerms permission node. Úkoly vyžadují stabilní ID, typ a pozitivní množství.
- Seznamy `commands`, `materials`, `entities`, `jobs` a `permissions` jsou přísně ověřované; neplatné filtry nemohou omylem rozšířit podmínky úkolu.
- Materiály z namespaced formátu se převedou na kanonické Bukkit názvy pro správné porovnání s událostmi.
- Nákup není potvrzen, pokud se odemčení nepodaří bezpečně uložit; plugin vrátí lokální stav a pokusí se kompenzovat cenu. Při problému s uložením markeru odměny za úkol se plugin pokusí vrátit připsané body.
- PlayerPoints API se ověří při startu, včetně metod pro přidávání i odečítání bodů.
- Přidány testy validace konfiguračních seznamů, map a čísel. CI používá GitHub Actions checkout v7, setup-java v6, upload-artifact v7 a Gradle 9.8.1.

## 1.3.0
- Opravena typová chyba při práci s `LuckPerms.modifyUser`, která mohla zablokovat kompilaci.
- VotingPlugin úkoly započítávají pouze skutečné a nezrušené `PlayerPostVoteEvent`; tento event má vlastní příznaky, které Bukkit `ignoreCancelled` sám nefiltruje.
- Ukládání `players.yml` při chybné syntaxi už nemůže potichu přepsat databázi prázdnými daty: soubor se zazálohuje a plugin se vypne.
- Offline přiřazení hlasů podle jména odmítne nejednoznačná UUID, aby odměna nešla špatnému účtu.
- Po dokončeném nákupu se stav odemčení synchronně zapíše na disk; při chybě LuckPerms se nákup pokusí vrátit body i při synchronní výjimce.
- Ověřování číselných hodnot v konfiguraci je přísnější; desetinné, nečíselné a nepovoleně nízké hodnoty zamknou položku do opravy konfigurace.
- Zůstatek PlayerPoints se načte pouze jednou na vykreslení menu.
- Jednorázová odměna za dokončené úkoly se po připsání do PlayerPoints synchronně zapíše i s ochranným příznakem.
- Creative režim se nepočítá ani do Jobs Reborn úkolů; při odhlášení se vypíší čekající změny.
- Přidána čistá utilita pro validaci názvů příkazů a omezený výpočet postupu plus JUnit testy.
- CI nyní spouští `clean test build` a vytváří artefakt verze 1.3.0.

## 1.2.0
- Přidána volitelná integrace Jobs Reborn přes `JobsExpGainEvent` a nový typ úkolu `JOBS_ACTION`.
- Úkoly Jobs lze omezit na konkrétní interní názvy jobů uvedené v `plugins/Jobs/jobs.yml`.
- Integrace Jobs je nepovinná; plugin funguje i bez Jobs Reborn.
- Zpřesněna validace seznamu jobů u úkolů, aby nevznikaly nefunkční úkoly.
- Chybně nakonfigurované odemčení zůstává registrované a bezpečně zamčené validačním úkolem, místo aby se tiše vyřadilo z kontroly příkazů.
- Omezena zbytečná práce při vykreslení GUI (zůstatek PlayerPoints se pro karty načítá jednou na vykreslení).
- Ukládání hráčských dat je čistě změnové a dávkované; odstraněno periodické přepisování souboru bez změn.

## 1.1.0

- Přidána volitelná podpora ikon ItemsAdder přes `itemsadder:namespace:id` a bezpečné vanilla fallbacky.
- Při události `ItemsAdderLoadDataEvent` se cache ikon invaliduje a otevřená menu se překreslí.
- Po reloadu konfigurace se znovu zaregistrují dostupné volitelné integrace; deaktivovaná integrace VotingPluginu ignoruje příchozí události.
- Menu obnoví platnou kategorii, stránku a výběr i po změně konfigurace.
- Detail úkolu zobrazuje grafický průběh plnění.
- Oznámení o možnosti odemknout se zobrazí i u příkazů bez úkolů.
- Při konfiguraci se odmítají neznámé typy úkolů a neplatné názvy materiálů či entit, aby vznikly méně nedokončitelné konfigurace.
- PlayerPoints mutace jsou volány pouze jednou i při kompatibilitě s případnými API variantami vracejícími `void`.
- Běžné změny stavu se ukládají dávkově pouze při změně; periodické zbytečné přepisování souboru je odstraněno. Synchronní zápis je vyhrazen pro dokončené nákupy, odhlášení s čekajícími změnami a vypnutí pluginu.
- Plugin cílí na Paper/Minecraft 1.21.10; `api-version` používá API řadu `1.21`.

## Stav ověření

YAML konfigurace a statické kontroly jsou ověřeny v dodávacím prostředí. Skutečný Gradle/JDK 21 build a test na běžícím Paper serveru nebylo možné spustit v tomto prostředí; sestavení je připravené přes GitHub Actions.

- Sjednoceno GitHub Actions sestavení na Gradle 9.2.1 a existující major verze akcí, aby workflow nespoléhalo na neověřené číslování.
