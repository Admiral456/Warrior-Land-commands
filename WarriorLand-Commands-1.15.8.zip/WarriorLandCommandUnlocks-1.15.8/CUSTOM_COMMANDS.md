# WarriorLand — Custom příkazy (1.15.8)

Tato verze používá pouze serverový Paper plugin, žádný klientský mód.

## `/chatcolour` a `/chatcolor`

- Odemčení `chatcolour` je jedna placená funkce. Alias `/chatcolor` zajišťuje ChatColor2; WarriorLand registruje `/chatcolour`, aby se registrace nekřížily.
- Vyžaduje aktivní plugin `ChatColor2`. Při jeho nepřítomnosti je nákup blokovaný a vlastní příkaz zobrazí vysvětlení.
- Odemčení nastavuje konkrétní chatcolor permission nodes; nepoužívá široké wildcard oprávnění.

## `/nickcolour <barva> <přezdívka>`

- Vlastní příkaz bezpečně volá EssentialsX nick handler pro povolenou barvu a validovanou přezdívku.
- Vyžaduje aktivní `Essentials`. Bez něj se příkaz neprovede a nákup se zablokuje.
- `/nickcolour` není alias k `/nick`; jde o samostatné odemčení.

## Příkazy od externích pluginů

`/workbench`, `/ignore`, `/nick`, EssentialsX, Residence, SetHome a ostatní definované příkazy neposkytuje samotný WarriorLand. Plugin je zamyká přes jejich permission nodes a vstupní příkazovou kontrolu. Konkrétní verze a uzly oprávnění je nutné ověřit na cílovém serveru.

## MyCommand

Pro jednoduché vlastní příkazy viz `docs/MYCOMMAND_INTEGRATION.md` a příklady v `examples/mycommand/`. Pro každý vlastní příkaz nastav `register: true`, `permission-required: true` a totožný permission node jak v MyCommand, tak v odpovídajícím `unlocks.<id>.permissions`. Neprováděj příkazy s privilegovaným kontextem konzole.

## Tutorial

- `/prikazy` — první otevření se zeptá Ano/Ne, pokud preference ještě neexistuje.
- `/prikazy tutorial` — otevře šestistránkový inventářový návod kdykoli.
- `/prikazy tutorial reset` — vymaže uloženou volbu a nabídne Ano/Ne znovu.

Volba se ukládá do `players.yml` podle UUID, takže funguje bez klientské konfigurace.

## Ověření před produkcí

- Otestuj `/chatcolour` s aktivním ChatColor2 a `/nickcolour` s aktivním EssentialsX.
- Ověř nezávislé uzamčení `/nick`, `/nickcolour` a dalších schválených položek.
- Ověř MyCommand permission node na testovacím serveru.
- Prověř všech 75 definic proti skutečným příkazům a permission uzlům nainstalovaných verzí pluginů.
