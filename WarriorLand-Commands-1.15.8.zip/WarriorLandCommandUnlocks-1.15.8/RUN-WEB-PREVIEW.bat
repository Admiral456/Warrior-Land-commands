@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python nebyl nalezen. Nainstaluj Python 3 a pri instalaci zapni Add Python to PATH.
  pause
  exit /b 1
)
echo Spoustim WarriorLand Web Preview na http://127.0.0.1:8080
start "" cmd /c "timeout /t 2 /nobreak ^>nul ^& start http://127.0.0.1:8080"
python -m http.server 8080 --directory web
pause
