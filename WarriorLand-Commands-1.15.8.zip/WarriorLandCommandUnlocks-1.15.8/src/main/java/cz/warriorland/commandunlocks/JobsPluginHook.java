package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;

/** Optional Jobs Reborn integration. Only positive, non-cancelled Jobs XP events count. */
public final class JobsPluginHook {
    private static final String JOBS_EVENT = "com.gamingmesh.jobs.api.JobsExpGainEvent";

    private final CommandUnlocksPlugin plugin;
    private boolean registered;

    public boolean isRegistered() { return registered; }

    public JobsPluginHook(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @SuppressWarnings("unchecked")
    public void registerIfAvailable() {
        if (registered) return;
        if (!plugin.getConfig().getBoolean("integrations.jobs.enabled", true)) {
            warnIfConfiguredTasksCannotRun("integrace je vypnutá v konfiguraci");
            return;
        }
        Plugin jobs = Bukkit.getPluginManager().getPlugin("Jobs");
        if (jobs == null || !jobs.isEnabled()) {
            plugin.getLogger().info("Jobs Reborn nebyl nalezen; úkoly JOBS_ACTION zůstanou neaktivní.");
            warnIfConfiguredTasksCannotRun("Jobs Reborn není zapnutý");
            return;
        }
        try {
            Class<?> raw = Class.forName(JOBS_EVENT, false, jobs.getClass().getClassLoader());
            if (!Event.class.isAssignableFrom(raw)) throw new IllegalStateException(JOBS_EVENT + " není Bukkit Event.");
            Class<? extends Event> eventClass = (Class<? extends Event>) raw;
            EventExecutor executor = (listener, event) -> onJobsXp(event);
            Bukkit.getPluginManager().registerEvent(eventClass, new JobsListenerMarker(), EventPriority.MONITOR, executor, plugin, true);
            registered = true;
            plugin.getLogger().info("Integrace Jobs Reborn aktivní: úkoly JOBS_ACTION počítají úspěšné akce, které dávají Jobs XP.");
        } catch (ClassNotFoundException exception) {
            plugin.getLogger().warning("Jobs je zapnutý, ale JobsExpGainEvent nebyl nalezen; ověř verzi Jobs Reborn.");
            warnIfConfiguredTasksCannotRun("JobsExpGainEvent nebyl nalezen");
        } catch (Exception | LinkageError exception) {
            plugin.getLogger().warning("Nepodařilo se připojit Jobs Reborn: " + exception.getMessage());
            warnIfConfiguredTasksCannotRun("registrace eventu selhala");
        }
    }

    private void warnIfConfiguredTasksCannotRun(String reason) {
        boolean configured = plugin.unlocks().all().stream()
                .flatMap(definition -> definition.tasks().stream())
                .anyMatch(task -> task.type().equals("JOBS_ACTION"));
        if (configured) plugin.getLogger().warning("Konfigurace obsahuje úkoly JOBS_ACTION, ale " + reason + "; jejich postup se nebude počítat, dokud se integrace neopraví.");
    }

    private void onJobsXp(Event event) {
        if (!plugin.getConfig().getBoolean("integrations.jobs.enabled", true)) return;
        try {
            // JobsExpGainEvent has its own Cancellable state. Do not rely solely on Bukkit's
            // registerEvent(ignoreCancelled=true), because API wrappers may expose cancellation
            // through their own method and silently count denied/rolled-back job actions otherwise.
            Object cancelledValue = invoke(event, "isCancelled");
            if (!(cancelledValue instanceof Boolean cancelled) || cancelled) return;

            Object expValue = invoke(event, "getExp");
            if (!(expValue instanceof Number exp) || !JobsXpEligibility.isCountable(exp, cancelled)) return;

            Object playerValue = invoke(event, "getPlayer");
            if (!(playerValue instanceof OfflinePlayer offlinePlayer)) return;
            UUID playerId = offlinePlayer.getUniqueId();
            if (playerId == null) return;

            Object jobValue = invoke(event, "getJob");
            if (jobValue == null) return;
            Object nameValue = invoke(jobValue, "getName");
            if (!(nameValue instanceof String jobName) || jobName.isBlank()) return;

            Runnable action = () -> {
                Player online = Bukkit.getPlayer(playerId);
                if (online != null && plugin.getConfig().getBoolean("settings.ignore-creative-mode", true)
                        && online.getGameMode() == GameMode.CREATIVE) return;
                plugin.tasks().progress(playerId, online, "JOBS_ACTION", jobName, 1);
            };
            if (event.isAsynchronous()) Bukkit.getScheduler().runTask(plugin, action);
            else action.run();
        } catch (ReflectiveOperationException | LinkageError exception) {
            plugin.getLogger().warning("Jobs XP událost nemá očekávané API; akce nebyla započítána: " + exception.getMessage());
        }
    }

    private Object invoke(Object target, String name) throws ReflectiveOperationException {
        Method method = target.getClass().getMethod(name);
        return method.invoke(target);
    }

    private static final class JobsListenerMarker implements org.bukkit.event.Listener { }
}
