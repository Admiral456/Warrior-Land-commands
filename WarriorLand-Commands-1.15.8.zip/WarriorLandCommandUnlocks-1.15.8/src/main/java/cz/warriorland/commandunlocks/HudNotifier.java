package cz.warriorland.commandunlocks;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Vanilla Paper HUD feedback: boss bar, titles, action bar, sounds and particles. No client mod required. */
public final class HudNotifier {
    private static final long BLOCKED_NOTICE_COOLDOWN_MS = 2_500L;
    private static final long TASK_PROGRESS_COOLDOWN_NANOS = 900_000_000L;
    private static final long STATUS_REFRESH_TICKS = 40L;

    private final CommandUnlocksPlugin plugin;
    private final Map<UUID, Long> lastBlockedNotice = new HashMap<>();
    private final Map<UUID, Long> lastTaskProgressNotice = new HashMap<>();
    private final Map<UUID, BossBar> statusBars = new HashMap<>();
    private BukkitTask statusUpdater;

    public HudNotifier(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    /** Starts the per-player status bar updater. It never replaces the player's scoreboard. */
    public void start() {
        if (statusUpdater != null) statusUpdater.cancel();
        for (Player player : Bukkit.getOnlinePlayers()) refreshStatusBar(player);
        statusUpdater = Bukkit.getScheduler().runTaskTimer(plugin, this::refreshOnlineStatusBars,
                STATUS_REFRESH_TICKS, STATUS_REFRESH_TICKS);
    }

    public boolean statusBarEnabled(UUID playerId) {
        if (playerId == null || plugin.data() == null) return false;
        return HudStatusPolicy.isEnabled(plugin.data().getHudChoice(playerId),
                plugin.getConfig().getBoolean("settings.hud-status-bar", true));
    }

    /** Immediately redraws a player's optional persistent vanilla boss-bar HUD. */
    public void refreshStatusBar(Player player) {
        if (player == null || !player.isOnline() || plugin.data() == null || plugin.unlocks() == null
                || plugin.points() == null || !statusBarEnabled(player.getUniqueId())) {
            if (player != null) hideStatusBar(player.getUniqueId());
            return;
        }

        UUID uuid = player.getUniqueId();
        BossBar bar = statusBars.computeIfAbsent(uuid,
                ignored -> Bukkit.createBossBar("", BarColor.PURPLE, BarStyle.SEGMENTED_12));
        if (!bar.getPlayers().contains(player)) bar.addPlayer(player);
        bar.setColor(BarColor.PURPLE);
        bar.setStyle(BarStyle.SEGMENTED_12);
        bar.setVisible(true);

        int totalUnlocks = plugin.unlocks().all().size();
        int unlocked = 0;
        int totalTasks = 0;
        int completedTasks = 0;
        for (UnlockDefinition definition : plugin.unlocks().all()) {
            if (plugin.data().isUnlocked(uuid, definition.id())) unlocked++;
            for (TaskDefinition task : definition.tasks()) {
                totalTasks++;
                if (HudStatusPolicy.isTaskComplete(plugin.data().getTaskProgress(uuid, definition.id(), task.id()), task.amount())) completedTasks++;
            }
        }
        int balance = plugin.points().balance(uuid);
        String title = plugin.color(HudStatusPolicy.title(balance, unlocked, totalUnlocks, completedTasks, totalTasks));
        if (!title.equals(bar.getTitle())) bar.setTitle(title);
        bar.setProgress(HudStatusPolicy.progress(unlocked, totalUnlocks));
    }

    public void onConfigurationReloaded() {
        refreshOnlineStatusBars();
    }

    public void hideStatusBar(UUID playerId) {
        if (playerId == null) return;
        BossBar bar = statusBars.remove(playerId);
        if (bar != null) {
            bar.removeAll();
            bar.setVisible(false);
        }
    }

    public int statusBarPlayerCount() {
        return statusBars.size();
    }

    private void refreshOnlineStatusBars() {
        for (Player player : Bukkit.getOnlinePlayers()) refreshStatusBar(player);
        // Remove any stale entries if a quit event was missed during an exceptional shutdown/reload.
        Iterator<Map.Entry<UUID, BossBar>> iterator = statusBars.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, BossBar> entry = iterator.next();
            if (Bukkit.getPlayer(entry.getKey()) == null) {
                entry.getValue().removeAll();
                entry.getValue().setVisible(false);
                iterator.remove();
            }
        }
    }

    public void purchaseSucceeded(Player player, UnlockDefinition definition) {
        if (!enabled() || player == null || !player.isOnline() || definition == null) return;
        show(player, "&a&lPŘÍKAZ ODEMČEN", "&f/" + definition.primaryCommand() + " &8• &e-" + definition.cost() + " PP",
                Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        particles(player, true);
        refreshStatusBar(player);
    }

    public void taskReward(Player player, String unlockName, int amount) {
        if (!enabled() || player == null || !player.isOnline()) return;
        show(player, "&6&lÚKOL SPLNĚN", "&f" + safeText(unlockName, 40) + " &8• &e+" + Math.max(0, amount) + " PP",
                Sound.ENTITY_PLAYER_LEVELUP, 0.65f, 1.35f);
        particles(player, false);
        refreshStatusBar(player);
    }

    /** Low-noise action-bar task progress, shared across objectives and rate-limited per player. */
    public void taskProgress(Player player, String taskName, int current, int target) {
        if (!enabled() || !plugin.getConfig().getBoolean("settings.hud-task-progress", true)
                || player == null || !player.isOnline() || target <= 0) return;
        UUID uuid = player.getUniqueId();
        long now = System.nanoTime();
        Long last = lastTaskProgressNotice.get(uuid);
        if (!HudProgressPolicy.shouldNotify(last, now, TASK_PROGRESS_COOLDOWN_NANOS)) return;
        lastTaskProgressNotice.put(uuid, now);
        trimProgressNoticeCache(now);

        int safeTarget = Math.max(1, target);
        int safeCurrent = Math.max(0, Math.min(current, safeTarget));
        int filled = HudProgressPolicy.filledSegments(safeCurrent, safeTarget, 8);
        String progressColor = safeCurrent >= safeTarget ? "&a" : "&d";
        String bar = progressColor + "▰".repeat(filled) + "&8" + "▰".repeat(8 - filled);
        String line = "&5&lÚKOL &8» &f" + safeText(taskName, 24) + " " + progressColor
                + safeCurrent + "&7/&f" + safeTarget + " &8[" + bar + "&8]";
        try {
            player.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(plugin.color(line)));
        } catch (IllegalArgumentException ignored) {
            // A cosmetic action-bar failure must never interrupt task progress or its durable save.
        }
    }

    private void trimProgressNoticeCache(long now) {
        trimCache(lastTaskProgressNotice, now, 60_000_000_000L);
    }

    private void trimBlockedNoticeCache(long nowMillis) {
        trimCache(lastBlockedNotice, nowMillis, 60_000L);
    }

    private void trimCache(Map<UUID, Long> cache, long now, long maxAge) {
        if (cache.size() <= 512) return;
        Iterator<Map.Entry<UUID, Long>> iterator = cache.entrySet().iterator();
        while (iterator.hasNext()) {
            if (now - iterator.next().getValue() > maxAge) iterator.remove();
        }
        while (cache.size() > 512) {
            UUID oldestUuid = null;
            long oldestAt = Long.MAX_VALUE;
            for (Map.Entry<UUID, Long> entry : cache.entrySet()) {
                if (entry.getValue() < oldestAt) {
                    oldestAt = entry.getValue();
                    oldestUuid = entry.getKey();
                }
            }
            if (oldestUuid == null) break;
            cache.remove(oldestUuid);
        }
    }

    public void commandBlocked(Player player, String command) {
        if (!enabled() || player == null || !player.isOnline()) return;
        long now = System.currentTimeMillis();
        UUID uuid = player.getUniqueId();
        Long last = lastBlockedNotice.get(uuid);
        if (last != null && now - last < BLOCKED_NOTICE_COOLDOWN_MS) return;
        lastBlockedNotice.put(uuid, now);
        trimBlockedNoticeCache(now);
        show(player, "&c&lPŘÍKAZ JE ZAMČENÝ", "&f" + safeText(command, 40) + " &8• &dOtevři /prikazy",
                Sound.ENTITY_VILLAGER_NO, 0.5f, 0.9f);
    }

    public void forget(UUID uuid) {
        if (uuid != null) {
            lastBlockedNotice.remove(uuid);
            lastTaskProgressNotice.remove(uuid);
            hideStatusBar(uuid);
        }
    }

    public void shutdown() {
        if (statusUpdater != null) {
            statusUpdater.cancel();
            statusUpdater = null;
        }
        for (BossBar bar : statusBars.values()) {
            bar.removeAll();
            bar.setVisible(false);
        }
        statusBars.clear();
        lastBlockedNotice.clear();
        lastTaskProgressNotice.clear();
    }

    private void particles(Player player, boolean unlocked) {
        if (!plugin.getConfig().getBoolean("settings.hud-particles", true)) return;
        try {
            var center = player.getLocation().add(0.0, 1.0, 0.0);
            player.spawnParticle(unlocked ? Particle.TOTEM_OF_UNDYING : Particle.HAPPY_VILLAGER,
                    center, unlocked ? 20 : 10, 0.35, 0.45, 0.35, 0.02);
            if (unlocked) player.spawnParticle(Particle.END_ROD, center, 8, 0.45, 0.5, 0.45, 0.01);
        } catch (IllegalArgumentException ignored) {
            // Cosmetic particles must not interrupt a committed transaction.
        }
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("settings.hud-notifications", true);
    }

    private void show(Player player, String title, String subtitle, Sound sound, float volume, float pitch) {
        player.sendTitle(plugin.color(title), plugin.color(subtitle), 5, 32, 8);
        if (plugin.getConfig().getBoolean("settings.hud-notification-sounds", true)) {
            try {
                player.playSound(player.getLocation(), sound, volume, pitch);
            } catch (IllegalArgumentException ignored) {
                // If a target server uses a slightly different sound registry, keep the HUD text.
            }
        }
    }

    private String safeText(String value, int maxLength) {
        if (value == null) return "";
        String normalized = value.replaceAll("[\\r\\n\\t§&]", "").trim();
        return normalized.length() <= maxLength ? normalized : normalized.substring(0, maxLength);
    }
}
