package cz.warriorland.commandunlocks;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;

public final class TaskProgressListener implements Listener {
    private final CommandUnlocksPlugin plugin;

    public TaskProgressListener(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (ignorePlayer(player)) return;
        plugin.tasks().progress(player, "BREAK_BLOCK", event.getBlock().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || ignorePlayer(event.getPlayer())) return;
        String caughtMaterial = "";
        Entity caught = event.getCaught();
        if (caught instanceof Item item) {
            ItemStack stack = item.getItemStack();
            Material material = stack.getType();
            if (material != null) caughtMaterial = material.name();
        }
        plugin.tasks().progress(event.getPlayer(), "FISH_CAUGHT", caughtMaterial, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobKill(EntityDeathEvent event) {
        // PvP kills must not count as mob-kill tasks.
        if (event.getEntity() instanceof Player) return;
        Player killer = event.getEntity().getKiller();
        if (killer == null || ignorePlayer(killer)) return;
        plugin.tasks().progress(killer, "KILL_MOB", event.getEntity().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || ignorePlayer(player)) return;
        if (event.getRecipe() == null) return;
        ItemStack result = event.getRecipe().getResult();
        if (result == null || result.getType().isAir()) return;
        plugin.tasks().progress(player, "CRAFT_ITEM", result.getType().name(), Math.max(1, result.getAmount()));
    }

    private boolean ignorePlayer(Player player) {
        return plugin.getConfig().getBoolean("settings.ignore-creative-mode", true)
                && player.getGameMode() == GameMode.CREATIVE;
    }
}
