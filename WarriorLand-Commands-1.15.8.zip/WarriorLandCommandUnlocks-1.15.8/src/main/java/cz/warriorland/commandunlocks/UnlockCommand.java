package cz.warriorland.commandunlocks;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class UnlockCommand implements CommandExecutor, TabCompleter {
    private final CommandUnlocksPlugin plugin;

    public UnlockCommand(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        boolean statusRequest = args.length >= 2 && args[0].equalsIgnoreCase("admin") && args[1].equalsIgnoreCase("status");
        if (plugin.isSafeMode() || plugin.data() == null || plugin.tasks() == null || plugin.menus() == null) {
            if (statusRequest) showStatus(sender);
            else plugin.sendSafeModeMessage(sender);
            return true;
        }
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                plugin.sendMessage(sender, "only-player");
                return true;
            }
            plugin.tasks().checkAllReady(player);
            if (TutorialPromptPolicy.shouldPrompt(plugin.data().getTutorialChoice(player.getUniqueId()))) plugin.menus().openTutorialPrompt(player);
            else plugin.menus().open(player);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "body", "balance" -> {
                if (!(sender instanceof Player player)) plugin.sendMessage(sender, "only-player");
                else plugin.sendMessage(player, "balance", "%balance%", String.valueOf(plugin.points().balance(player.getUniqueId())));
            }
            case "hud" -> handleHud(sender, args);
            case "seznam", "list" -> showList(sender);
            case "hledat", "search", "vyhledat" -> {
                if (!(sender instanceof Player player)) {
                    plugin.sendMessage(sender, "only-player");
                    return true;
                }
                if (args.length < 2) {
                    plugin.menus().beginSearch(player);
                } else {
                    plugin.menus().setSearch(player, String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)));
                }
            }
            case "seradit", "sort" -> {
                if (!(sender instanceof Player player)) {
                    plugin.sendMessage(sender, "only-player");
                    return true;
                }
                if (args.length < 2) plugin.menus().cycleSort(player, null);
                else plugin.menus().setSortMode(player, args[1]);
            }
            case "tutorial", "pruvodce", "průvodce", "navod", "návod" -> {
                if (!(sender instanceof Player player)) {
                    plugin.sendMessage(sender, "only-player");
                    return true;
                }
                if (args.length >= 2 && args[1].equalsIgnoreCase("reset")) {
                    if (!plugin.data().setTutorialChoice(player.getUniqueId(), null)) {
                        plugin.sendMessage(player, "tutorial-reset-failed");
                    } else {
                        plugin.sendMessage(player, "tutorial-reset");
                        plugin.menus().openTutorialPrompt(player);
                    }
                    return true;
                }
                plugin.tasks().checkAllReady(player);
                plugin.menus().openTutorial(player);
            }
            case "help", "napoveda", "nápověda" -> {
                plugin.sendMessage(sender, "help");
                if (sender.hasPermission(plugin.getAdminPermission())) plugin.sendMessage(sender, "admin-help");
            }
            case "admin" -> admin(sender, args);
            default -> {
                if (sender instanceof Player player) plugin.menus().open(player);
                else plugin.sendMessage(sender, "help");
            }
        }
        return true;
    }

    private void handleHud(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.sendMessage(sender, "only-player");
            return;
        }
        if (args.length < 2 || args[1].equalsIgnoreCase("status")) {
            boolean enabled = plugin.hud().statusBarEnabled(player.getUniqueId());
            plugin.sendMessage(player, "hud-status", "%state%", enabled ? "&aZAPNUTÝ" : "&cVYPNUTÝ");
            plugin.sendMessage(player, "hud-usage");
            plugin.hud().refreshStatusBar(player);
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "on", "zapnout", "zapni" -> {
                if (!plugin.data().setHudChoice(player.getUniqueId(), true)) {
                    plugin.sendMessage(player, "hud-preference-save-failed");
                    return;
                }
                plugin.hud().refreshStatusBar(player);
                plugin.sendMessage(player, "hud-enabled");
            }
            case "off", "vypnout", "vypni" -> {
                if (!plugin.data().setHudChoice(player.getUniqueId(), false)) {
                    plugin.sendMessage(player, "hud-preference-save-failed");
                    return;
                }
                plugin.hud().hideStatusBar(player.getUniqueId());
                plugin.sendMessage(player, "hud-disabled");
            }
            default -> {
                plugin.sendMessage(player, "hud-usage");
            }
        }
    }

    private void showList(CommandSender sender) {
        plugin.sendMessage(sender, "list-header");
        if (sender instanceof Player player) plugin.sendMessage(sender, "balance", "%balance%", String.valueOf(plugin.points().balance(player.getUniqueId())));
        for (UnlockDefinition definition : plugin.unlocks().all()) {
            String status;
            if (!(sender instanceof Player player)) status = "&7[ZOBRAZENÍ]";
            else if (plugin.data().isUnlocked(player.getUniqueId(), definition.id())) status = "&a[ODEMČENO]";
            else if (plugin.tasks().requirementsMet(player.getUniqueId(), definition)) status = "&e[PŘIPRAVENO K ODEMČENÍ]";
            else status = "&7[ZAMČENO]";
            String line = plugin.getConfig().getString("messages.list-item", "%status% %name% - %cost% PP")
                    .replace("%status%", status)
                    .replace("%name%", definition.name())
                    .replace("%id%", definition.id())
                    .replace("%description%", definition.description())
                    .replace("%cost%", String.valueOf(definition.cost()))
                    .replace("%command%", "/" + definition.primaryCommand());
            sender.sendMessage(plugin.color(line));
        }
    }

    private void admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission(plugin.getAdminPermission())) {
            plugin.sendMessage(sender, "no-permission");
            return;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("reload")) {
            if (plugin.reloadPlugin()) plugin.sendMessage(sender, "reloaded");
            else plugin.sendMessage(sender, "reload-failed");
            return;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("status")) {
            showStatus(sender);
            return;
        }
        if (args.length >= 2 && (args[1].equalsIgnoreCase("tutorial") || args[1].equalsIgnoreCase("navod") || args[1].equalsIgnoreCase("návod"))) {
            if (!(sender instanceof Player player)) {
                plugin.sendMessage(sender, "only-player");
                return;
            }
            plugin.menus().openAdminTutorial(player, 0);
            return;
        }
        plugin.sendMessage(sender, "admin-help");
    }

    private void showStatus(CommandSender sender) {
        if (!sender.hasPermission(plugin.getAdminPermission())) {
            plugin.sendMessage(sender, "no-permission");
            return;
        }
        sender.sendMessage(plugin.color("&8[&5WarriorLand&8] &d&lStav Command Unlocks"));
        String mode = plugin.isSafeMode() ? "&cBEZPEČNÝ REŽIM" : "&aAKTIVNÍ";
        if (plugin.isSafeMode() && plugin.safeModeReason() != null && !plugin.safeModeReason().isBlank()) {
            mode += " &7(" + plugin.safeModeReason() + ")";
        }
        statusLine(sender, "Režim", mode);
        statusLine(sender, "Pravidla odemčení", plugin.unlocks() == null ? "&cnenačtena"
                : "&e" + plugin.unlocks().all().size() + " položek" + (plugin.isSafeModeUsingBundledRules() ? " &7(zabudovaná nouzová pravidla)" : ""));
        if (plugin.unlocks() != null) {
            statusLine(sender, "Zámek příkazů", "&e" + plugin.unlocks().configuredCommandLabelCount()
                    + " konfigurovaných názvů &7+ &e" + plugin.unlocks().automaticallyProtectedAliasCount() + " automatických aliasů");
        }
        if (plugin.unlocks() != null) {
            long tasks = plugin.unlocks().all().stream().mapToLong(definition -> definition.tasks().size()).sum();
            long invalid = plugin.unlocks().all().stream().filter(definition -> definition.tasks().stream()
                    .anyMatch(task -> task.type().equals("INVALID_CONFIG"))).count();
            statusLine(sender, "Úkoly", "&e" + tasks + " úkolů" + (invalid > 0 ? " &c| " + invalid + " položek blokováno kvůli konfiguraci" : ""));
        }
        if (plugin.unlocks() != null) {
            statusLine(sender, "CommandMap", plugin.unlocks().canInspectCommandRegistration()
                    ? "&aDostupná &7| &e" + plugin.unlocks().registeredCommandLabelCount() + " registrovaných názvů"
                    : "&eNelze automaticky ověřit — spoléhám na konfiguraci");
        }
        statusLine(sender, "PlayerPoints", plugin.points() != null ? "&aAPI připojeno" : "&cnení dostupné");
        statusLine(sender, "LuckPerms", plugin.luckPerms() != null ? "&aAPI připojeno" : "&cnení dostupné");
        statusLine(sender, "Databáze hráčů", plugin.data() != null && plugin.data().isLoaded() ? "&aNačtena" : "&cNení načtena");
        statusLine(sender, "HUD BossBar", plugin.hud() == null ? "&cNeaktivní" : "&e" + plugin.hud().statusBarPlayerCount() + " hráčů s aktivní lištou");
        if (plugin.resourcePackListener() != null) {
            String packState = plugin.resourcePackListener().hasAutomaticDelivery()
                    ? "&aAutomatické HTTPS nabídnutí nastaveno &7| &e" + plugin.resourcePackListener().loadedPlayerCount() + " hráčů načetlo aktuální pack"
                    : "&7Automatická nabídka vypnuta / ruční distribuce";
            statusLine(sender, "Resource pack", packState);
            statusLine(sender, "Vlastní ikony", plugin.getConfig().getBoolean("settings.use-resource-pack-icons", false)
                    ? "&aZapnuté (pro pack-aware hráče)" : "&7Vypnuté — vanilla ikony");
        }
        if (plugin.purchases() != null) {
            int inProgress = plugin.purchases().inProgressCount();
            int unresolved = plugin.purchases().unresolvedPermissionCleanupCount();
            statusLine(sender, "Nákupy", inProgress == 0 ? "&aŽádný rozpracovaný" : "&e" + inProgress + " rozpracovaných");
            statusLine(sender, "Kontrola nákupu / oprávnění", unresolved == 0 ? "&aBez čekajících případů" : "&c" + unresolved + " vyžaduje kontrolu");
        }
        statusLine(sender, "VotingPlugin", plugin.votingPluginHook() != null && plugin.votingPluginHook().isRegistered() ? "&aIntegrace aktivní" : "&7Neaktivní / nedostupný");
        statusLine(sender, "Jobs Reborn", plugin.jobsPluginHook() != null && plugin.jobsPluginHook().isRegistered() ? "&aIntegrace aktivní" : "&7Neaktivní / nedostupný");
        statusLine(sender, "ItemsAdder reload hook", plugin.itemsAdderHook() != null && plugin.itemsAdderHook().isRegistered() ? "&aAktivní" : "&7Neaktivní / nedostupný");
        statusLine(sender, "Texturované GUI", plugin.menus() == null ? "&cNení inicializováno" : plugin.menus().itemsAdderGuiStatus());
        sender.sendMessage(plugin.color("&7Diagnostika: &e/prikazy admin status &8| &7Reload: &e/prikazy admin reload"));
    }

    private void statusLine(CommandSender sender, String label, String value) {
        sender.sendMessage(plugin.color("&8[&5WarriorLand&8] &7" + label + ": " + value));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> suggestions = new ArrayList<>();
        if (args.length == 1) {
            suggestions.addAll(List.of("body", "seznam", "help", "tutorial", "hud", "hledat", "seradit"));
            if (sender.hasPermission(plugin.getAdminPermission())) suggestions.add("admin");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("tutorial") && sender instanceof Player) {
            suggestions.add("reset");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("hud") && sender instanceof Player) {
            suggestions.addAll(List.of("on", "off", "status"));
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("seradit") || args[0].equalsIgnoreCase("sort")) && sender instanceof Player) {
            suggestions.addAll(List.of("default", "availability", "price-asc", "price-desc", "name"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("admin") && sender.hasPermission(plugin.getAdminPermission())) {
            suggestions.addAll(List.of("reload", "status", "tutorial"));
        }
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        return suggestions.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted().toList();
    }
}
