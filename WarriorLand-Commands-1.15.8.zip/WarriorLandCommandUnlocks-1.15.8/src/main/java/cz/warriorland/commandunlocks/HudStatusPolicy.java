package cz.warriorland.commandunlocks;

/** Pure policy for the optional, vanilla Paper boss-bar HUD. */
final class HudStatusPolicy {
    private HudStatusPolicy() { }

    static boolean isEnabled(Boolean playerChoice, boolean serverDefault) {
        return playerChoice == null ? serverDefault : playerChoice;
    }

    static String title(int points, int unlocked, int totalUnlocks, int completedTasks, int totalTasks) {
        int safePoints = Math.max(0, points);
        int safeUnlocked = Math.max(0, Math.min(unlocked, Math.max(0, totalUnlocks)));
        int safeTotalUnlocks = Math.max(0, totalUnlocks);
        int safeCompletedTasks = Math.max(0, Math.min(completedTasks, Math.max(0, totalTasks)));
        int safeTotalTasks = Math.max(0, totalTasks);
        return "&5✦ &d&lWL &8| &6" + safePoints + " PP &8| &dPříkazy "
                + safeUnlocked + "/" + safeTotalUnlocks + " &8| &bÚkoly "
                + safeCompletedTasks + "/" + safeTotalTasks;
    }

    static double progress(int completed, int total) {
        if (total <= 0) return 0.0d;
        int safeCompleted = Math.max(0, Math.min(completed, total));
        return (double) safeCompleted / (double) total;
    }

    static boolean isTaskComplete(int current, int target) {
        return target > 0 && current >= target;
    }

    static int completedTasks(int[] currentValues, int[] targets) {
        if (currentValues == null || targets == null) return 0;
        int length = Math.min(currentValues.length, targets.length);
        int completed = 0;
        for (int i = 0; i < length; i++) {
            if (isTaskComplete(currentValues[i], targets[i])) completed++;
        }
        return completed;
    }
}
