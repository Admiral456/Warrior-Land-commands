package cz.warriorland.commandunlocks;

/** Guards int-backed PlayerPoints balances against overflow during point credits. */
public final class PointsCreditPolicy {
    private PointsCreditPolicy() { }

    public static boolean canCredit(int currentBalance, int amount) {
        return currentBalance >= 0 && amount >= 0 && (long) currentBalance + amount <= Integer.MAX_VALUE;
    }
}
