package cz.warriorland.commandunlocks;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Identifies tutorial prompt/pages without relying on localized inventory titles. */
public final class TutorialHolder implements InventoryHolder {
    private final boolean prompt;
    private final boolean adminTutorial;
    private final int page;
    private Inventory inventory;

    private TutorialHolder(boolean prompt, boolean adminTutorial, int page) {
        this.prompt = prompt;
        this.adminTutorial = adminTutorial;
        this.page = Math.max(0, page);
    }

    public static TutorialHolder prompt() { return new TutorialHolder(true, false, 0); }
    public static TutorialHolder page(int page) { return new TutorialHolder(false, false, page); }
    public static TutorialHolder adminPage(int page) { return new TutorialHolder(false, true, page); }
    public boolean isPrompt() { return prompt; }
    public boolean isAdminTutorial() { return adminTutorial; }
    public int page() { return page; }
    public void setInventory(Inventory inventory) { this.inventory = inventory; }
    @Override public Inventory getInventory() { return inventory; }
}
