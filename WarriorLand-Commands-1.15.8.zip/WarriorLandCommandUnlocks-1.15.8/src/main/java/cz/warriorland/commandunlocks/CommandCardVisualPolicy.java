package cz.warriorland.commandunlocks;

/** Pure status-to-icon mapping used by the optional custom item-model resource pack. */
final class CommandCardVisualPolicy {
    private CommandCardVisualPolicy() { }

    static String variant(boolean unlocked, boolean unavailable, boolean tasksComplete, boolean enoughPoints) {
        if (unavailable) return "unavailable";
        if (unlocked) return "unlocked";
        if (!tasksComplete) return "locked";
        return enoughPoints ? "ready" : "insufficient";
    }
}
