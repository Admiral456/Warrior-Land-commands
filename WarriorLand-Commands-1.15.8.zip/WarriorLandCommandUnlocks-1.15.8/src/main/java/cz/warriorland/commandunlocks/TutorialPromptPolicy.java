package cz.warriorland.commandunlocks;

/** Pure policy for the first-run tutorial choice; null means the player has not answered yet. */
final class TutorialPromptPolicy {
    private TutorialPromptPolicy() { }
    static boolean shouldPrompt(Boolean savedChoice) { return savedChoice == null; }
}
