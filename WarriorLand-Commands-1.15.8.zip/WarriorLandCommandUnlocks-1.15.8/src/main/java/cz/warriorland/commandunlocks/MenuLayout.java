package cz.warriorland.commandunlocks;

import java.util.HashSet;
import java.util.Set;

/**
 * Slot map for the real 54-slot Bukkit inventory. Keeping the map independent from rendering
 * lets tests detect accidental overlap between cards, navigation, and the detail panel.
 */
final class MenuLayout {
    static final int INVENTORY_SIZE = 54;
    static final int CARDS_PER_PAGE = 12;

    private static final int[] CARD_SLOTS = {
            11, 12, 13, 14,
            20, 21, 22, 23,
            29, 30, 31, 32
    };
    private static final int[] QUICK_INFO_SLOTS = {38, 39, 40, 41};
    private static final int[] DETAIL_SLOTS = {
            6, 7, 8,
            15, 16, 17,
            24, 25, 26,
            33, 34, 35,
            42, 43, 44
    };
    private static final int[] SEPARATOR_SLOTS = {10, 19, 28, 37};
    private static final int[] CATEGORY_SLOTS = {0, 9, 18, 27, 36};
    private static final int[] HEADER_SLOTS = {1, 2, 3, 4, 5};
    private static final int[] FOOTER_SLOTS = {45, 46, 47, 48, 49, 50, 51, 52, 53};

    private MenuLayout() { }

    static int[] cardSlots() { return CARD_SLOTS.clone(); }
    static int[] detailSlots() { return DETAIL_SLOTS.clone(); }
    static int[] quickInfoSlots() { return QUICK_INFO_SLOTS.clone(); }
    static int[] separatorSlots() { return SEPARATOR_SLOTS.clone(); }
    static int[] categorySlots() { return CATEGORY_SLOTS.clone(); }
    static int[] headerSlots() { return HEADER_SLOTS.clone(); }
    static int[] footerSlots() { return FOOTER_SLOTS.clone(); }

    static boolean isSidebarCategorySlot(int slot) {
        for (int categorySlot : CATEGORY_SLOTS) if (categorySlot == slot) return true;
        return false;
    }

    static boolean hasValidLayout() {
        Set<Integer> used = new HashSet<>();
        return addUniqueValid(used, CATEGORY_SLOTS)
                && addUniqueValid(used, HEADER_SLOTS)
                && addUniqueValid(used, SEPARATOR_SLOTS)
                && addUniqueValid(used, CARD_SLOTS)
                && addUniqueValid(used, QUICK_INFO_SLOTS)
                && addUniqueValid(used, DETAIL_SLOTS)
                && addUniqueValid(used, FOOTER_SLOTS)
                && used.size() == INVENTORY_SIZE
                && CARD_SLOTS.length == CARDS_PER_PAGE;
    }

    private static boolean addUniqueValid(Set<Integer> used, int[] slots) {
        for (int slot : slots) {
            if (slot < 0 || slot >= INVENTORY_SIZE || !used.add(slot)) return false;
        }
        return true;
    }
}
