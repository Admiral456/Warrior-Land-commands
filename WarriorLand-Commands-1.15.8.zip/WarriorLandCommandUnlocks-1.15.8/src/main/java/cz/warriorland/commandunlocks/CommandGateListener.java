package cz.warriorland.commandunlocks;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public final class CommandGateListener implements Listener {
    private final CommandUnlocksPlugin plugin;

    public CommandGateListener(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String label = CommandGatePolicy.commandLabel(event.getMessage());
        if (label.isBlank()) return;

        String matchedCommand = plugin.unlocks().matchedCommand(event.getMessage());
        UnlockDefinition definition = matchedCommand.isBlank() ? null : plugin.unlocks().byCommand(event.getMessage());
        if (definition == null) return;

        var player = event.getPlayer();
        boolean bypass = player.hasPermission(plugin.getBypassPermission());
        boolean safeMode = plugin.isSafeMode() || plugin.data() == null;
        boolean unlocked = !safeMode && plugin.data().isUnlocked(player.getUniqueId(), definition.id());
        if (!CommandGatePolicy.shouldBlock(bypass, safeMode, unlocked)) return;

        event.setCancelled(true);
        if (safeMode) {
            plugin.sendSafeModeMessage(player);
            return;
        }
        String displayCommand = "/" + (matchedCommand.isBlank() ? label : matchedCommand);
        plugin.sendMessage(player, "blocked-command", "%command%", displayCommand, "%id%", definition.id());
        if (plugin.hud() != null) plugin.hud().commandBlocked(player, displayCommand);
    }
}
