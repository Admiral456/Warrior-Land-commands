package cz.warriorland.commandunlocks;

import java.util.Objects;
import java.util.UUID;

/** Pure decisions for replacing this plugin's pack without disturbing packs owned by other plugins. */
final class ResourcePackReloadPolicy {
    private ResourcePackReloadPolicy() { }

    static boolean identityChanged(UUID previousRequestId, UUID nextRequestId) {
        return !Objects.equals(previousRequestId, nextRequestId);
    }

    static boolean shouldRemovePrevious(UUID previousRequestId, UUID nextRequestId) {
        return previousRequestId != null && identityChanged(previousRequestId, nextRequestId);
    }

    static boolean shouldClearLoadedState(UUID nextRequestId) {
        return nextRequestId == null;
    }

    static boolean shouldOfferAfterReload(UUID nextRequestId, UUID previousRequestId, boolean forceModeChanged) {
        return nextRequestId != null && (identityChanged(previousRequestId, nextRequestId) || forceModeChanged);
    }

    static boolean shouldOfferToPlayer(UUID nextRequestId, UUID playerLoadedRequestId,
                                       boolean packIdentityChanged, boolean forceModeChanged) {
        if (nextRequestId == null) return false;
        if (packIdentityChanged) return true;
        return forceModeChanged && !nextRequestId.equals(playerLoadedRequestId);
    }
}
