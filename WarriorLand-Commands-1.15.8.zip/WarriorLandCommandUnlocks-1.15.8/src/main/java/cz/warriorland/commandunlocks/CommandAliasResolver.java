package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Discovers aliases already registered by Paper/Bukkit plugins. Reflection is isolated here so a
 * server implementation that hides its command map simply falls back to explicit config aliases.
 */
public final class CommandAliasResolver {
    private final CommandUnlocksPlugin plugin;
    private boolean warnedUnavailable;
    private volatile Set<String> registeredRootLabels = Set.of();
    private volatile boolean registrationSnapshotKnown;

    public CommandAliasResolver(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    public List<Set<String>> discoverGroups(Set<String> configuredLabels) {
        try {
            Object commandMap = findCommandMap();
            if (commandMap == null) throw new ReflectiveOperationException("server neposkytuje CommandMap");
            Object rawKnownCommands = readKnownCommands(commandMap);
            if (!(rawKnownCommands instanceof Map<?, ?> knownCommands)) {
                throw new ReflectiveOperationException("CommandMap neobsahuje známou mapu příkazů");
            }

            Map<Command, Set<String>> groups = new IdentityHashMap<>();
            Set<String> registeredLabels = new LinkedHashSet<>();
            for (Map.Entry<?, ?> entry : knownCommands.entrySet()) {
                if (!(entry.getValue() instanceof Command command)) continue;
                Set<String> labels = groups.computeIfAbsent(command, ignored -> new LinkedHashSet<>());
                if (entry.getKey() instanceof String key) {
                    addLabel(labels, key);
                    addLabel(registeredLabels, key);
                }
                addLabel(labels, command.getName());
                addLabel(registeredLabels, command.getName());
                for (String alias : command.getAliases()) {
                    addLabel(labels, alias);
                    addLabel(registeredLabels, alias);
                }
            }
            registeredRootLabels = Set.copyOf(registeredLabels);
            registrationSnapshotKnown = true;

            List<Set<String>> matched = new ArrayList<>();
            for (Set<String> labels : groups.values()) {
                if (labels.stream().anyMatch(configuredLabels::contains)) {
                    matched.add(Collections.unmodifiableSet(new LinkedHashSet<>(labels)));
                }
            }
            warnedUnavailable = false;
            return List.copyOf(matched);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError error) {
            registrationSnapshotKnown = false;
            registeredRootLabels = Set.of();
            if (!warnedUnavailable) {
                plugin.getLogger().warning("Automatické rozpoznání aliasů z CommandMap není dostupné (" + error.getMessage()
                        + "). Ochrana zůstává aktivní pro příkazy/aliasy uvedené v config.yml; další aliasy doplň ručně do commands.");
                warnedUnavailable = true;
            }
            return List.of();
        }
    }

    /** Returns UNKNOWN when the server hides CommandMap; a configured name alone is not proof of existence. */
    public CommandAvailabilityPolicy.Status registrationStatus(String rawSelector) {
        if (!registrationSnapshotKnown) return CommandAvailabilityPolicy.Status.UNKNOWN;
        String root = CommandLabel.normalize(rawSelector);
        if (root.isBlank()) return CommandAvailabilityPolicy.Status.UNKNOWN;
        return registeredRootLabels.contains(root)
                ? CommandAvailabilityPolicy.Status.REGISTERED
                : CommandAvailabilityPolicy.Status.MISSING;
    }

    public boolean canInspectRegistration() {
        return registrationSnapshotKnown;
    }

    public int registeredLabelCount() {
        return registeredRootLabels.size();
    }

    private Object findCommandMap() throws ReflectiveOperationException {
        Object server = Bukkit.getServer();
        for (Method method : server.getClass().getMethods()) {
            if (method.getName().equals("getCommandMap") && method.getParameterCount() == 0) {
                return method.invoke(server);
            }
        }

        for (Class<?> type = server.getClass(); type != null; type = type.getSuperclass()) {
            for (Field field : type.getDeclaredFields()) {
                if (!field.getName().equalsIgnoreCase("commandMap") && !field.getType().getSimpleName().toLowerCase(java.util.Locale.ROOT).contains("commandmap")) continue;
                if (!field.trySetAccessible()) continue;
                Object result = field.get(server);
                if (result != null) return result;
            }
        }
        throw new NoSuchFieldException("commandMap");
    }

    private Object readKnownCommands(Object commandMap) throws ReflectiveOperationException {
        for (Class<?> type = commandMap.getClass(); type != null; type = type.getSuperclass()) {
            for (Field field : type.getDeclaredFields()) {
                if (!field.getName().equalsIgnoreCase("knownCommands")) continue;
                if (!field.trySetAccessible()) continue;
                return field.get(commandMap);
            }
        }
        throw new NoSuchFieldException("knownCommands");
    }

    private void addLabel(Set<String> labels, String rawLabel) {
        String normalized = CommandLabel.normalize(rawLabel);
        if (!normalized.isBlank()) labels.add(normalized);
    }
}
