package cz.warriorland.commandunlocks;

import org.bukkit.configuration.file.YamlConfiguration;

import java.util.function.BooleanSupplier;

/** Applies a tutorial preference only when it is durably saved; restores memory on write failure. */
final class TutorialChoiceMutationPolicy {
    private TutorialChoiceMutationPolicy() { }

    static boolean persistOrRestore(YamlConfiguration data, String path, Boolean choice,
                                    BooleanSupplier durableSave) {
        Object previous = data.get(path);
        data.set(path, choice);
        try {
            if (durableSave.getAsBoolean()) return true;
        } catch (RuntimeException failure) {
            data.set(path, previous);
            throw failure;
        }
        data.set(path, previous);
        return false;
    }
}
