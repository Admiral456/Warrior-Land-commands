package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuManager {
    // 54-slot inventory layout: category rail, three rows of four commands, a right-hand detail rail,
    // a compact help row, and dedicated paging/footer controls.
    private static final int[] CARD_SLOTS = MenuLayout.cardSlots();
    private static final int[] DETAIL_SLOTS = MenuLayout.detailSlots();
    private static final int[] QUICK_INFO_SLOTS = MenuLayout.quickInfoSlots();
    private static final int[] SEPARATOR_SLOTS = MenuLayout.separatorSlots();
    private final CommandUnlocksPlugin plugin;
    private final Map<String, ItemStack> itemsAdderIconCache = new HashMap<>();
    private final Set<String> warnedMissingIcons = new HashSet<>();
    private final Set<java.util.UUID> scheduledRefreshes = new HashSet<>();
    private final Map<UUID, String> searchQueries = new HashMap<>();
    private final Map<UUID, String> sortModes = new HashMap<>();
    private final Set<UUID> awaitingSearchInput = ConcurrentHashMap.newKeySet();
    private final Map<UUID, SearchReturnState> pendingSearchReturns = new HashMap<>();
    private final Map<UUID, BukkitTask> searchTimeouts = new HashMap<>();
    private boolean warnedItemsAdderGuiSkinUnavailable;
    private boolean lastTexturedGuiCreationSucceeded;

    /** Human-readable admin diagnostic; configuration alone is not treated as proof the texture loaded. */
    public String itemsAdderGuiStatus() {
        if (!plugin.getConfig().getBoolean("settings.itemsadder-textured-gui", false)) {
            return "&7Vypnuto — běžné Paper GUI";
        }
        if (!plugin.getServer().getPluginManager().isPluginEnabled("ItemsAdder")) {
            return "&cZapnuto v konfiguraci, ale ItemsAdder neběží";
        }
        if (lastTexturedGuiCreationSucceeded) {
            return "&aTexturovaný inventář byl úspěšně vytvořen";
        }
        if (warnedItemsAdderGuiSkinUnavailable) {
            return "&cTextura/API selhala — používá se vanilla fallback";
        }
        return "&eZatím neověřeno — otevři /prikazy a zkontroluj zarovnání";
    }

    private record InventoryCreation(Inventory inventory, boolean texturedBackground) { }
    private record SearchReturnState(String category, int page, String selectedId, boolean pointsView) { }

    public MenuManager(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String category = "all";
        String selected = firstId(player, category);
        open(player, category, 0, selected, false);
    }

    public String searchQuery(UUID playerId) {
        return playerId == null ? "" : searchQueries.getOrDefault(playerId, "");
    }

    public String sortMode(UUID playerId) {
        return playerId == null ? "default" : sortModes.getOrDefault(playerId, "default");
    }

    public boolean isAwaitingSearchInput(UUID playerId) {
        return playerId != null && awaitingSearchInput.contains(playerId);
    }

    /** Starts a vanilla-chat search prompt, preserving the current catalogue view for cancel. */
    public void beginSearch(Player player, MenuHolder holder) {
        if (player == null || !player.isOnline()) return;
        UUID uuid = player.getUniqueId();
        if (holder == null || holder.pointsView()) {
            pendingSearchReturns.put(uuid, new SearchReturnState("all", 0, firstId(player, "all"), false));
        } else {
            pendingSearchReturns.put(uuid, new SearchReturnState(holder.category(), holder.page(), holder.selectedId(), false));
        }
        awaitingSearchInput.add(uuid);
        player.closeInventory();
        player.sendMessage(plugin.color("&5&lPŘÍKAZY &8» &dNapiš hledaný text do chatu &7(název, příkaz, alias nebo popis)."));
        player.sendMessage(plugin.color("&7Max. 48 znaků. Napiš &eclear &7pro vymazání filtru nebo &czrušit &7pro návrat."));
        cancelSearchTimeout(uuid);
        searchTimeouts.put(uuid, Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!awaitingSearchInput.remove(uuid)) {
                searchTimeouts.remove(uuid);
                return;
            }
            searchTimeouts.remove(uuid);
            SearchReturnState previous = pendingSearchReturns.remove(uuid);
            Player current = Bukkit.getPlayer(uuid);
            if (current != null && current.isOnline()) {
                plugin.sendMessage(current, "search-timeout");
                if (previous != null) open(current, previous.category(), previous.page(), previous.selectedId(), previous.pointsView());
                else open(current);
            }
        }, 20L * 45));
    }

    public void beginSearch(Player player) {
        MenuHolder current = player != null && player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder holder
                ? holder : null;
        beginSearch(player, current);
    }

    /** Called on the server thread after MenuListener consumes the player's next chat message. */
    public void acceptSearchInput(Player player, String rawInput) {
        if (player == null) return;
        UUID uuid = player.getUniqueId();
        if (!awaitingSearchInput.remove(uuid)) return;
        SearchReturnState savedReturn = pendingSearchReturns.remove(uuid);
        cancelSearchTimeout(uuid);
        final SearchReturnState previous = savedReturn == null
                ? new SearchReturnState("all", 0, null, false) : savedReturn;
        if (!player.isOnline()) return;

        String query = CommandSearchPolicy.sanitize(rawInput);
        String command = query.toLowerCase(Locale.ROOT);
        if (command.equals("zrusit") || command.equals("zrušit") || command.equals("cancel") || command.equals("esc")) {
            plugin.sendMessage(player, "search-cancelled");
            open(player, previous.category(), previous.page(), previous.selectedId(), previous.pointsView());
            return;
        }
        if (query.isBlank() || command.equals("clear") || command.equals("vymazat") || command.equals("vše") || command.equals("vse")) {
            searchQueries.remove(uuid);
            plugin.sendMessage(player, "search-cleared");
        } else {
            searchQueries.put(uuid, query);
            plugin.sendMessage(player, "search-applied", "%query%", query);
        }
        List<UnlockDefinition> results = filteredDefinitions(player, previous.category());
        String selected = results.stream().anyMatch(definition -> definition.id().equals(previous.selectedId()))
                ? previous.selectedId() : results.stream().findFirst().map(UnlockDefinition::id).orElse(null);
        open(player, previous.category(), 0, selected, previous.pointsView());
    }

    /** Applies a search supplied directly as /prikazy hledat <text>. */
    public void setSearch(Player player, String rawQuery) {
        if (player == null || !player.isOnline()) return;
        UUID uuid = player.getUniqueId();
        awaitingSearchInput.remove(uuid);
        pendingSearchReturns.remove(uuid);
        cancelSearchTimeout(uuid);
        String query = CommandSearchPolicy.sanitize(rawQuery);
        if (query.isBlank() || query.equalsIgnoreCase("clear") || query.equalsIgnoreCase("vymazat")) {
            searchQueries.remove(uuid);
            plugin.sendMessage(player, "search-cleared");
        } else {
            searchQueries.put(uuid, query);
            plugin.sendMessage(player, "search-applied", "%query%", query);
        }
        open(player, "all", 0, firstId(player, "all"), false);
    }

    public void setSortMode(Player player, String requestedMode) {
        if (player == null || !player.isOnline()) return;
        String mode = canonicalSortMode(requestedMode);
        if (!CommandSearchPolicy.isValidSort(mode)) {
            plugin.sendMessage(player, "sort-usage");
            return;
        }
        sortModes.put(player.getUniqueId(), mode);
        MenuHolder current = player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder holder
                ? holder : null;
        String category = current == null || current.pointsView() ? "all" : current.category();
        String candidateId = current == null ? firstId(player, category) : current.selectedId();
        plugin.sendMessage(player, "sort-applied", "%sort%", CommandSearchPolicy.label(mode));
        List<UnlockDefinition> results = filteredDefinitions(player, category);
        boolean candidateStillVisible = candidateId != null
                && results.stream().anyMatch(definition -> definition.id().equals(candidateId));
        String selectedId = candidateStillVisible ? candidateId
                : results.stream().findFirst().map(UnlockDefinition::id).orElse(null);
        open(player, category, 0, selectedId, false);
    }

    public void cycleSort(Player player, MenuHolder holder) {
        if (player == null || !player.isOnline()) return;
        String next = CommandSearchPolicy.nextSortMode(sortMode(player.getUniqueId()));
        setSortMode(player, next);
    }

    /** Forget short-lived UI state on logout; durable purchase/task/tutorial state lives elsewhere. */
    public void forget(UUID playerId) {
        if (playerId == null) return;
        awaitingSearchInput.remove(playerId);
        pendingSearchReturns.remove(playerId);
        cancelSearchTimeout(playerId);
        scheduledRefreshes.remove(playerId);
        searchQueries.remove(playerId);
        sortModes.remove(playerId);
    }

    private void cancelSearchTimeout(UUID playerId) {
        BukkitTask task = searchTimeouts.remove(playerId);
        if (task != null) task.cancel();
    }

    /** Opens the server-only tutorial in ordinary Paper inventory screens. */
    public void openTutorial(Player player) {
        if (player == null || !player.isOnline()) return;
        if (!Boolean.TRUE.equals(plugin.data().getTutorialChoice(player.getUniqueId()))) {
            if (!plugin.data().setTutorialChoice(player.getUniqueId(), true)) {
                plugin.getLogger().warning("Explicitní volbu tutorialu se nepodařilo uložit pro " + player.getName());
            }
        }
        openTutorialPage(player, 0);
    }

    /** First-run prompt shown once per player; the answer is saved in players.yml. */
    public void openTutorialPrompt(Player player) {
        if (player == null || !player.isOnline()) return;
        cancelPendingSearch(player.getUniqueId());
        TutorialHolder holder = TutorialHolder.prompt();
        Inventory inventory = Bukkit.createInventory(holder, 27, plugin.color("&5&lWARRIORLAND &8» &dTutoriál?"));
        holder.setInventory(inventory);
        fillTutorialFrame(inventory);
        inventory.setItem(4, item(Material.BOOK, "&d&lRYCHLÝ TUTORIÁL", List.of(
                "&7Chceš krátký návod, který ti ukáže,", "&7jak funguje odemykání příkazů?", "", 
                "&eDozvíš se, kde jsou kategorie,", "&eúkoly, ceny a bezpečné potvrzení."), true));
        inventory.setItem(11, item(Material.LIME_DYE, "&a&lANO — ZOBRAZIT NÁVOD", List.of(
                "&7Otevře krátký návod po krocích.", "&7Můžeš ho kdykoli znovu spustit", "&7příkazem &f/prikazy tutorial&7.", "", "&eKlikni pro pokračování."), true));
        inventory.setItem(15, item(Material.RED_DYE, "&c&lNE — PŘESKOČIT", List.of(
                "&7Otevře rovnou obchod příkazů.", "&7Tato volba se zapamatuje.", "", "&eTutorial kdykoli spustíš přes", "&f/prikazy tutorial&e.")));
        inventory.setItem(22, item(Material.WRITABLE_BOOK, "&bNávod kdykoli znovu", List.of(
                "&7Příkaz: &f/prikazy tutorial", "&7Reset volby: &f/prikazy tutorial reset")));
        player.openInventory(inventory);
    }

    private void fillTutorialFrame(Inventory inventory) {
        ItemStack filler = item(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int slot = 0; slot < inventory.getSize(); slot++) inventory.setItem(slot, filler);
        ItemStack accent = item(Material.PURPLE_STAINED_GLASS_PANE, "&5", List.of());
        for (int slot : new int[]{0,1,2,3,5,6,7,8,9,10,12,14,16,17,18,19,20,21,23,24,25,26}) inventory.setItem(slot, accent);
    }

    private static final List<TutorialStep> TUTORIAL_STEPS = List.of(
            new TutorialStep(Material.COMMAND_BLOCK, "&d&l1. VÍTEJ V OBCHODĚ", "&7Tady odemykáš užitečné příkazy za PlayerPoints.", List.of("&7Vyber kategorii a potom kartu příkazu.", "&7V detailu si vždy zkontroluj cenu, úkoly", "&7a případné požadované pluginy.")),
            new TutorialStep(Material.COMPASS, "&d&l2. KATEGORIE, HLEDÁNÍ A ŘAZENÍ", "&7Levý panel vybírá kategorii; nahoře hledáš a řadíš.", List.of("&fVšechny &7— celý katalog.", "&fTeleportace &7— cestování a domovy.", "&fResidence &7— funkce rezidencí.", "&fEkonomika &7— peníze a obchod.", "&fUtility &7— ostatní nástroje.", "", "&bHledání &7— nahoře klikni na lupu a zadej název, příkaz, alias nebo popis.", "&bŘazení &7— klikni na symbol násypky: dostupnost, cena nebo název.", "&7Lze použít i &f/prikazy hledat <text>&7.")),
            new TutorialStep(Material.EMERALD, "&d&l3. KARTY A BARVY", "&7Karta ukazuje hlavní příkaz a jeho cenu.", List.of("&aZelená &7— příkaz už vlastníš.", "&eZlatá &7— cena v PlayerPoints.", "&7Šedá &7— úkoly nebo body ještě chybí.", "&cČervená &7— chybí požadovaný plugin.", "&7Klikni na kartu pro detail vpravo.")),
            new TutorialStep(Material.WRITABLE_BOOK, "&d&l4. DETAIL A ÚKOLY", "&7Detail zobrazuje podmínky pro odemčení.", List.of("&7Zkontroluj popis, cenu, aliasy a závislosti.", "&7Úkoly mohou vyžadovat těžbu, crafting,", "&7rybaření, boj nebo hlasování.", "&7Postup se ukládá podle UUID hráče.", "&7Pouze dokončené požadavky se počítají.")),
            new TutorialStep(Material.GOLD_INGOT, "&d&l5. BODY A NÁKUP", "&7Saldo načítáme přímo z PlayerPoints.", List.of("&7První kliknutí otevře potvrzení nákupu.", "&7Body se odečtou až po potvrzení.", "&7Zavření nebo storno nic nekoupí.", "&7Nedostatek bodů? Plň úkoly a získej odměny.")),
            new TutorialStep(Material.SHIELD, "&d&l6. HOTOVO, HUD A IKONY", "&7Teď už víš, jak obchod používat.", List.of("&7Odemčené příkazy můžeš používat ihned.", "&7Alias stejné funkce nekupuješ znovu.", "&7Pokud chybí plugin, nákup zůstane blokovaný.", "&7HUD zapneš/vypneš: /prikazy hud on|off", "&7Tutorial: /prikazy tutorial", "&7Vlastní ikony vyžadují nakonfigurovaný a načtený resource pack.", "&7Bez něj se použijí běžné Minecraft ikony."))
    );

    private static final List<TutorialStep> ADMIN_TUTORIAL_STEPS = List.of(
            new TutorialStep(Material.WRITABLE_BOOK, "&d&l1. KONFIGURACE KATALOGU", "&7Každá položka má stabilní interní ID v config.yml.", List.of(
                    "&7Soubor: &fplugins/WarriorLandCommandUnlocks/config.yml",
                    "&7Položku uprav v sekci &funlocks.<id>&7.",
                    "&7Důležité údaje: name, description, category, icon, commands, cost, tasks.",
                    "&7ID po vydání neměň — používá se pro vlastnictví a postup.",
                    "&7Po úpravě použij &f/prikazy admin reload&7 a kontroluj konzoli.")),
            new TutorialStep(Material.CHAIN, "&d&l2. ZÁVISLOSTI A CUSTOM PŘÍKAZY", "&7Nákup povol jen pokud je funkce skutečně dostupná.", List.of(
                    "&7Požadované pluginy deklaruj v &frequired-plugins&7.",
                    "&7Odemčení nastaví explicitní LuckPerms nodes.",
                    "&7MyCommand může dodat vlastní jednoduchý příkaz; stejný permission node musí být v MyCommand i v katalogu.",
                    "&cNeregistruj znovu příkaz, který už vlastní EssentialsX, Residence nebo jiný plugin.",
                    "&7Chybějící závislost má bezpečně zablokovat nákup.")),
            new TutorialStep(Material.SHIELD, "&d&l3. RESOURCE PACK A DIAGNOSTIKA", "&7Vlastní ikony jsou volitelné; základní funkce musí zůstat dostupná bez packu.", List.of(
                    "&7Nastav HTTPS URL a odpovídající SHA-1 resource packu.",
                    "&7Vlastní item modely povol až po ověření, že klient pack načetl.",
                    "&7ItemsAdder texturované GUI je samostatná volitelná integrace.",
                    "&e/prikazy admin status &7— stav závislostí, HUD, packu a transakcí.",
                    "&e/prikazy admin reload &7— bezpečné načtení konfigurace.",
                    "&7Nejdřív testuj na kopii serveru; nikdy netestuj cizí příkazy jejich spouštěním."))
    );

    public void openTutorialPage(Player player, int requestedPage) {
        if (player == null || !player.isOnline()) return;
        cancelPendingSearch(player.getUniqueId());
        int page = Math.max(0, Math.min(TUTORIAL_STEPS.size() - 1, requestedPage));
        TutorialHolder holder = TutorialHolder.page(page);
        Inventory inventory = Bukkit.createInventory(holder, 27, plugin.color("&5&lTUTORIÁL &8· &d" + (page + 1) + "/" + TUTORIAL_STEPS.size()));
        holder.setInventory(inventory);
        fillTutorialFrame(inventory);
        TutorialStep step = TUTORIAL_STEPS.get(page);
        inventory.setItem(4, item(Material.BOOK, "&d&l" + stripColors(step.title()), List.of("&7Krok " + (page + 1) + " z " + TUTORIAL_STEPS.size()), true));
        inventory.setItem(11, item(Material.LIGHT_BLUE_STAINED_GLASS_PANE, "&b&lKDE CO NAJDEŠ", List.of(step.summary(), "", "&7Prohlédni si body vpravo.")));
        inventory.setItem(13, item(step.icon(), stripColors(step.title()), buildTutorialLore(step), true));
        inventory.setItem(15, item(Material.WRITABLE_BOOK, "&f&lV TOMTO KROKU", step.details()));
        inventory.setItem(18, item(Material.ARROW, "&fZPĚT", List.of("&7Předchozí krok."), page > 0));
        inventory.setItem(22, item(Material.BARRIER, "&cPŘESKOČIT NÁVOD", List.of("&7Otevře hlavní katalog příkazů.")));
        inventory.setItem(26, item(page == TUTORIAL_STEPS.size() - 1 ? Material.LIME_DYE : Material.ARROW,
                page == TUTORIAL_STEPS.size() - 1 ? "&a&lDOKONČIT" : "&d&lDALŠÍ KROK",
                List.of(page == TUTORIAL_STEPS.size() - 1 ? "&7Přejít do katalogu." : "&7Pokračovat na krok " + (page + 2) + "."), true));
        inventory.setItem(8, item(Material.BARRIER, "&cZAVŘÍT", List.of("&7Zavře návod.")));
        player.openInventory(inventory);
    }

    public void openAdminTutorial(Player player, int requestedPage) {
        if (player == null || !player.isOnline()) return;
        cancelPendingSearch(player.getUniqueId());
        if (!player.hasPermission(plugin.getAdminPermission())) {
            plugin.sendMessage(player, "no-permission");
            return;
        }
        int page = Math.max(0, Math.min(ADMIN_TUTORIAL_STEPS.size() - 1, requestedPage));
        TutorialHolder holder = TutorialHolder.adminPage(page);
        Inventory inventory = Bukkit.createInventory(holder, 27,
                plugin.color("&5&lADMIN TUTORIÁL &8· &d" + (page + 1) + "/" + ADMIN_TUTORIAL_STEPS.size()));
        holder.setInventory(inventory);
        fillTutorialFrame(inventory);
        TutorialStep step = ADMIN_TUTORIAL_STEPS.get(page);
        inventory.setItem(4, item(Material.KNOWLEDGE_BOOK, "&d&l" + stripColors(step.title()),
                List.of("&7Administrační návod", "&7Krok " + (page + 1) + " z " + ADMIN_TUTORIAL_STEPS.size()), true));
        inventory.setItem(11, item(Material.LIGHT_BLUE_STAINED_GLASS_PANE, "&b&lCO A KDE", List.of(step.summary())));
        inventory.setItem(13, item(step.icon(), stripColors(step.title()), buildTutorialLore(step), true));
        inventory.setItem(15, item(Material.WRITABLE_BOOK, "&f&lDŮLEŽITÉ BODY", step.details()));
        inventory.setItem(18, item(Material.ARROW, "&fZPĚT", List.of("&7Předchozí krok."), page > 0));
        inventory.setItem(22, item(Material.BARRIER, "&cPŘESKOČIT NÁVOD", List.of("&7Otevře hlavní katalog.")));
        inventory.setItem(26, item(page == ADMIN_TUTORIAL_STEPS.size() - 1 ? Material.LIME_DYE : Material.ARROW,
                page == ADMIN_TUTORIAL_STEPS.size() - 1 ? "&a&lDOKONČIT" : "&d&lDALŠÍ KROK",
                List.of(page == ADMIN_TUTORIAL_STEPS.size() - 1 ? "&7Přejít do katalogu." : "&7Pokračovat na krok " + (page + 2) + "."), true));
        inventory.setItem(8, item(Material.BARRIER, "&cZAVŘÍT", List.of("&7Zavře administrační návod.")));
        player.openInventory(inventory);
    }

    private List<String> buildTutorialLore(TutorialStep step) {
        List<String> lore = new ArrayList<>();
        lore.add(step.summary());
        lore.add("");
        for (String detail : step.details()) lore.add(detail);
        return lore;
    }

    private String stripColors(String text) {
        return text == null ? "" : text.replaceAll("&[0-9a-fk-or]", "");
    }

    private record TutorialStep(Material icon, String title, String summary, List<String> details) { }

    public void handleTutorialClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof TutorialHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        int slot = event.getRawSlot();
        if (holder.isPrompt()) {
            if (slot == 11) {
                boolean saved = plugin.data().setTutorialChoice(player.getUniqueId(), true);
                if (!saved) plugin.getLogger().warning("Volbu tutorialu se nepodařilo uložit pro " + player.getName() + "; návod se přesto otevře.");
                openTutorialPage(player, 0);
            } else if (slot == 15) {
                boolean saved = plugin.data().setTutorialChoice(player.getUniqueId(), false);
                if (!saved) plugin.getLogger().warning("Volbu přeskočení tutorialu se nepodařilo uložit pro " + player.getName() + "; prompt se může příště opakovat.");
                open(player);
            } else if (slot == 22) {
                player.closeInventory();
                player.sendMessage(plugin.color("&dTutoriál znovu spustíš příkazem &f/prikazy tutorial&d. Pro novou volbu použij &f/prikazy tutorial reset&d."));
            }
            return;
        }
        if (holder.isAdminTutorial()) {
            if (slot == 8) player.closeInventory();
            else if (slot == 18) openAdminTutorial(player, holder.page() - 1);
            else if (slot == 22) open(player);
            else if (slot == 26) {
                if (holder.page() >= ADMIN_TUTORIAL_STEPS.size() - 1) open(player);
                else openAdminTutorial(player, holder.page() + 1);
            }
            return;
        }
        if (slot == 8) {
            player.closeInventory();
        } else if (slot == 18) {
            openTutorialPage(player, holder.page() - 1);
        } else if (slot == 22) {
            open(player);
        } else if (slot == 26) {
            if (holder.page() >= TUTORIAL_STEPS.size() - 1) open(player);
            else openTutorialPage(player, holder.page() + 1);
        }
    }

    public void open(Player player, String category, int page, String selectedId, boolean pointsView) {
        cancelPendingSearch(player.getUniqueId());
        String resolvedCategory = category == null ? "all" : category;
        if (!resolvedCategory.equalsIgnoreCase("all")
                && plugin.getConfig().getConfigurationSection("categories." + resolvedCategory) == null) {
            resolvedCategory = "all";
        }
        List<UnlockDefinition> categoryDefinitions = filteredDefinitions(player, resolvedCategory);
        int maxPage = Math.max(0, (categoryDefinitions.size() - 1) / CARD_SLOTS.length);
        int resolvedPage = Math.max(0, Math.min(page, maxPage));
        String resolvedSelectedId = selectedId;
        if (!pointsView) {
            int pageStart = resolvedPage * CARD_SLOTS.length;
            int pageEnd = Math.min(categoryDefinitions.size(), pageStart + CARD_SLOTS.length);
            boolean selectedOnPage = false;
            for (int i = pageStart; i < pageEnd; i++) {
                if (categoryDefinitions.get(i).id().equals(resolvedSelectedId)) {
                    selectedOnPage = true;
                    break;
                }
            }
            if (!selectedOnPage) resolvedSelectedId = pageStart < categoryDefinitions.size()
                    ? categoryDefinitions.get(pageStart).id() : null;
        }
        MenuHolder holder = new MenuHolder(resolvedCategory, resolvedPage, resolvedSelectedId, pointsView);
        String titleKey = pointsView ? "settings.points-title" : "settings.menu-title";
        String title = plugin.getConfig().getString(titleKey, pointsView ? "&8[&5WL&8] &6Moje body" : "&8[&5WL&8] &dPříkazy");
        InventoryCreation creation = createMainInventory(holder, 54, title);
        Inventory inventory = creation.inventory();
        holder.setInventory(inventory);
        fillBackground(inventory, creation.texturedBackground());
        int balance = plugin.points().balance(player.getUniqueId());
        renderHeader(player, inventory, holder, balance);
        renderSidebar(player, inventory, holder);

        if (pointsView) {
            renderPoints(player, inventory, balance);
        } else {
            renderCards(player, inventory, holder, balance);
            renderQuickGuide(player, holder, inventory);
            renderDetails(player, inventory, holder, balance);
            renderPaging(player, inventory, holder);
        }

        inventory.setItem(53, item(Material.BARRIER, "&c&lZAVŘÍT MENU", List.of("&7Zavře obchod příkazů.", "", "&8Tvé nákupy zůstávají uložené.")));
        player.openInventory(inventory);
    }

    /**
     * Re-render at most once on the next server tick. Progress can change several tasks in one event
     * burst (e.g. fast crafting or Jobs callbacks); reopening the inventory synchronously for every
     * increment causes unnecessary packets and visible flicker.
     */
    public void refresh(Player player) {
        if (player == null || !player.isOnline()) return;
        if (!(player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder)) return;
        java.util.UUID playerId = player.getUniqueId();
        if (!scheduledRefreshes.add(playerId)) return;
        try {
            Bukkit.getScheduler().runTask(plugin, () -> {
                scheduledRefreshes.remove(playerId);
                Player current = Bukkit.getPlayer(playerId);
                if (current == null || !current.isOnline()
                        || !(current.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
                open(current, holder.category(), holder.page(), holder.selectedId(), holder.pointsView());
            });
        } catch (IllegalStateException schedulerUnavailable) {
            scheduledRefreshes.remove(playerId);
            if (!plugin.isShuttingDown()) {
                plugin.getLogger().warning("Nelze naplánovat obnovení GUI pro hráče " + playerId + ": " + schedulerUnavailable.getMessage());
            }
        }
    }

    /** Opens a second-step confirmation screen; no currency or permissions change here. */
    private void openConfirmation(Player player, String category, int page, String selectedId) {
        UnlockDefinition definition = plugin.unlocks().byId(selectedId);
        if (definition == null) {
            open(player, category, page, selectedId, false);
            return;
        }

        int balance = plugin.points().balance(player.getUniqueId());
        boolean unlocked = plugin.data().isUnlocked(player.getUniqueId(), definition.id());
        boolean complete = plugin.tasks().requirementsMet(player.getUniqueId(), definition);
        List<String> missingDependencies = plugin.missingRequiredPlugins(definition);
        boolean commandMissing = CommandAvailabilityPolicy.blocksPurchase(plugin.unlocks().commandRegistrationStatus(definition));
        MenuHolder holder = new MenuHolder(category, page, definition.id(), false, true);
        String title = plugin.getConfig().getString("settings.purchase-title", "&5&lWarriorLand &8» &ePotvrdit nákup");
        Inventory inventory = Bukkit.createInventory(holder, 27, plugin.color(title));
        holder.setInventory(inventory);
        ItemStack filler = item(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, filler);
        for (int slot : new int[]{0, 1, 2, 3, 5, 6, 7, 8, 9, 17, 18, 19, 20, 21, 23, 24, 25, 26}) {
            inventory.setItem(slot, item(Material.PURPLE_STAINED_GLASS_PANE, "&5", List.of()));
        }

        List<String> summary = new ArrayList<>();
        summary.add("&7Funkce: &f" + definition.name());
        summary.add("&7Příkaz: &f/" + definition.primaryCommand());
        summary.add("&7Kategorie: &f" + categoryName(definition.category()));
        summary.add("");
        summary.add("&6Cena: &e" + definition.cost() + " PP");
        summary.add("&7Aktuální zůstatek: &e" + balance + " PP");
        summary.add("&7Zůstatek po nákupu: &e" + Math.max(0, balance - definition.cost()) + " PP");
        summary.add("");
        summary.add("&8Vlastnictví aliasů se sdílí — další nákup není potřeba.");
        inventory.setItem(4, item(definition.icon(), Material.PAPER, "&ePotvrzení nákupu", summary));
        inventory.setItem(13, item(Material.GOLD_INGOT, "&6Cena a zůstatek", List.of(
                "&7Cena: &e" + definition.cost() + " PP",
                "&7Teď máš: &e" + balance + " PP",
                "&7Po nákupu: &e" + Math.max(0, balance - definition.cost()) + " PP"), true));

        if (unlocked) {
            inventory.setItem(11, item(Material.LIME_DYE, "&aJiž odemčeno", List.of("&7Tuto funkci už vlastníš.", "&7Body nebudou odečteny.")));
        } else if (!missingDependencies.isEmpty() || commandMissing) {
            List<String> unavailableLore = new ArrayList<>();
            if (!missingDependencies.isEmpty()) unavailableLore.addAll(wrapLore("Chybí zapnutý plugin: " + String.join(", ", missingDependencies), 32, "&c"));
            if (commandMissing) unavailableLore.addAll(wrapLore("Není registrován příkaz /" + definition.primaryCommand(), 32, "&c"));
            unavailableLore.add("&7Nákup není možný.");
            inventory.setItem(11, item(Material.BARRIER, "&cFunkce není dostupná", unavailableLore));
        } else if (!complete) {
            inventory.setItem(11, item(Material.GRAY_DYE, "&7Úkoly nejsou splněny", List.of("&7Vrať se do detailu a dokonči úkoly.")));
        } else if (balance < definition.cost()) {
            inventory.setItem(11, item(Material.ORANGE_DYE, "&6Nedostatek bodů", List.of("&7Chybí: &e" + (definition.cost() - balance) + " PP")));
        } else {
            inventory.setItem(11, item(Material.EMERALD, "&aPotvrdit nákup", List.of(
                    "&7Odemkne funkci a její aliasy:",
                    "&f" + String.join(", ", definition.commands().stream().map(command -> "/" + command).toList()),
                    "", "&cOdečte se &e" + definition.cost() + " PP&c.", "", "&aKlikni pro potvrzení."), true));
        }
        inventory.setItem(15, item(Material.RED_DYE, "&cZrušit nákup", List.of("&7Nic se nekoupí ani neodečte.", "", "&eVrátit se k vybrané funkci.")));
        inventory.setItem(22, item(Material.BARRIER, "&7Zavřít", List.of("&7Zavře potvrzení bez nákupu.")));
        player.openInventory(inventory);
    }

    public void handleClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        if (holder.confirmationView()) {
            if (slot == 11) {
                UnlockDefinition selected = plugin.unlocks().byId(holder.selectedId());
                if (selected != null && plugin.missingRequiredPlugins(selected).isEmpty()
                        && !CommandAvailabilityPolicy.blocksPurchase(plugin.unlocks().commandRegistrationStatus(selected))) {
                    plugin.purchases().purchase(player, selected, holder);
                } else if (selected != null) {
                    List<String> missing = plugin.missingRequiredPlugins(selected);
                    if (!missing.isEmpty()) plugin.sendMessage(player, "dependency-missing", "%plugins%", String.join(", ", missing));
                    else if (CommandAvailabilityPolicy.blocksPurchase(plugin.unlocks().commandRegistrationStatus(selected))) {
                        plugin.sendMessage(player, "command-provider-missing", "%command%", "/" + selected.primaryCommand());
                    }
                    open(player, holder.category(), holder.page(), selected.id(), false);
                }
                else open(player, holder.category(), holder.page(), null, false);
            } else if (slot == 15) {
                open(player, holder.category(), holder.page(), holder.selectedId(), false);
            } else if (slot == 22) {
                player.closeInventory();
            }
            return;
        }
        if (slot == 53) {
            player.closeInventory();
            return;
        }
        if (slot == 45) {
            if (holder.pointsView()) {
                open(player, "all", 0, firstId(player, "all"), false);
            } else {
                open(player, holder.category(), holder.page(), holder.selectedId(), true);
            }
            return;
        }

        // The compact shortcut bar is actionable, with its slot mapping covered by pure-policy tests.
        if (!holder.pointsView()) {
            switch (MenuQuickActionPolicy.actionFor(slot)) {
                case TUTORIAL -> { openTutorialPage(player, 0); return; }
                case POINTS -> { open(player, holder.category(), holder.page(), holder.selectedId(), true); return; }
                case TASKS -> { openTutorialPage(player, 3); return; }
                case STATUS_LEGEND -> { openTutorialPage(player, 2); return; }
                case HUD_TOGGLE -> {
                    boolean next = !plugin.hud().statusBarEnabled(player.getUniqueId());
                    if (!plugin.data().setHudChoice(player.getUniqueId(), next)) {
                        plugin.sendMessage(player, "hud-preference-save-failed");
                    } else {
                        if (next) plugin.hud().refreshStatusBar(player);
                        else plugin.hud().hideStatusBar(player.getUniqueId());
                        plugin.sendMessage(player, next ? "hud-enabled" : "hud-disabled");
                    }
                    open(player, holder.category(), holder.page(), holder.selectedId(), false);
                    return;
                }
                case NONE -> { /* Continue to category, card, and paging handlers. */ }
            }
        }

        if (!holder.pointsView() && slot == 2) {
            beginSearch(player, holder);
            return;
        }
        if (!holder.pointsView() && slot == 3) {
            cycleSort(player, holder);
            return;
        }

        String categoryAtSlot = categoryAtSlot(slot);
        if (categoryAtSlot != null) {
            open(player, categoryAtSlot, 0, firstId(player, categoryAtSlot), false);
            return;
        }

        if (holder.pointsView()) {
            if (slot == 48) open(player, "all", 0, firstId(player, "all"), false);
            return;
        }

        if (slot == 46) {
            int targetPage = Math.max(0, holder.page() - 1);
            open(player, holder.category(), targetPage, firstIdOnPage(player, holder.category(), targetPage), false);
            return;
        }
        if (slot == 50) {
            int maxPage = Math.max(0, (filteredDefinitions(player, holder.category()).size() - 1) / CARD_SLOTS.length);
            int targetPage = Math.min(maxPage, holder.page() + 1);
            open(player, holder.category(), targetPage, firstIdOnPage(player, holder.category(), targetPage), false);
            return;
        }
        if (slot == 43) {
            UnlockDefinition selected = plugin.unlocks().byId(holder.selectedId());
            if (selected == null) return;
            if (plugin.data().isUnlocked(player.getUniqueId(), selected.id())) {
                plugin.sendMessage(player, "already-unlocked", "%name%", selected.name(), "%command%", "/" + selected.primaryCommand());
            } else if (!plugin.missingRequiredPlugins(selected).isEmpty()
                    || CommandAvailabilityPolicy.blocksPurchase(plugin.unlocks().commandRegistrationStatus(selected))
                    || !plugin.tasks().requirementsMet(player.getUniqueId(), selected)
                    || plugin.points().balance(player.getUniqueId()) < selected.cost()) {
                // Keep the existing explanatory purchase checks for locked/underfunded entries.
                plugin.purchases().purchase(player, selected, holder);
            } else {
                openConfirmation(player, holder.category(), holder.page(), selected.id());
            }
            return;
        }

        int cardIndex = indexOf(CARD_SLOTS, slot);
        if (cardIndex >= 0) {
            List<UnlockDefinition> definitions = filteredDefinitions(player, holder.category());
            if (definitions.isEmpty() && cardIndex == 0 && !searchQuery(player.getUniqueId()).isBlank()) {
                searchQueries.remove(player.getUniqueId());
                plugin.sendMessage(player, "search-cleared");
                open(player, holder.category(), 0, firstId(player, holder.category()), false);
                return;
            }
            int index = holder.page() * CARD_SLOTS.length + cardIndex;
            if (index < definitions.size()) {
                open(player, holder.category(), holder.page(), definitions.get(index).id(), false);
            }
        }
    }

    private InventoryCreation createMainInventory(MenuHolder holder, int size, String title) {
        String coloredTitle = plugin.color(title);
        if (!plugin.getConfig().getBoolean("settings.itemsadder-textured-gui", false)
                || !plugin.getServer().getPluginManager().isPluginEnabled("ItemsAdder")) {
            lastTexturedGuiCreationSucceeded = false;
            return new InventoryCreation(Bukkit.createInventory(holder, size, coloredTitle), false);
        }
        String fontImageId = plugin.getConfig().getString("settings.itemsadder-font-image", "warriorland_unlocks:command_menu_background");
        int titleOffset = Math.max(-512, Math.min(512, plugin.getConfig().getInt("settings.itemsadder-title-offset", 0)));
        int textureOffset = Math.max(-512, Math.min(512, plugin.getConfig().getInt("settings.itemsadder-texture-offset", 0)));
        try {
            Class<?> fontImageType = Class.forName("dev.lone.itemsadder.api.FontImages.FontImageWrapper");
            Object fontImage = fontImageType.getConstructor(String.class).newInstance(fontImageId);
            try {
                Object exists = fontImageType.getMethod("exists").invoke(fontImage);
                if (exists instanceof Boolean found && !found) {
                    throw new IllegalStateException("ItemsAdder font image does not exist: " + fontImageId);
                }
            } catch (NoSuchMethodException ignored) {
                // Older ItemsAdder builds may not expose exists(); inventory creation below is still validated.
            }
            Class<?> wrapperType = Class.forName("dev.lone.itemsadder.api.FontImages.TexturedInventoryWrapper");
            ItemsAdderConstructorPolicy.Plan plan = ItemsAdderConstructorPolicy.findBest(
                    wrapperType, holder.getClass(), fontImageType);
            if (plan == null) {
                throw new NoSuchMethodException("No compatible TexturedInventoryWrapper constructor (offset-aware or legacy) was found");
            }
            Object wrapper = plan.create(holder, size, coloredTitle, fontImage, fontImageType, titleOffset, textureOffset);
            Object result = wrapperType.getMethod("getInternal").invoke(wrapper);
            if (!(result instanceof Inventory inventory) || inventory.getSize() != size
                    || !(inventory.getHolder() instanceof MenuHolder)) {
                throw new IllegalStateException("ItemsAdder returned an inventory with an unexpected holder or size");
            }
            lastTexturedGuiCreationSucceeded = true;
            return new InventoryCreation(inventory, true);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException failure) {
            lastTexturedGuiCreationSucceeded = false;
            if (!warnedItemsAdderGuiSkinUnavailable) {
                warnedItemsAdderGuiSkinUnavailable = true;
                plugin.getLogger().warning("ItemsAdder GUI skin is enabled but its API/background is unavailable; using the safe vanilla inventory. "
                        + "Check the WarriorLand ItemsAdder add-on and itemsadder-font-image. Cause: " + failure.getClass().getSimpleName());
            }
            return new InventoryCreation(Bukkit.createInventory(holder, size, coloredTitle), false);
        }
    }

    private void fillBackground(Inventory inventory, boolean texturedBackground) {
        if (texturedBackground) {
            // ItemsAdder draws a custom glyph background over the vanilla chest texture.
            // Empty slots are intentional and remain click-cancelled by the menu listener.
            inventory.clear();
            return;
        }
        ItemStack filler = item(Material.BLACK_STAINED_GLASS_PANE, "&0", List.of());
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, filler);
        ItemStack panel = item(Material.PURPLE_STAINED_GLASS_PANE, "&5", List.of());
        for (int slot : DETAIL_SLOTS) inventory.setItem(slot, panel);
        ItemStack separator = item(Material.BLUE_STAINED_GLASS_PANE, "&1", List.of());
        for (int slot : SEPARATOR_SLOTS) inventory.setItem(slot, separator);
        for (int slot : CARD_SLOTS) inventory.setItem(slot,
                item(Material.GRAY_STAINED_GLASS_PANE, "&8Volné místo", List.of("&7V této kategorii už další příkaz není.")));
    }

    private void renderHeader(Player player, Inventory inventory, MenuHolder holder, int balance) {
        int commandCount = plugin.unlocks().inCategory(holder.category()).size();
        if (holder.pointsView()) {
            inventory.setItem(1, item(Material.GOLD_INGOT, "&6Moje body", List.of(
                    "&7Saldo, získané a utracené PP."), true));
            inventory.setItem(2, item(Material.AMETHYST_SHARD, "&5Přehled bodů", List.of(
                    "&7Zůstatek, získané a utracené body.")));
            inventory.setItem(3, item(Material.NETHER_STAR, "&bStatistiky", List.of(
                    "&7Saldo pochází z PlayerPoints.", "&7Historie je jen z tohoto systému.")));
            inventory.setItem(4, item(Material.COMPASS, "&eZpět do katalogu", List.of(
                    "&7Klikni na šipku v dolní liště.")));
            inventory.setItem(5, item(Material.SPYGLASS, "&fJak získat body", List.of(
                    "&7Plň úkoly u jednotlivých příkazů.", "&7Splněné úkoly mohou připsat PP.")));
        } else {
            inventory.setItem(1, item(Material.COMMAND_BLOCK, "&dPříkazy", List.of(
                    "&7Vyber příkaz, splň úkoly a odemkni jej za PP."), true));
            String query = searchQuery(player.getUniqueId());
            int visibleCount = filteredDefinitions(player, holder.category()).size();
            inventory.setItem(2, item(Material.SPYGLASS,
                    query.isBlank() ? "&b&lHledat příkaz" : "&b&lHledání: &f" + truncate(query, 18),
                    List.of("&7Hledá název, příkaz, alias a popis.",
                            "&7Výsledek: &f" + visibleCount + "&7 z &f" + commandCount,
                            "", "&eKlikni a napiš hledaný výraz.", "&7Napiš &eclear &7pro vymazání nebo &czrušit &7pro návrat."), !query.isBlank()));
            String sort = sortMode(player.getUniqueId());
            inventory.setItem(3, item(Material.HOPPER, "&d&lŘazení: &f" + CommandSearchPolicy.label(sort), List.of(
                    "&7Změní pořadí viditelných příkazů.",
                    "&fVýchozí &8· &fDostupnost", "&fCena vzestupně / sestupně", "&fNázev A–Z",
                    "", "&eKlikni pro další způsob."), true));
            inventory.setItem(4, item(Material.COMPASS, "&e" + categoryName(holder.category()), List.of(
                    "&7Kategorie: &f" + commandCount + " příkazů",
                    "&7Na stránce: &f" + CARD_SLOTS.length,
                    "&7Stránka: &f" + (holder.page() + 1), "&8Přepnutí je vlevo.")));
            inventory.setItem(5, item(Material.BOOK, "&d&lTUTORIÁL", List.of(
                    "&7Průvodce kategoriemi, kartami, úkoly", "&7a bezpečným potvrzením nákupu.", "", "&eKlikni pro spuštění návodu."), true));
        }
        inventory.setItem(6, item(Material.GOLD_INGOT, "&6&l" + balance + " PP", List.of(
                "&7Aktuální zůstatek PlayerPoints.", "&7Body se odečtou až po potvrzení.", "", "&eKlikni pro statistiky bodů."), true));
    }

    private void renderSidebar(Player player, Inventory inventory, MenuHolder holder) {
        var section = plugin.getConfig().getConfigurationSection("categories");
        Set<Integer> usedSidebarSlots = new HashSet<>();
        if (section != null) {
            for (String id : section.getKeys(false)) {
                String path = "categories." + id + ".";
                int slot = plugin.getConfig().getInt(path + "slot", -1);
                if (!isSidebarCategorySlot(slot)) {
                    plugin.getLogger().warning("Kategorie '" + id + "' má slot " + slot + "; kategorie patří do levého panelu na sloty 0, 9, 18, 27 nebo 36. Položku skrývám.");
                    continue;
                }
                if (!usedSidebarSlots.add(slot)) {
                    plugin.getLogger().warning("Kategorie '" + id + "' sdílí slot " + slot + " s jinou kategorií; položku skrývám.");
                    continue;
                }
                String name = plugin.getConfig().getString(path + "name", id);
                String icon = plugin.getConfig().getString(path + "icon", "ENDER_EYE");
                boolean selected = !holder.pointsView() && holder.category().equalsIgnoreCase(id);
                int count = plugin.unlocks().inCategory(id).size();
                List<String> lore = selected
                        ? List.of("&aVybraná kategorie", "&7Dostupných položek: &f" + count, "", "&ePrávě zobrazená")
                        : List.of("&7Příkazy v kategorii: &f" + count, "", "&eKlikni pro otevření");
                inventory.setItem(slot, item(icon, Material.ENDER_EYE, (selected ? "&a» &f" : "&7") + name, lore, selected));
            }
        }
        boolean pointsSelected = holder.pointsView();
        inventory.setItem(45, item(Material.GOLD_INGOT, (pointsSelected ? "&a» &e" : "&6") + "Moje body",
                List.of("&7Zůstatek PlayerPoints", "&7Body získané z úkolů", "&7Body utracené za odemčení", "", "&eKlikni pro přehled"), pointsSelected));
    }

    private void renderCards(Player player, Inventory inventory, MenuHolder holder, int balance) {
        List<UnlockDefinition> definitions = filteredDefinitions(player, holder.category());
        if (definitions.isEmpty()) {
            String query = searchQuery(player.getUniqueId());
            inventory.setItem(CARD_SLOTS[0], item(Material.BARRIER, "&c&lŽÁDNÉ VÝSLEDKY", List.of(
                    "&7Pro hledání: &f" + (query.isBlank() ? "(bez filtru)" : truncate(query, 32)),
                    "&7Zkus kratší nebo obecnější výraz.", "", "&eKliknutím sem vymažeš hledání."), true));
            inventory.setItem(CARD_SLOTS[5], item(Material.SPYGLASS, "&bZkus jiné hledání", List.of(
                    "&7Klikni nahoře na Hledat příkaz", "&7a zadej jiný výraz.")));
            return;
        }
        int start = holder.page() * CARD_SLOTS.length;
        for (int i = 0; i < CARD_SLOTS.length; i++) {
            int index = start + i;
            if (index >= definitions.size()) break;
            UnlockDefinition definition = definitions.get(index);
            boolean unlocked = plugin.data().isUnlocked(player.getUniqueId(), definition.id());
            boolean complete = plugin.tasks().requirementsMet(player.getUniqueId(), definition);
            List<String> missingDependencies = plugin.missingRequiredPlugins(definition);
            CommandAvailabilityPolicy.Status commandStatus = plugin.unlocks().commandRegistrationStatus(definition);
            boolean commandMissing = CommandAvailabilityPolicy.blocksPurchase(commandStatus);
            boolean unavailable = !missingDependencies.isEmpty() || commandMissing;
            boolean canBuy = complete && balance >= definition.cost() && !unlocked && !unavailable;
            boolean selected = definition.id().equals(holder.selectedId());

            String status;
            String titleColor;
            if (unlocked) {
                status = unavailable ? "&a[ODEMČENO] &cPLUGIN CHYBÍ" : "&a[ODEMČENO]";
                titleColor = "&a";
            } else if (unavailable) {
                status = "&c[NEDOSTUPNÉ]";
                titleColor = "&c";
            } else if (canBuy) {
                status = "&e[PŘIPRAVENO]";
                titleColor = "&e";
            } else if (complete) {
                status = "&6[CHYBÍ BODY]";
                titleColor = "&6";
            } else {
                status = "&7[ZAMČENO]";
                titleColor = "&f";
            }

            List<String> lore = new ArrayList<>();
            lore.add(status);
            lore.add("&f" + definition.name());
            lore.addAll(wrapLore(definition.description(), 34, "&7"));
            lore.add("");
            lore.add("&6Cena: &e" + definition.cost() + " PP");
            lore.add("&7Úkoly: &f" + taskSummary(player, definition));
            if (unavailable) {
                if (!missingDependencies.isEmpty()) {
                    lore.add("&cChybí plugin:");
                    for (String dependency : missingDependencies) lore.addAll(wrapLore(dependency, 34, "&c- "));
                }
                if (commandMissing) lore.addAll(wrapLore("Není registrován příkaz /" + definition.primaryCommand(), 34, "&c"));
            } else if (commandStatus == CommandAvailabilityPolicy.Status.UNKNOWN) {
                lore.add("&eDostupnost příkazu nelze ověřit automaticky.");
            } else if (!unlocked && complete && balance < definition.cost()) {
                lore.add("&cChybí bodů: &e" + (definition.cost() - balance) + " PP");
            }
            if (definition.commands().size() > 1) lore.add("&dAliasů: &f" + (definition.commands().size() - 1));
            lore.add("");
            lore.add(selected ? "&dVybráno — detail vpravo" : "&eKlikni pro podrobnosti");

            // Use the actual command as the short, scannable card title. The human-readable
            // feature name and its wrapped explanation stay together in the tooltip.
            String cardTitle = titleColor + "&l/" + definition.primaryCommand();
            String visualState = CommandCardVisualPolicy.variant(unlocked, unavailable, complete, balance >= definition.cost());
            inventory.setItem(CARD_SLOTS[i], commandIcon(player, definition, cardTitle, lore, selected || canBuy || unlocked, visualState));
        }
    }

    private void renderQuickGuide(Player player, MenuHolder holder, Inventory inventory) {
        UUID playerId = player.getUniqueId();
        UnlockDefinition selected = plugin.unlocks().byId(holder.selectedId());
        int currentTasks = 0;
        int totalTasks = 0;
        if (selected != null) {
            for (TaskDefinition task : selected.tasks()) {
                totalTasks++;
                if (HudStatusPolicy.isTaskComplete(plugin.data().getTaskProgress(playerId, selected.id(), task.id()), task.amount())) currentTasks++;
            }
        }
        int balance = plugin.points().balance(playerId);
        int earned = plugin.data().getPointsEarnedFromTasks(playerId);
        int spent = plugin.data().getPointsSpentOnUnlocks(playerId);
        boolean hudEnabled = plugin.hud().statusBarEnabled(playerId);

        inventory.setItem(QUICK_INFO_SLOTS[0], item(Material.IRON_PICKAXE, "&b&lTVÉ ÚKOLY &8· &f" + currentTasks + "/" + totalTasks, List.of(
                selected == null ? "&7Vyber příkaz a zobraz jeho úkoly." : "&7Vybráno: &f/" + selected.primaryCommand(),
                "&7Splněno: &b" + currentTasks + "/" + totalTasks,
                "", "&eKlikni pro vysvětlení úkolů.")));
        inventory.setItem(QUICK_INFO_SLOTS[1], item(Material.GOLD_INGOT, "&6&lMOJE BODY &8· &e" + balance + " PP", List.of(
                "&7Aktuální saldo PlayerPoints.", "&aZískáno z úkolů: &f+" + earned + " PP", "&cUtraceno za odemčení: &f-" + spent + " PP", "", "&eKlikni pro celý bodový přehled."), true));
        inventory.setItem(QUICK_INFO_SLOTS[2], item(Material.EMERALD, "&a&lLEGENDA STAVŮ", List.of(
                "&a✔ Odemčeno  &e● Připraveno", "&6● Chybí body  &7● Zamčeno", "&c✖ Nedostupné (závislost)", "", "&eKlikni pro vysvětlení barev.")));
        inventory.setItem(QUICK_INFO_SLOTS[3], item(hudEnabled ? Material.BEACON : Material.REDSTONE_TORCH,
                (hudEnabled ? "&d&lHUD ZAPNUTÝ" : "&7&lHUD VYPNUTÝ"), List.of(
                        hudEnabled ? "&7BossBar zobrazuje PP, příkazy" : "&7Zapni přehledný fialový BossBar.",
                        hudEnabled ? "&7a dokončené úkoly." : "&7a postup úkolů.",
                        "&7HUD lze přepnout i příkazem:", "&f/prikazy hud on|off", "", "&eKlikni pro přepnutí."), hudEnabled));
    }

    private void renderDetails(Player player, Inventory inventory, MenuHolder holder, int balance) {
        UnlockDefinition definition = plugin.unlocks().byId(holder.selectedId());
        if (definition == null) {
            inventory.setItem(7, item(Material.BOOK, "&dDetail příkazu", List.of("&7Vyber jednu z karet vlevo.")));
            inventory.setItem(8, item(Material.PAPER, "&fČekám na výběr", List.of("&7Zde uvidíš příkaz, cenu,", "&7požadavky a stav odemčení.")));
            inventory.setItem(43, item(Material.GRAY_DYE, "&7Nejdřív vyber příkaz", List.of("&7Klikni na jednu z karet.")));
            inventory.setItem(44, item(Material.GRAY_STAINED_GLASS_PANE, "&8", List.of()));
            return;
        }

        boolean unlocked = plugin.data().isUnlocked(player.getUniqueId(), definition.id());
        boolean complete = plugin.tasks().requirementsMet(player.getUniqueId(), definition);
        List<String> missingDependencies = plugin.missingRequiredPlugins(definition);
        CommandAvailabilityPolicy.Status commandStatus = plugin.unlocks().commandRegistrationStatus(definition);
        boolean commandMissing = CommandAvailabilityPolicy.blocksPurchase(commandStatus);
        boolean unavailable = !missingDependencies.isEmpty() || commandMissing;
        boolean canBuy = !unlocked && complete && balance >= definition.cost() && !unavailable;

        String visualState = CommandCardVisualPolicy.variant(unlocked, unavailable, complete, balance >= definition.cost());
        inventory.setItem(7, commandIcon(player, definition, "&dVybraná funkce", List.of(
                "&7Interní ID: &8" + definition.id(),
                "&7Kategorie: &f" + categoryName(definition.category())), true, visualState));
        List<String> commandLore = new ArrayList<>();
        commandLore.add("&f" + definition.name());
        commandLore.add("");
        commandLore.addAll(wrapLore(definition.description(), 34, "&7"));
        inventory.setItem(8, item(Material.COMMAND_BLOCK, "&f&l/" + definition.primaryCommand(), commandLore));

        String stateName = unlocked
                ? (unavailable ? "&aVlastníš &8· &cplugin chybí" : "&aOdemčeno")
                : unavailable ? "&cNedostupné"
                : canBuy ? "&ePřipraveno k odemčení"
                : complete ? "&6Úkoly hotové — chybí body" : "&7Zamčeno";
        List<String> stateLore = new ArrayList<>();
        if (unlocked) stateLore.add(unavailable ? "&cVlastnictví zůstává, ale plugin chybí." : "&aTuto funkci už vlastníš.");
        else if (unavailable) {
            if (!missingDependencies.isEmpty()) {
                stateLore.add("&cChybí zapnutá závislost:");
                for (String dependency : missingDependencies) stateLore.addAll(wrapLore(dependency, 32, "&c- "));
            }
            if (commandMissing) stateLore.addAll(wrapLore("Server aktuálně neregistruje /" + definition.primaryCommand() + ".", 32, "&c"));
            stateLore.add("&cNákup je zablokovaný.");
        } else if (commandStatus == CommandAvailabilityPolicy.Status.UNKNOWN) {
            stateLore.add("&eDostupnost příkazu nelze automaticky ověřit.");
            stateLore.add("&7Ověř příkaz na testovacím serveru.");
        } else if (!complete) stateLore.add("&7Nejdřív dokonči požadované úkoly.");
        else if (balance < definition.cost()) stateLore.add("&cChybí &e" + (definition.cost() - balance) + " PP&c.");
        else {
            stateLore.add("&aVšechny nákupní podmínky jsou splněny.");
            if (commandStatus == CommandAvailabilityPolicy.Status.UNKNOWN) {
                stateLore.add("&eRegistraci příkazu nelze automaticky ověřit.");
            }
        }
        inventory.setItem(15, item(unavailable ? Material.BARRIER : unlocked ? Material.LIME_DYE : canBuy ? Material.GOLD_INGOT : Material.GRAY_DYE,
                stateName, stateLore, unlocked && !unavailable || canBuy));
        inventory.setItem(16, item(Material.NAME_TAG, "&fPříkazy a aliasy", definition.commands().stream()
                .map(command -> (command.equalsIgnoreCase(definition.primaryCommand()) ? "&aHlavní: /" : "&dAlias: /") + command).toList()));
        inventory.setItem(17, item(Material.COMPASS, "&bKategorie", List.of(
                "&f" + categoryName(definition.category()), "", "&7Jedna položka = jedno vlastnictví.",
                "&7Alias se nekupuje samostatně.")));

        List<String> descriptionLore = new ArrayList<>();
        descriptionLore.add("&7Stručný popis:");
        descriptionLore.addAll(wrapLore(definition.description(), 34, "&f"));
        descriptionLore.add("");
        descriptionLore.add("&8Příkaz musí poskytovat serverový plugin.");
        inventory.setItem(24, item(Material.WRITABLE_BOOK, "&dCo funkce dělá", descriptionLore));

        List<String> taskLore = new ArrayList<>();
        taskLore.add("&d&lPOŽADOVANÉ ÚKOLY");
        if (definition.tasks().isEmpty()) {
            taskLore.add("&aBez úkolu — podmínka splněna.");
        } else {
            for (TaskDefinition task : definition.tasks()) {
                int current = plugin.data().getTaskProgress(player.getUniqueId(), definition.id(), task.id());
                boolean done = current >= task.amount();
                taskLore.addAll(wrapLore(task.description(), 32, done ? "&a- " : "&7- "));
                taskLore.add("  " + progressBar(current, task.amount()));
                taskLore.add("  " + (done ? "&a" : "&f") + Math.min(current, task.amount()) + "&7/&f" + task.amount());
            }
        }
        inventory.setItem(25, item(Material.WRITABLE_BOOK, "&eÚkoly a postup", taskLore));
        inventory.setItem(26, item(Material.MAP, "&bSouhrn postupu", List.of(
                "&7Splněno: &f" + taskSummary(player, definition),
                "&7Odměna za úkoly: &a+" + definition.taskReward() + " PP",
                "", "&8Postup se ukládá podle UUID hráče.")));

        List<String> costLore = new ArrayList<>();
        costLore.add("&7Cena odemčení:");
        costLore.add("&6&l" + definition.cost() + " PP");
        costLore.add("");
        costLore.add("&7Tvůj zůstatek: &e" + balance + " PP");
        if (!unlocked && complete && balance < definition.cost()) costLore.add("&cChybí: " + (definition.cost() - balance) + " PP");
        costLore.add("");
        costLore.add("&8Nákup se provede až po potvrzení.");
        inventory.setItem(33, item(Material.GOLD_INGOT, "&6Cena: &e" + definition.cost() + " PP", costLore, canBuy));
        inventory.setItem(34, item(Material.EMERALD, "&aOdměna: +" + definition.taskReward() + " PP", List.of(
                "&7Za splněné úkoly získáš:", "&a+" + definition.taskReward() + " PP",
                "", "&8Odměna je součástí pravidel položky.")));
        inventory.setItem(35, item(Material.CHAIN, "&dAliasy bez příplatku", List.of(
                "&7Zakoupením se aktivuje každá", "&7schválená varianta této funkce.",
                "", "&8Neprovádí se druhá platba.")));

        inventory.setItem(42, item(unavailable ? Material.BARRIER : unlocked ? Material.LIME_DYE : complete ? Material.YELLOW_DYE : Material.GRAY_DYE,
                "&fSplnění podmínek", List.of(
                        unlocked ? "&aVlastníš tuto funkci." : unavailable ? "&cFunkce není dostupná." : complete ? "&aÚkoly dokončeny." : "&7Úkoly čekají na splnění.",
                        "&7Body: &e" + balance + " PP", "&7Cena: &6" + definition.cost() + " PP")));
        if (unlocked) {
            inventory.setItem(43, item(unavailable ? Material.BARRIER : Material.LIME_DYE,
                    unavailable ? "&cVlastníš, ale plugin chybí" : "&aOdemčeno",
                    List.of(unavailable ? "&cChybí: " + String.join(", ", missingDependencies) : "&aMůžeš příkaz používat.", "&7Další nákup není potřeba."), !unavailable));
        } else if (unavailable) {
            String unavailableTitle = commandMissing && missingDependencies.isEmpty() ? "&cPříkaz není registrován" : "&cFunkce není dostupná";
            List<String> unavailableLore = new ArrayList<>();
            if (!missingDependencies.isEmpty()) unavailableLore.addAll(wrapLore("Chybí plugin: " + String.join(", ", missingDependencies), 32, "&c"));
            if (commandMissing) unavailableLore.addAll(wrapLore("Není registrován /" + definition.primaryCommand(), 32, "&c"));
            unavailableLore.add("&cNákup není povolen.");
            inventory.setItem(43, item(Material.BARRIER, unavailableTitle, unavailableLore));
        } else if (!complete) {
            inventory.setItem(43, item(Material.GRAY_DYE, "&7Nejdřív dokonči úkoly", List.of("&7Ještě nesplňuješ podmínky.", "&ePodrobnosti jsou výše.")));
        } else if (balance < definition.cost()) {
            inventory.setItem(43, item(Material.ORANGE_DYE, "&6Nedostatek bodů", List.of("&7Chybí ti &e" + (definition.cost() - balance) + " PP", "&7Další body můžeš získat úkoly.")));
        } else {
            inventory.setItem(43, item(Material.EMERALD_BLOCK, "&aOdemknout funkci", List.of(
                    "&7Odemkne: &f/" + definition.primaryCommand(),
                    "&7Cena: &6" + definition.cost() + " PP", "", "&eKlikni pro potvrzení nákupu."), true));
        }
        inventory.setItem(44, item(Material.PURPLE_STAINED_GLASS_PANE, "&5Nákup se potvrzuje zvlášť", List.of(
                "&7Záměrně ve dvou krocích.", "&7Nejdřív detail, potom potvrzení.", "", "&8Zavření menu nic nekoupí.")));
    }

    /**
     * Uses a Paper item-model string understood by the optional 1.21.10 resource pack.
     * With the setting disabled (the safe default), normal vanilla/ItemsAdder icons remain untouched.
     */
    private ItemStack commandIcon(Player player, UnlockDefinition definition, String name, List<String> lore, boolean glow, String visualState) {
        boolean customPack = plugin.getConfig().getBoolean("settings.use-resource-pack-icons", false);
        // Missing listener is not proof of pack delivery. Use vanilla icons unless the listener
        // explicitly verifies the current pack (or the administrator opts into unverified manual mode).
        boolean packAvailable = plugin.resourcePackListener() != null
                && plugin.resourcePackListener().canUseCustomIcons(player);
        if (!customPack || !packAvailable || isItemsAdderIcon(definition.icon())) {
            return item(definition.icon(), Material.PAPER, name, lore, glow);
        }
        ItemStack stack = new ItemStack(Material.PAPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null || !applyCustomItemModel(meta, "warriorland:command_icons/" + safeModelKey(definition.id()) + "_" + safeModelKey(visualState))) {
            return item(definition.icon(), Material.PAPER, name, lore, glow);
        }
        meta.setDisplayName(plugin.color(name));
        meta.setLore(lore.stream().map(plugin::color).toList());
        if (glow) {
            meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private String safeModelKey(String value) {
        String key = value == null ? "unknown" : value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_.-]", "_");
        return key.isBlank() ? "unknown" : key;
    }

    private boolean applyCustomItemModel(ItemMeta meta, String modelKey) {
        try {
            Class<?> namespacedKeyType = Class.forName("org.bukkit.NamespacedKey");
            Object key = namespacedKeyType.getMethod("fromString", String.class).invoke(null, modelKey);
            if (key == null) return false;
            ItemMeta.class.getMethod("setItemModel", namespacedKeyType).invoke(meta, key);
            return true;
        } catch (ReflectiveOperationException | LinkageError failure) {
            plugin.getLogger().warning("Vlastní resource-pack model není podporovaný aktuálním API; používám vanilla ikonu. Důvod: " + failure.getClass().getSimpleName());
            return false;
        }
    }

    private List<String> wrapLore(String text, int maxWidth, String color) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isBlank()) return List.of(color + "Bez dodatečného popisu.");
        StringBuilder line = new StringBuilder();
        for (String word : text.trim().split("\\s+")) {
            if (line.length() > 0 && line.length() + word.length() + 1 > maxWidth) {
                lines.add(color + line);
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(word);
        }
        if (line.length() > 0) lines.add(color + line);
        return lines;
    }

    private void renderPoints(Player player, Inventory inventory, int balance) {
        int earned = plugin.data().getPointsEarnedFromTasks(player.getUniqueId());
        int spent = plugin.data().getPointsSpentOnUnlocks(player.getUniqueId());
        inventory.setItem(7, item(Material.BOOK, "&6&lBODOVÝ PŘEHLED", List.of("&7Statistiky odemykacího systému.")));
        inventory.setItem(8, item(Material.GOLD_INGOT, "&e&l" + balance + " PP", List.of("&7Aktuální PlayerPoints saldo.", "&8Zůstatek se načítá při otevření."), true));
        inventory.setItem(11, item(Material.GOLD_INGOT, "&6&lAKTUÁLNÍ ZŮSTATEK", List.of(
                "&7Načteno přímo z PlayerPoints:", "", "&e&l" + balance + " PP"), true));
        inventory.setItem(12, item(Material.EMERALD, "&a&lZÍSKÁNO Z ÚKOLŮ", List.of(
                "&7Body připsané tímto systémem:", "", "&a+" + earned + " PP")));
        inventory.setItem(13, item(Material.REDSTONE, "&c&lUTRACENO ZA PŘÍKAZY", List.of(
                "&7Body za zakoupená odemčení:", "", "&c-" + spent + " PP")));
        inventory.setItem(14, item(Material.BOOK, "&d&lJAK ZÍSKAT BODY", List.of(
                "&7Dokončuj úkoly v katalogu.", "&7Těžba, rybaření, crafting", "&7nebo boj podle požadavků.")));
        inventory.setItem(20, item(Material.IRON_PICKAXE, "&b&lTĚŽBA", List.of("&7Pokud ji příkaz vyžaduje,", "&7počítá se rozbití daných bloků.")));
        inventory.setItem(21, item(Material.FISHING_ROD, "&b&lRYBAŘENÍ", List.of("&7Počítají se úspěšné úlovky,", "&7nikoli pouhé nahození.")));
        inventory.setItem(22, item(Material.CRAFTING_TABLE, "&b&lCRAFTING", List.of("&7Počítá se vytvoření položek", "&7podle požadavků úkolu.")));
        inventory.setItem(23, item(Material.IRON_SWORD, "&b&lBOJ", List.of("&7Některé funkce vyžadují", "&7zabití určených mobů.")));
        inventory.setItem(24, item(Material.BOOK, "&d&lPŘEHLED", List.of("&7Zůstatek je aktuální saldo.", "&7Ostatní částky sledují pouze", "&7činnost odemykacího pluginu.")));
        inventory.setItem(25, item(Material.EMERALD, "&a&lODMĚNY", List.of("&7Celkem získáno z úkolů:", "&a+" + earned + " PP")));
        inventory.setItem(26, item(Material.REDSTONE, "&c&lNÁKUPY", List.of("&7Celkem utraceno:", "&c-" + spent + " PP")));
        inventory.setItem(33, item(Material.CLOCK, "&f&lAKTUALIZACE", List.of("&7Saldo načítá PlayerPoints.", "&7Změny jiných pluginů se", "&7projeví při opětovném otevření.")));
        inventory.setItem(34, item(Material.BOOK, "&d&lULOŽENÍ", List.of("&7Vlastnictví se ukládá", "&7trvale podle UUID hráče.")));
        inventory.setItem(35, item(Material.SHIELD, "&a&lBEZPEČNÝ NÁKUP", List.of("&7Nákup se vždy potvrzuje.", "&7Duplicitní nákup je odmítnut.")));
        inventory.setItem(42, item(Material.AMETHYST_SHARD, "&dMoje statistiky", List.of("&7Získáno: &a+" + earned + " PP", "&7Utraceno: &c-" + spent + " PP")));
        inventory.setItem(43, item(Material.PAPER, "&eDůležité", List.of("&7Cena příkazu a aktuální", "&7zůstatek jsou viditelné", "&7v jeho detailu.")));
        inventory.setItem(44, item(Material.ARROW, "&dNávrat", List.of("&7Zpět do katalogu dole.")));
        inventory.setItem(48, item(Material.ARROW, "&d&lZPĚT DO KATALOGU", List.of("&7Vrátí tě na seznam příkazů.", "&7Bez nákupu a bez změny bodů."), true));
        inventory.setItem(49, item(Material.PAPER, "&f&lSTATISTIKY", List.of("&7Získáno a utraceno", "&7se týká jen tohoto pluginu.")));
        inventory.setItem(50, item(Material.BARRIER, "&8Stránkování není v přehledu bodů", List.of()));
    }

    private void renderPaging(Player player, Inventory inventory, MenuHolder holder) {
        int count = filteredDefinitions(player, holder.category()).size();
        int maxPage = Math.max(0, (count - 1) / CARD_SLOTS.length);
        inventory.setItem(46, item(Material.ARROW, "&dPředchozí stránka", List.of("&7Stránka " + (holder.page() + 1) + "/" + (maxPage + 1), "&7Klikni pro předchozí příkazy."), holder.page() > 0));
        inventory.setItem(47, item(Material.COMPASS, "&b" + categoryName(holder.category()), List.of("&7Položek v kategorii: &f" + count, "&7Zobrazeno na této stránce: &f" + Math.max(0, Math.min(CARD_SLOTS.length, count - holder.page() * CARD_SLOTS.length)))));
        inventory.setItem(48, item(Material.PAPER, "&fStránka " + (holder.page() + 1) + " / " + (maxPage + 1), List.of("&7Katalog příkazů", "&7Celkem v kategorii: &f" + count)));
        UnlockDefinition selected = plugin.unlocks().byId(holder.selectedId());
        inventory.setItem(49, item(Material.NAME_TAG, "&dVybraná položka", List.of(selected == null ? "&7Zatím není vybrána." : "&f/" + selected.primaryCommand(), "&7Detail se zobrazuje vpravo.")));
        inventory.setItem(50, item(Material.ARROW, "&dDalší stránka", List.of("&7Stránka " + (holder.page() + 1) + "/" + (maxPage + 1), "&7Klikni pro další příkazy."), holder.page() < maxPage));
        inventory.setItem(51, item(Material.BOOK, "&eJak nakupovat", List.of("&71. Vyber kartu.", "&72. Zkontroluj cenu a úkoly.", "&73. Potvrď nákup.")));
        inventory.setItem(52, item(Material.LANTERN, "&bStavy příkazů", List.of("&aZelená = odemčeno", "&eZlatá = připraveno", "&7Šedá = zamčeno", "&cČervená = chybí plugin")));
    }

    private String progressBar(int current, int target) {
        int safeTarget = Math.max(1, target);
        int percent = (int) Math.min(100L, Math.max(0L, (long) Math.max(0, current) * 100L / safeTarget));
        int filled = percent / 10;
        return (percent >= 100 ? "&a" : "&e") + "=".repeat(filled)
                + "&8" + "-".repeat(10 - filled) + " &7" + percent + "%";
    }

    private String taskSummary(Player player, UnlockDefinition definition) {
        if (definition.tasks().isEmpty()) return "bez úkolu";
        long complete = definition.tasks().stream().filter(task -> plugin.data().getTaskProgress(player.getUniqueId(), definition.id(), task.id()) >= task.amount()).count();
        return complete + "/" + definition.tasks().size() + " splněno";
    }

    private String firstId(Player player, String category) {
        return firstIdOnPage(player, category, 0);
    }

    private String firstIdOnPage(Player player, String category, int page) {
        List<UnlockDefinition> definitions = filteredDefinitions(player, category);
        int index = Math.max(0, page) * CARD_SLOTS.length;
        return index < definitions.size() ? definitions.get(index).id() : null;
    }

    private List<UnlockDefinition> filteredDefinitions(Player player, String category) {
        List<UnlockDefinition> source = plugin.unlocks().inCategory(category);
        if (player == null) return source;
        UUID uuid = player.getUniqueId();
        return CatalogViewPolicy.apply(source, searchQuery(uuid), sortMode(uuid), this::categoryName,
                definition -> availabilityRank(player, definition));
    }

    private int availabilityRank(Player player, UnlockDefinition definition) {
        UUID uuid = player.getUniqueId();
        if (!plugin.missingRequiredPlugins(definition).isEmpty()
                || CommandAvailabilityPolicy.blocksPurchase(plugin.unlocks().commandRegistrationStatus(definition))) return 4;
        if (plugin.data().isUnlocked(uuid, definition.id())) return 1;
        if (!plugin.tasks().requirementsMet(uuid, definition)) return 3;
        if (plugin.points().balance(uuid) < definition.cost()) return 2;
        return 0; // Ready to purchase appears first in the availability sort.
    }

    private String canonicalSortMode(String value) {
        if (value == null) return "default";
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "default", "vychozi", "výchozí" -> "default";
            case "availability", "dostupnost", "stav" -> "availability";
            case "price-asc", "cena", "cena-asc", "levne", "levně" -> "price-asc";
            case "price-desc", "cena-desc", "drazsi", "dražší" -> "price-desc";
            case "name", "nazev", "název", "a-z" -> "name";
            default -> value;
        };
    }

    private String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) return value == null ? "" : value;
        return value.substring(0, Math.max(0, maxLength - 1)) + "…";
    }

    private void cancelPendingSearch(UUID playerId) {
        if (awaitingSearchInput.remove(playerId)) pendingSearchReturns.remove(playerId);
        cancelSearchTimeout(playerId);
    }

    private boolean isSidebarCategorySlot(int slot) {
        return MenuLayout.isSidebarCategorySlot(slot);
    }

    private String categoryAtSlot(int slot) {
        if (!isSidebarCategorySlot(slot)) return null;
        var section = plugin.getConfig().getConfigurationSection("categories");
        if (section == null) return null;
        for (String id : section.getKeys(false)) {
            if (plugin.getConfig().getInt("categories." + id + ".slot", -1) == slot) return id;
        }
        return null;
    }

    private String categoryName(String category) {
        return plugin.getConfig().getString("categories." + category + ".name", category);
    }

    private int indexOf(int[] values, int find) {
        for (int i = 0; i < values.length; i++) if (values[i] == find) return i;
        return -1;
    }

    private Material material(String name, Material fallback) {
        if (name == null || name.isBlank() || isItemsAdderIcon(name)) return fallback;
        Material result = Material.matchMaterial(name.trim().toUpperCase(Locale.ROOT));
        return result == null ? fallback : result;
    }

    private boolean isItemsAdderIcon(String iconSpec) {
        return iconSpec != null && (iconSpec.regionMatches(true, 0, "itemsadder:", 0, "itemsadder:".length())
                || iconSpec.regionMatches(true, 0, "ia:", 0, "ia:".length()));
    }

    private ItemStack item(String iconSpec, Material fallback, String name, List<String> lore) {
        return item(iconSpec, fallback, name, lore, false);
    }

    private ItemStack item(String iconSpec, Material fallback, String name, List<String> lore, boolean glow) {
        ItemStack stack = resolveIcon(iconSpec, fallback);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;
        meta.setDisplayName(plugin.color(name));
        meta.setLore(lore.stream().map(plugin::color).toList());
        if (glow) {
            meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack resolveIcon(String iconSpec, Material fallback) {
        if (!isItemsAdderIcon(iconSpec)) return new ItemStack(material(iconSpec, fallback));

        String normalized = iconSpec.trim();
        String itemId = normalized.regionMatches(true, 0, "itemsadder:", 0, "itemsadder:".length())
                ? normalized.substring("itemsadder:".length()).trim()
                : normalized.substring("ia:".length()).trim();
        if (itemId.isBlank() || !itemId.contains(":")) {
            warnMissingIcon(normalized, "Použij formát itemsadder:namespace:id.");
            return new ItemStack(fallback);
        }

        ItemStack cached = itemsAdderIconCache.get(itemId);
        if (cached != null) return cached.clone();
        if (warnedMissingIcons.contains(itemId)) return new ItemStack(fallback);

        try {
            var itemsAdderPlugin = Bukkit.getPluginManager().getPlugin("ItemsAdder");
            if (itemsAdderPlugin == null || !itemsAdderPlugin.isEnabled()) {
                warnMissingIcon(itemId, "ItemsAdder není nainstalovaný nebo zapnutý; používám záložní Minecraft item.");
                return new ItemStack(fallback);
            }
            Class<?> customStackClass = Class.forName("dev.lone.itemsadder.api.CustomStack", true,
                    itemsAdderPlugin.getClass().getClassLoader());
            Method getInstance = customStackClass.getMethod("getInstance", String.class);
            Object customStack = getInstance.invoke(null, itemId);
            if (customStack == null) {
                warnMissingIcon(itemId, "ID vlastního itemu nebylo nalezeno; zkontroluj namespace a ID v ItemsAdderu.");
                return new ItemStack(fallback);
            }
            Object resolved = customStackClass.getMethod("getItemStack").invoke(customStack);
            if (!(resolved instanceof ItemStack iconStack)) {
                warnMissingIcon(itemId, "ItemsAdder nevrátil ItemStack; používám záložní Minecraft item.");
                return new ItemStack(fallback);
            }
            ItemStack safeCopy = iconStack.clone();
            itemsAdderIconCache.put(itemId, safeCopy);
            return safeCopy.clone();
        } catch (ReflectiveOperationException | LinkageError exception) {
            warnMissingIcon(itemId, "Integrace ItemsAdderu není dostupná (" + exception.getClass().getSimpleName() + "); používám záložní Minecraft item.");
            return new ItemStack(fallback);
        }
    }

    private void warnMissingIcon(String itemId, String reason) {
        if (warnedMissingIcons.add(itemId)) {
            plugin.getLogger().warning("Ikona ItemsAdder '" + itemId + "': " + reason);
        }
    }

    public void clearIconCache() {
        itemsAdderIconCache.clear();
        warnedMissingIcons.clear();
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        return item(material, name, lore, false);
    }

    private ItemStack item(Material material, String name, List<String> lore, boolean glow) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;
        meta.setDisplayName(plugin.color(name));
        meta.setLore(lore.stream().map(plugin::color).toList());
        if (glow) {
            meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        stack.setItemMeta(meta);
        return stack;
    }

}
