package cz.warriorland.commandunlocks;

/** Guards the player-data writer against stale asynchronous snapshots. */
public final class SnapshotWritePolicy {
    private SnapshotWritePolicy() { }

    /**
     * A snapshot may be written only when it is not older than either the last durable write or
     * the newest requested snapshot. A false result means a newer snapshot owns persistence.
     */
    public static boolean shouldWrite(long snapshotVersion, long lastWrittenVersion, long newestRequestedVersion) {
        return snapshotVersion >= lastWrittenVersion && snapshotVersion >= newestRequestedVersion;
    }

    /** True only when disk is known to contain this snapshot or a newer one. */
    public static boolean isDurablyWritten(long requestedSnapshotVersion, long lastWrittenVersion) {
        return lastWrittenVersion >= requestedSnapshotVersion;
    }
}
