package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;

/** Optional integration that invalidates cached custom icons after ItemsAdder reloads its registry. */
public final class ItemsAdderHook {
    private static final String LOAD_EVENT_CLASS = "dev.lone.itemsadder.api.Events.ItemsAdderLoadDataEvent";
    private final CommandUnlocksPlugin plugin;
    private boolean registered;

    public boolean isRegistered() { return registered; }

    public ItemsAdderHook(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @SuppressWarnings("unchecked")
    public void registerIfAvailable() {
        if (registered) return;
        Plugin itemsAdder = Bukkit.getPluginManager().getPlugin("ItemsAdder");
        if (itemsAdder == null || !itemsAdder.isEnabled()) return;
        try {
            Class<?> rawEventClass = Class.forName(LOAD_EVENT_CLASS, false, itemsAdder.getClass().getClassLoader());
            if (!Event.class.isAssignableFrom(rawEventClass)) {
                throw new IllegalStateException(LOAD_EVENT_CLASS + " není Bukkit Event.");
            }
            Class<? extends Event> eventClass = (Class<? extends Event>) rawEventClass;
            EventExecutor executor = (listener, event) -> {
                Runnable refresh = () -> {
                    plugin.menus().clearIconCache();
                    for (var player : Bukkit.getOnlinePlayers()) plugin.menus().refresh(player);
                };
                if (event.isAsynchronous()) Bukkit.getScheduler().runTask(plugin, refresh);
                else refresh.run();
            };
            Bukkit.getPluginManager().registerEvent(eventClass, new LoadListenerMarker(), EventPriority.MONITOR,
                    executor, plugin, true);
            registered = true;
            plugin.getLogger().info("Integrace ItemsAdder aktivní: vlastní ikony GUI se obnoví po reloadu ItemsAdderu.");
        } catch (ClassNotFoundException exception) {
            plugin.getLogger().warning("ItemsAdderLoadDataEvent nebyl nalezen; ikony se obnoví při /prikazy admin reload.");
        } catch (Exception | LinkageError exception) {
            plugin.getLogger().warning("Nepodařilo se připojit událost ItemsAdderu: " + exception.getMessage());
        }
    }

    private static final class LoadListenerMarker implements org.bukkit.event.Listener { }
}
