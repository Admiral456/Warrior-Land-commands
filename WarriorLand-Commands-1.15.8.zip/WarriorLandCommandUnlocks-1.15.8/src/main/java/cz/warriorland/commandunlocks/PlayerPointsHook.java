package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;

/** Uses PlayerPoints' public API through reflection so the plugin remains buildable without bundling PlayerPoints. */
public final class PlayerPointsHook {
    private final CommandUnlocksPlugin plugin;
    private final Object api;

    public PlayerPointsHook(CommandUnlocksPlugin plugin) throws ReflectiveOperationException {
        this.plugin = plugin;
        Plugin pointsPlugin = Bukkit.getPluginManager().getPlugin("PlayerPoints");
        if (pointsPlugin == null || !pointsPlugin.isEnabled()) {
            throw new IllegalStateException("PlayerPoints není načtený.");
        }
        Method getApi = pointsPlugin.getClass().getMethod("getAPI");
        this.api = getApi.invoke(pointsPlugin);
        if (api == null) throw new IllegalStateException("PlayerPoints getAPI() vrátil null.");
        if (!hasSupportedBalanceMethod()) {
            throw new NoSuchMethodException("PlayerPoints API neobsahuje kompatibilní look(UUID) s číselným návratovým typem.");
        }
        if (!hasSupportedMutationMethod("take", UUID.class, int.class)
                && !hasSupportedMutationMethod("take", UUID.class, UUID.class, int.class)) {
            throw new NoSuchMethodException("PlayerPoints API neobsahuje bezpečně podporovanou metodu take(...).");
        }
        if (!hasSupportedMutationMethod("give", UUID.class, int.class)
                && !hasSupportedMutationMethod("give", UUID.class, UUID.class, int.class)) {
            throw new NoSuchMethodException("PlayerPoints API neobsahuje bezpečně podporovanou metodu give(...).");
        }
    }

    public int balance(UUID playerId) {
        Integer current = readBalance(playerId);
        return current == null ? 0 : current;
    }

    private Integer readBalance(UUID playerId) {
        try {
            Object value = invoke("look", new Class<?>[]{UUID.class}, playerId);
            if (!(value instanceof Number number)) {
                plugin.getLogger().severe("PlayerPoints look(UUID) vrátil nečíselný zůstatek.");
                return null;
            }
            double rawAmount = number.doubleValue();
            if (!Double.isFinite(rawAmount) || rawAmount != Math.rint(rawAmount)
                    || rawAmount < 0 || rawAmount > Integer.MAX_VALUE) {
                plugin.getLogger().severe("PlayerPoints vrátil zůstatek mimo podporovaný celočíselný rozsah: " + rawAmount);
                return null;
            }
            return (int) rawAmount;
        } catch (ReflectiveOperationException exception) {
            plugin.getLogger().severe("Nepodařilo se načíst PlayerPoints: " + exception.getMessage());
            return null;
        }
    }

    public boolean take(UUID playerId, int amount) {
        if (amount <= 0) return true;
        Class<?>[] twoArgument = {UUID.class, int.class};
        Class<?>[] threeArgument = {UUID.class, UUID.class, int.class};
        try {
            if (hasSupportedMutationMethod("take", twoArgument)) return invokeMutation("take", twoArgument, playerId, amount);
            // Newer PlayerPoints APIs use the second UUID as the source/actor. Null identifies
            // a system-originated transaction; claiming the player as their own source is wrong.
            return invokeMutation("take", threeArgument, playerId, null, amount);
        } catch (ReflectiveOperationException exception) {
            plugin.getLogger().severe("PlayerPoints API neumí bezpečně odečíst body: " + exception.getMessage());
            return false;
        }
    }

    public boolean give(UUID playerId, int amount) {
        if (amount <= 0) return true;
        // PlayerPoints stores balances as int in supported APIs. Reject any known credit that could wrap
        // the stored balance into a negative number instead of relying on the external API's addition.
        Integer currentBalance = readBalance(playerId);
        if (currentBalance == null) return false;
        if (!PointsCreditPolicy.canCredit(currentBalance, amount)) {
            plugin.getLogger().warning("Odmítám připsat " + amount + " PP hráči " + playerId
                    + ", protože by zůstatek překročil podporované maximum " + Integer.MAX_VALUE + ".");
            return false;
        }
        Class<?>[] twoArgument = {UUID.class, int.class};
        Class<?>[] threeArgument = {UUID.class, UUID.class, int.class};
        try {
            if (hasSupportedMutationMethod("give", twoArgument)) return invokeMutation("give", twoArgument, playerId, amount);
            // This is a plugin/system transaction, not a transfer initiated by the player.
            return invokeMutation("give", threeArgument, playerId, null, amount);
        } catch (ReflectiveOperationException exception) {
            plugin.getLogger().severe("PlayerPoints API neumí bezpečně přidat body: " + exception.getMessage());
            return false;
        }
    }

    /** Invoke a mutation only once; some API versions may return void rather than boolean. */
    private boolean invokeMutation(String name, Class<?>[] types, Object... args) throws ReflectiveOperationException {
        Method method = api.getClass().getMethod(name, types);
        if (!PointsMutationPolicy.supportsReturnType(method.getReturnType())) {
            throw new NoSuchMethodException(name + " má nepodporovaný návratový typ " + method.getReturnType().getName());
        }
        Object result = method.invoke(api, args);
        return PointsMutationPolicy.succeeded(method.getReturnType(), result);
    }

    private boolean hasSupportedBalanceMethod() {
        try {
            Class<?> returnType = api.getClass().getMethod("look", UUID.class).getReturnType();
            return returnType == byte.class || returnType == short.class || returnType == int.class || returnType == long.class
                    || Number.class.isAssignableFrom(returnType);
        } catch (NoSuchMethodException ignored) {
            return false;
        }
    }

    private boolean hasSupportedMutationMethod(String name, Class<?>... parameterTypes) {
        try {
            Method method = api.getClass().getMethod(name, parameterTypes);
            return PointsMutationPolicy.supportsReturnType(method.getReturnType());
        } catch (NoSuchMethodException ignored) {
            return false;
        }
    }

    private Object invoke(String name, Class<?>[] types, Object... args) throws ReflectiveOperationException {
        Method method = api.getClass().getMethod(name, types);
        return method.invoke(api, args);
    }
}
