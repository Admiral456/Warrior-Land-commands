package cz.warriorland.commandunlocks;

/** Safe migration of bundled default messages while preserving administrator customizations. */
public final class DefaultMessageMigration {
    public static final String LEGACY_BLOCKED_COMMAND =
            "&cPříkaz &e%command% &cje zamčený. Splň jeho úkoly a odemkni ho v menu &e/prikazy&c.";
    public static final String CURRENT_BLOCKED_COMMAND =
            "&cTenhle příkaz ještě nemáš odemčený: &e%command%&c. Otevři &e/prikazy &ca splň úkoly, potom si ho odemkni za PlayerPoints.";

    private DefaultMessageMigration() { }

    /** Upgrades only the old bundled default. Any custom nonblank message is preserved. */
    public static String migrateBlockedCommand(String configuredMessage) {
        if (configuredMessage == null || configuredMessage.isBlank()
                || LEGACY_BLOCKED_COMMAND.equals(configuredMessage)) {
            return CURRENT_BLOCKED_COMMAND;
        }
        return configuredMessage;
    }
}
