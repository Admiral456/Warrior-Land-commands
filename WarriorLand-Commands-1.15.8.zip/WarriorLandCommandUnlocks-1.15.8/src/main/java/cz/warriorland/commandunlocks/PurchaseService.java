package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/** Coordinates a purchase as a compensating transaction across LuckPerms, PlayerPoints and disk. */
public final class PurchaseService {
    private final CommandUnlocksPlugin plugin;
    private final Set<UUID> purchasesInProgress = ConcurrentHashMap.newKeySet();
    /**
     * New permission nodes for purchases not yet durably committed, or an empty guard marker if an
     * unexpected exception leaves the cross-plugin transaction's state uncertain. Kept until commit
     * or confirmed compensation.
     */
    private final Map<UUID, List<String>> pendingPermissionReceipts = new ConcurrentHashMap<>();
    private volatile boolean shuttingDown;

    public PurchaseService(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    public int inProgressCount() {
        return purchasesInProgress.size();
    }

    public boolean isInProgress(UUID playerId) {
        return playerId != null && purchasesInProgress.contains(playerId);
    }

    public boolean hasUnresolvedPermissionCleanup(UUID playerId) {
        return playerId != null && pendingPermissionReceipts.containsKey(playerId);
    }

    public int unresolvedPermissionCleanupCount() {
        return pendingPermissionReceipts.size();
    }

    public void purchase(Player player, UnlockDefinition definition, MenuHolder holder) {
        UUID playerId = player.getUniqueId();
        if (plugin.data().isUnlocked(playerId, definition.id())) {
            plugin.sendMessage(player, "already-unlocked", "%name%", definition.name(), "%command%", "/" + definition.primaryCommand());
            return;
        }
        List<String> missingDependencies = plugin.missingRequiredPlugins(definition);
        if (!missingDependencies.isEmpty()) {
            plugin.sendMessage(player, "dependency-missing", "%plugins%", String.join(", ", missingDependencies));
            plugin.menus().refresh(player);
            return;
        }
        if (CommandAvailabilityPolicy.blocksPurchase(plugin.unlocks().commandRegistrationStatus(definition))) {
            plugin.sendMessage(player, "command-provider-missing", "%command%", "/" + definition.primaryCommand());
            plugin.menus().refresh(player);
            return;
        }
        if (!plugin.tasks().requirementsMet(playerId, definition)) {
            plugin.sendMessage(player, "requirements-incomplete", "%name%", definition.name());
            plugin.menus().refresh(player);
            return;
        }
        if (shuttingDown || plugin.isShuttingDown()) {
            plugin.sendSafeModeMessage(player);
            return;
        }
        // An ordinary double-click should report an in-progress purchase rather than the
        // administrator-cleanup message used for a genuinely unresolved compensation.
        if (purchasesInProgress.contains(playerId)) {
            plugin.sendMessage(player, "purchase-pending");
            return;
        }
        if (pendingPermissionReceipts.containsKey(playerId)) {
            plugin.sendMessage(player, "permission-cleanup-pending");
            plugin.getLogger().warning("Nákup pro " + playerId + " je dočasně blokován: předchozí kompenzace oprávnění nebyla potvrzena.");
            return;
        }
        if (!purchasesInProgress.add(playerId)) {
            plugin.sendMessage(player, "purchase-pending");
            return;
        }

        int balance = plugin.points().balance(playerId);
        if (balance < definition.cost()) {
            purchasesInProgress.remove(playerId);
            plugin.sendMessage(player, "not-enough", "%missing%", String.valueOf(definition.cost() - balance), "%balance%", String.valueOf(balance));
            plugin.menus().refresh(player);
            return;
        }

        // Grant permissions first. PlayerPoints is not charged until LuckPerms has confirmed the
        // permission operation, reducing the chance of a lost charge during a shutdown/API failure.
        try {
            CompletableFuture<LuckPermsHook.GrantResult> permissionUpdate = plugin.luckPerms().grantTracked(playerId, definition.permissions());
            if (permissionUpdate == null) throw new IllegalStateException("LuckPerms nevrátil výsledek změny oprávnění.");
            permissionUpdate.whenComplete((grantResult, futureError) -> {
                List<String> receipt = grantResult == null ? List.of() : grantResult.newlyGranted();
                if (!receipt.isEmpty()) pendingPermissionReceipts.put(playerId, List.copyOf(receipt));
                Throwable error = futureError != null ? futureError
                        : grantResult == null ? new IllegalStateException("LuckPerms nevrátil výsledek udělení oprávnění.")
                        : grantResult.error();
                runOnMainOrAbandon(playerId, definition, () -> {
                    if (shuttingDown || plugin.isShuttingDown()) {
                        abandonPendingPermissionReceipt(playerId, "Server se vypíná před dokončením nákupu.");
                        return;
                    }
                    finishPermissionGrant(playerId, definition, holder, receipt, error);
                });
            });
        } catch (RuntimeException exception) {
            finishPermissionGrant(playerId, definition, holder, List.of(), exception);
        }
    }

    private void finishPermissionGrant(UUID playerId, UnlockDefinition definition, MenuHolder holder,
                                      List<String> newlyGrantedPermissions, Throwable error) {
        if (error != null) {
            cleanupPermissionsThen(playerId, definition, newlyGrantedPermissions, revokeError -> {
                if (revokeError != null) logCleanupFailure(playerId, definition, revokeError);
                finishNoChargeFailure(playerId, definition, holder,
                        "LuckPerms nedokázal potvrdit potřebná oprávnění.", revokeError);
            });
            return;
        }

        List<String> missingDependencies = plugin.missingRequiredPlugins(definition);
        if (!missingDependencies.isEmpty()) {
            cleanupPermissionsThen(playerId, definition, newlyGrantedPermissions, revokeError -> {
                if (revokeError != null) logCleanupFailure(playerId, definition, revokeError);
                purchasesInProgress.remove(playerId);
                Player online = Bukkit.getPlayer(playerId);
                if (online != null) {
                    plugin.sendMessage(online, "dependency-missing", "%plugins%", String.join(", ", missingDependencies));
                    if (revokeError != null) plugin.sendMessage(online, "purchase-permission-cleanup-warning");
                    plugin.menus().open(online, holder.category(), holder.page(), definition.id(), false);
                }
            });
            return;
        }

        if (plugin.data().isUnlocked(playerId, definition.id())) {
            cleanupPermissionsThen(playerId, definition, newlyGrantedPermissions, revokeError -> {
                if (revokeError != null) logCleanupFailure(playerId, definition, revokeError);
                purchasesInProgress.remove(playerId);
                Player online = Bukkit.getPlayer(playerId);
                if (online != null) {
                    plugin.sendMessage(online, "already-unlocked", "%name%", definition.name(), "%command%", "/" + definition.primaryCommand());
                    plugin.menus().open(online, holder.category(), holder.page(), definition.id(), false);
                }
            });
            return;
        }

        // The balance may have changed while LuckPerms was processing the update. Recheck it just
        // before debit; the mutation itself remains the final authority on whether payment passed.
        int balance = plugin.points().balance(playerId);
        if (balance < definition.cost()) {
            cleanupPermissionsThen(playerId, definition, newlyGrantedPermissions, revokeError -> {
                if (revokeError != null) logCleanupFailure(playerId, definition, revokeError);
                finishInsufficientBalance(playerId, definition, holder, revokeError);
            });
            return;
        }

        if (!plugin.points().take(playerId, definition.cost())) {
            int current = plugin.points().balance(playerId);
            cleanupPermissionsThen(playerId, definition, newlyGrantedPermissions, revokeError -> {
                if (revokeError != null) logCleanupFailure(playerId, definition, revokeError);
                if (current < definition.cost()) {
                    finishInsufficientBalance(playerId, definition, holder, revokeError);
                } else {
                    finishNoChargeFailure(playerId, definition, holder,
                            "PlayerPoints odmítl platbu, přestože se zůstatek jevil jako dostatečný.", revokeError);
                }
            });
            return;
        }

        plugin.data().unlock(playerId, definition.id());
        plugin.data().recordSpentPoints(playerId, definition.cost());
        // Purchases are financial operations: confirm only once the unlock is durably stored.
        if (!plugin.data().saveSync()) {
            plugin.data().revertPurchase(playerId, definition.id(), definition.cost());
            boolean refunded = plugin.points().give(playerId, definition.cost());
            if (!refunded) {
                plugin.getLogger().severe("Nepodařilo se vrátit " + definition.cost() + " PP hráči " + playerId
                        + " po chybě zápisu při nákupu '" + definition.id() + "'. Je nutná ruční kontrola PlayerPoints.");
            }
            cleanupPermissionsThen(playerId, definition, newlyGrantedPermissions, revokeError -> {
                if (revokeError != null) logCleanupFailure(playerId, definition, revokeError);
                finishSaveFailure(playerId, definition, holder, refunded, revokeError);
            });
            return;
        }

        pendingPermissionReceipts.remove(playerId);
        purchasesInProgress.remove(playerId);
        Player online = Bukkit.getPlayer(playerId);
        if (online != null) {
            // Retry a previously unpaid task reward without repeating its one-time ready notification.
            plugin.tasks().checkAllReady(online);
            plugin.sendMessage(online, "purchased",
                    "%name%", definition.name(),
                    "%command%", "/" + definition.primaryCommand(),
                    "%cost%", String.valueOf(definition.cost()),
                    "%balance%", String.valueOf(plugin.points().balance(playerId)));
            if (plugin.hud() != null) plugin.hud().purchaseSucceeded(online, definition);
            plugin.menus().open(online, holder.category(), holder.page(), definition.id(), false);
        }
    }

    private void finishInsufficientBalance(UUID playerId, UnlockDefinition definition, MenuHolder holder, Throwable cleanupError) {
        purchasesInProgress.remove(playerId);
        Player online = Bukkit.getPlayer(playerId);
        if (online != null) {
            int balance = plugin.points().balance(playerId);
            plugin.sendMessage(online, "not-enough",
                    "%missing%", String.valueOf(Math.max(0, definition.cost() - balance)),
                    "%balance%", String.valueOf(balance));
            if (cleanupError != null) plugin.sendMessage(online, "purchase-permission-cleanup-warning");
            plugin.menus().open(online, holder.category(), holder.page(), definition.id(), false);
        }
    }

    private void finishNoChargeFailure(UUID playerId, UnlockDefinition definition, MenuHolder holder,
                                       String reason, Throwable cleanupError) {
        purchasesInProgress.remove(playerId);
        Player online = Bukkit.getPlayer(playerId);
        if (online != null) {
            plugin.sendMessage(online, "purchase-failed-no-charge", "%reason%", reason);
            if (cleanupError != null) plugin.sendMessage(online, "purchase-permission-cleanup-warning");
            plugin.menus().open(online, holder.category(), holder.page(), definition.id(), false);
        }
        plugin.getLogger().warning("Nákup '" + definition.id() + "' pro " + playerId + " byl ukončen před odečtením bodů: " + reason);
    }

    private void finishSaveFailure(UUID playerId, UnlockDefinition definition, MenuHolder holder,
                                   boolean refunded, Throwable revokeError) {
        purchasesInProgress.remove(playerId);
        Player online = Bukkit.getPlayer(playerId);
        if (online != null) {
            String refundText = refunded ? "úspěšně vráceny" : "NEVRÁCENY — kontaktuj administrátora";
            plugin.sendMessage(online, "purchase-save-failed", "%refund%", refundText);
            if (revokeError != null) plugin.sendMessage(online, "purchase-permission-cleanup-warning");
            plugin.menus().open(online, holder.category(), holder.page(), definition.id(), false);
        }
    }

    /** Revoke only nodes first introduced by this purchase, preserving pre-existing direct nodes. */
    private void cleanupPermissionsThen(UUID playerId, UnlockDefinition definition, List<String> receipt,
                                        Consumer<Throwable> completion) {
        if (receipt == null || receipt.isEmpty()) {
            completion.accept(null);
            return;
        }
        CompletableFuture<Void> revokeFuture;
        try {
            revokeFuture = plugin.luckPerms().revoke(playerId, receipt);
            if (revokeFuture == null) throw new IllegalStateException("LuckPerms nevrátil výsledek odebrání oprávnění.");
        } catch (RuntimeException error) {
            completion.accept(error);
            return;
        }
        revokeFuture.whenComplete((unused, error) -> {
            Throwable result = unwrap(error);
            if (result == null) pendingPermissionReceipts.remove(playerId, receipt);
            runOnMainOrAbandon(playerId, definition, () -> completion.accept(result));
        });
    }

    /** Best-effort rollback for a permission grant that has not been durably committed as an unlock. */
    private void abandonPendingPermissionReceipt(UUID playerId, String reason) {
        // Keep a receipt in the map while compensation is pending. That blocks a second purchase
        // until LuckPerms confirms the revoke and avoids issuing another grant into an uncertain state.
        List<String> receipt = pendingPermissionReceipts.get(playerId);
        purchasesInProgress.remove(playerId);
        if (receipt == null || receipt.isEmpty()) {
            plugin.getLogger().warning("Nedokončený nákup hráče " + playerId + " byl opuštěn: " + reason + " PlayerPoints nebyly odečteny.");
            return;
        }
        try {
            CompletableFuture<Void> revoke = plugin.luckPerms().revoke(playerId, receipt);
            if (revoke == null) throw new IllegalStateException("LuckPerms nevrátil výsledek odebrání oprávnění.");
            revoke.whenComplete((unused, error) -> {
                if (error != null) {
                    Throwable cause = unwrap(error);
                    // Never discard the receipt just because shutdown has started. While the plugin
                    // is enabled it blocks another purchase; the exact nodes are also logged so a
                    // failed late-shutdown compensation can be repaired manually.
                    plugin.getLogger().severe("Nepodařilo se odebrat oprávnění po nedokončeném nákupu hráče " + playerId
                            + ": " + cause.getMessage() + ". Ověř LuckPerms nodes " + receipt + " ručně.");
                } else {
                    pendingPermissionReceipts.remove(playerId, receipt);
                    plugin.getLogger().info("Nedokončený nákup hráče " + playerId + " byl kompenzován: dočasná oprávnění odebrána. " + reason);
                }
            });
        } catch (RuntimeException error) {
            plugin.getLogger().severe("Nepodařilo se zahájit odebrání oprávnění po nedokončeném nákupu hráče "
                    + playerId + ": " + error.getMessage() + ". Čekající nodes " + receipt
                    + " zůstávají evidované, dokud je plugin aktivní; ověř je ručně.");
        }
    }

    /** Called from onDisable to make a final best-effort compensation and keep actionable logs. */
    public void shutdown() {
        shuttingDown = true;
        for (Map.Entry<UUID, List<String>> entry : pendingPermissionReceipts.entrySet()) {
            UUID playerId = entry.getKey();
            List<String> receipt = entry.getValue();
            if (receipt == null || receipt.isEmpty()) {
                plugin.getLogger().severe("Při vypínání zůstává nejasný stav nákupu hráče " + playerId
                        + ". Nejsou dostupné permission nodes pro automatickou kompenzaci; před dalším nákupem ověř PlayerPoints i LuckPerms.");
                continue;
            }
            try {
                CompletableFuture<Void> revoke = plugin.luckPerms().revoke(playerId, receipt);
                if (revoke == null) throw new IllegalStateException("LuckPerms nevrátil výsledek odebrání oprávnění.");
                revoke.whenComplete((unused, error) -> {
                    if (error != null) {
                        plugin.getLogger().severe("Při vypínání se nepodařilo odebrat oprávnění po nedokončeném nákupu hráče "
                                + playerId + ": " + unwrap(error).getMessage() + ". Ověř LuckPerms nodes " + receipt + " ručně.");
                    } else {
                        pendingPermissionReceipts.remove(playerId, receipt);
                        plugin.getLogger().info("Při vypínání byla potvrzena kompenzace oprávnění hráče " + playerId + ": " + receipt);
                    }
                });
            } catch (RuntimeException error) {
                plugin.getLogger().severe("Při vypínání se nepodařilo zahájit kompenzaci oprávnění hráče "
                        + playerId + ": " + error.getMessage() + ". Ověř LuckPerms nodes " + receipt + " ručně.");
            }
        }
        purchasesInProgress.clear();
    }

    private void runOnMainOrAbandon(UUID playerId, UnlockDefinition definition, Runnable action) {
        if (shuttingDown || plugin.isShuttingDown()) {
            abandonPendingPermissionReceipt(playerId, "Server se vypíná před dokončením nákupu '" + definition.id() + "'.");
            return;
        }
        try {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (shuttingDown || plugin.isShuttingDown()) {
                    abandonPendingPermissionReceipt(playerId, "Server se vypíná před dokončením nákupu '" + definition.id() + "'.");
                    return;
                }
                try {
                    action.run();
                } catch (RuntimeException unexpected) {
                    // The transaction may already have changed external state. Preserve the receipt
                    // as a guard and require an administrator check instead of guessing a rollback.
                    purchasesInProgress.remove(playerId);
                    List<String> uncertainReceipt = pendingPermissionReceipts.getOrDefault(playerId, List.of());
                    pendingPermissionReceipts.putIfAbsent(playerId, uncertainReceipt);
                    plugin.getLogger().severe("Nákup '" + definition.id() + "' hráče " + playerId
                            + " skončil neočekávanou chybou v hlavním vlákně. Stav platby je nutné ověřit; další nákupy jsou zablokované: "
                            + unexpected.getMessage());
                    Player online = Bukkit.getPlayer(playerId);
                    if (online != null) plugin.sendMessage(online, "permission-cleanup-pending");
                }
            });
        } catch (RuntimeException schedulerUnavailable) {
            // No point debit is done before main-thread confirmation. Only compensate pending LP nodes.
            abandonPendingPermissionReceipt(playerId, "Plánovač už nepřijímá úlohy.");
            plugin.getLogger().warning("Nákup '" + definition.id() + "' hráče " + playerId + " nebylo možné dokončit. PlayerPoints nebyly odečteny.");
        }
    }

    private void logCleanupFailure(UUID playerId, UnlockDefinition definition, Throwable error) {
        plugin.getLogger().severe("Nepodařilo se odebrat nově přidaná oprávnění po nedokončeném nákupu '"
                + definition.id() + "' hráče " + playerId + ": " + unwrap(error).getMessage() + ". Zkontroluj LuckPerms ručně.");
    }

    private Throwable unwrap(Throwable error) {
        if (error instanceof java.util.concurrent.CompletionException completion && completion.getCause() != null) {
            return completion.getCause();
        }
        return error;
    }
}
