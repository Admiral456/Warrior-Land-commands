package cz.warriorland.commandunlocks;

/** Small, pure policies for rate-limited task progress shown in the vanilla action bar. */
final class HudProgressPolicy {
    private HudProgressPolicy() { }

    static boolean shouldNotify(Long lastNoticeNanos, long nowNanos, long cooldownNanos) {
        return lastNoticeNanos == null || nowNanos - lastNoticeNanos >= Math.max(0L, cooldownNanos);
    }

    static int filledSegments(int current, int target, int segments) {
        int safeSegments = Math.max(0, Math.min(20, segments));
        if (safeSegments == 0 || target <= 0 || current <= 0) return 0;
        if (current >= target) return safeSegments;
        return (int) Math.min(safeSegments, (long) current * safeSegments / target);
    }
}
