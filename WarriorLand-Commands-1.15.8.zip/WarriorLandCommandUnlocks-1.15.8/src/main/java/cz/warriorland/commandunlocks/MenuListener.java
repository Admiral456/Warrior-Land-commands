package cz.warriorland.commandunlocks;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class MenuListener implements Listener {
    private final CommandUnlocksPlugin plugin;

    public MenuListener(CommandUnlocksPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof TutorialHolder) {
            plugin.menus().handleTutorialClick(event);
            return;
        }
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder)) return;
        plugin.menus().handleClick(event);
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder
                || event.getView().getTopInventory().getHolder() instanceof TutorialHolder) {
            event.setCancelled(true);
        }
    }

    /** The search prompt consumes exactly the next chat message; ordinary chat is untouched otherwise. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSearchChat(AsyncChatEvent event) {
        if (plugin.menus() == null || !plugin.menus().isAwaitingSearchInput(event.getPlayer().getUniqueId())) return;
        event.setCancelled(true);
        var playerId = event.getPlayer().getUniqueId();
        String input = PlainTextComponentSerializer.plainText().serialize(event.message());
        Bukkit.getScheduler().runTask(plugin, () -> {
            var player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline() && plugin.menus() != null) {
                plugin.menus().acceptSearchInput(player, input);
            }
        });
    }
}
