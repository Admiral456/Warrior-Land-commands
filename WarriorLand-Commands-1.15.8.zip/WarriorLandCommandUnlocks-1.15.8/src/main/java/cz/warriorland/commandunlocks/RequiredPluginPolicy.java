package cz.warriorland.commandunlocks;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Pure policy for fail-closed optional-plugin prerequisites; input names are those of enabled plugins. */
public final class RequiredPluginPolicy {
    private RequiredPluginPolicy() { }

    public static List<String> missing(List<String> required, Collection<String> enabledPluginNames) {
        if (required == null || required.isEmpty()) return List.of();
        Set<String> enabled = new HashSet<>();
        if (enabledPluginNames != null) {
            for (String name : enabledPluginNames) {
                if (name != null && !name.isBlank()) enabled.add(name.trim().toLowerCase(Locale.ROOT));
            }
        }
        Set<String> missingSeen = new HashSet<>();
        return required.stream().filter(name -> name != null && !name.isBlank())
                .map(String::trim)
                .filter(name -> !enabled.contains(name.toLowerCase(Locale.ROOT)))
                .filter(name -> missingSeen.add(name.toLowerCase(Locale.ROOT)))
                .toList();
    }
}
