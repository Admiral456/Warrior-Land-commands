package cz.warriorland.commandunlocks;

import java.util.List;

/** Matching helpers for external task targets whose API may use different capitalization. */
public final class TaskTargetMatcher {
    private TaskTargetMatcher() { }

    /** Jobs Reborn job names are identifiers, not user-facing labels; treat their case as insignificant. */
    public static boolean matchesJob(List<String> configuredJobs, String eventJobName) {
        if (configuredJobs == null || eventJobName == null || eventJobName.isBlank()) return false;
        String target = eventJobName.trim();
        return configuredJobs.stream()
                .filter(java.util.Objects::nonNull)
                .map(String::trim)
                .anyMatch(configured -> !configured.isBlank() && configured.equalsIgnoreCase(target));
    }
}
