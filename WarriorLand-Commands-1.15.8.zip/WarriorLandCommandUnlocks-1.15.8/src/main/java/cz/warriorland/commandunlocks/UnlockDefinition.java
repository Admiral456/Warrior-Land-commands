package cz.warriorland.commandunlocks;

import java.util.List;
import java.util.Locale;

public record UnlockDefinition(
        String id,
        String name,
        String description,
        String category,
        String icon,
        int cost,
        int taskReward,
        List<String> commands,
        List<String> permissions,
        List<TaskDefinition> tasks,
        List<String> requiredPlugins
) {
    public UnlockDefinition {
        id = id == null ? "" : id.toLowerCase(Locale.ROOT);
        name = name == null || name.isBlank() ? id : name;
        description = description == null ? "" : description;
        category = category == null || category.isBlank() ? "utility" : category.toLowerCase(Locale.ROOT);
        icon = icon == null || icon.isBlank() ? "PAPER" : icon.trim();
        cost = Math.max(0, cost);
        taskReward = Math.max(0, taskReward);
        commands = commands == null ? List.of() : commands.stream().map(UnlockRegistry::normalizeCommand).filter(s -> !s.isBlank()).distinct().toList();
        permissions = permissions == null ? List.of() : permissions.stream().map(String::trim).filter(s -> !s.isBlank()).distinct().toList();
        tasks = tasks == null ? List.of() : List.copyOf(tasks);
        requiredPlugins = requiredPlugins == null ? List.of() : requiredPlugins.stream()
                .map(String::trim).filter(s -> !s.isBlank()).distinct().toList();
    }

    public String primaryCommand() {
        return commands.isEmpty() ? id : commands.getFirst();
    }
}
