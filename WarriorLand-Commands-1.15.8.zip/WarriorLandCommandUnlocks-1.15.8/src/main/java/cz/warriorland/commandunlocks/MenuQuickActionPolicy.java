package cz.warriorland.commandunlocks;

/** Pure mapping for the clickable quick-action row and the two top shortcuts. */
final class MenuQuickActionPolicy {
    enum Action { NONE, TUTORIAL, POINTS, TASKS, STATUS_LEGEND, HUD_TOGGLE }

    private MenuQuickActionPolicy() { }

    static Action actionFor(int slot) {
        return switch (slot) {
            case 5 -> Action.TUTORIAL;
            case 6, 39 -> Action.POINTS;
            case 38 -> Action.TASKS;
            case 40 -> Action.STATUS_LEGEND;
            case 41 -> Action.HUD_TOGGLE;
            default -> Action.NONE;
        };
    }
}
