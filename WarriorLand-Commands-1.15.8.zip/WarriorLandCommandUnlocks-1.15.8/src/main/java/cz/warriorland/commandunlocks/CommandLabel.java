package cz.warriorland.commandunlocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Normalizes root command labels and optional subcommand selectors. */
public final class CommandLabel {
    private static final Pattern VALID_TOKEN = Pattern.compile("(?i)[a-z0-9_.-]+");
    private static final Pattern VALID_ROOT = Pattern.compile("(?i)([a-z0-9_.-]+:)?[a-z0-9_.-]+");

    private CommandLabel() { }

    /**
     * Returns a lowercase, namespace-free root command label. Arguments are deliberately discarded.
     * Used for Bukkit aliases, which belong to the root command rather than a subcommand.
     */
    public static String normalize(String command) {
        if (command == null) return "";
        String normalized = stripLeadingSlashes(command.trim()).toLowerCase(Locale.ROOT);
        int separatorIndex = firstSpace(normalized);
        if (separatorIndex >= 0) normalized = normalized.substring(0, separatorIndex);
        int namespaceIndex = normalized.lastIndexOf(':');
        if (namespaceIndex >= 0 && namespaceIndex + 1 < normalized.length()) {
            normalized = normalized.substring(namespaceIndex + 1);
        }
        return normalized;
    }

    /** Normalizes a config selector such as "res tp" while stripping a namespace only from its root. */
    public static String normalizeConfiguredKey(String command) {
        if (command == null) return "";
        String raw = stripLeadingSlashes(command.trim());
        if (raw.isBlank()) return "";
        String[] pieces = raw.toLowerCase(Locale.ROOT).split("\\s+");
        if (pieces.length == 0 || pieces[0].isBlank()) return "";
        List<String> normalized = new ArrayList<>(pieces.length);
        normalized.add(normalize(pieces[0]));
        for (int i = 1; i < pieces.length; i++) normalized.add(pieces[i]);
        return String.join(" ", normalized);
    }

    /**
     * Normalizes all command tokens from a player-entered command. The caller chooses the longest
     * configured selector prefix, so command arguments after a subcommand remain ordinary arguments.
     */
    public static List<String> inputTokens(String input) {
        if (input == null) return List.of();
        String raw = stripLeadingSlashes(input.trim());
        if (raw.isBlank()) return List.of();
        String[] pieces = raw.toLowerCase(Locale.ROOT).split("\\s+");
        List<String> normalized = new ArrayList<>(pieces.length);
        normalized.add(normalize(pieces[0]));
        for (int i = 1; i < pieces.length; i++) normalized.add(pieces[i]);
        return normalized.stream().filter(token -> !token.isBlank()).toList();
    }

    private static String stripLeadingSlashes(String value) {
        int start = 0;
        while (start < value.length() && value.charAt(start) == '/') start++;
        return value.substring(start);
    }

    private static int firstSpace(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (Character.isWhitespace(value.charAt(i)) || Character.isSpaceChar(value.charAt(i))) return i;
        }
        return -1;
    }

    /** Validates a root command or a sequence of literal subcommand tokens; arbitrary punctuation is rejected. */
    public static boolean isValidConfiguredCommand(String command) {
        if (command == null || command.isBlank()) return false;
        String raw = stripLeadingSlashes(command.trim());
        if (raw.isBlank()) return false;
        String[] pieces = raw.split("\\s+");
        if (pieces.length == 0 || !VALID_ROOT.matcher(pieces[0]).matches()) return false;
        for (int i = 1; i < pieces.length; i++) {
            if (!VALID_TOKEN.matcher(pieces[i]).matches()) return false;
        }
        return true;
    }
}
