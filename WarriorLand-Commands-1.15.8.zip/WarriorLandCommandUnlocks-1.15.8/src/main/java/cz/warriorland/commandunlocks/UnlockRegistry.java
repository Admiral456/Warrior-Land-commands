package cz.warriorland.commandunlocks;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Loads unlock definitions and keeps invalid entries locked rather than accidentally failing open. */
public final class UnlockRegistry {
    private static final Set<String> RESERVED_COMMANDS = Set.of("prikazy", "odemykani", "unlock", "odemykat");
    private static final Set<String> TASK_TYPES = Set.of(
            "BREAK_BLOCK", "FISH_CAUGHT", "KILL_MOB", "CRAFT_ITEM", "VOTE", "JOBS_ACTION");

    private final CommandUnlocksPlugin plugin;
    private final CommandAliasResolver aliasResolver;
    private final Map<String, UnlockDefinition> definitions = new LinkedHashMap<>();
    private final Map<String, String> commandOwners = new LinkedHashMap<>();

    public UnlockRegistry(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
        this.aliasResolver = new CommandAliasResolver(plugin);
    }

    public boolean reload(FileConfiguration config) {
        Set<String> claimedCommandLabels = new HashSet<>();
        Map<String, UnlockDefinition> parsedDefinitions = new LinkedHashMap<>();
        ConfigurationSection section = config.getConfigurationSection("unlocks");
        if (!config.contains("unlocks", true) || section == null || section.getKeys(false).isEmpty()) {
            plugin.getLogger().severe("V config.yml chybí nebo je prázdná sekce 'unlocks'. Aktivní pravidla zůstávají beze změny.");
            return false;
        }

        for (String rawId : section.getKeys(false)) {
            String path = "unlocks." + rawId + ".";
            String id = rawId.toLowerCase(Locale.ROOT);
            boolean invalidConfiguration = false;
            if (!id.matches("[a-z0-9_-]+")) {
                plugin.getLogger().warning("Neplatné ID odemčení '" + rawId + "'. Položka zůstane zamčená pod bezpečným ID, dokud neopravíš config.yml.");
                id = "invalid-" + Integer.toUnsignedString(rawId.hashCode(), 36);
                invalidConfiguration = true;
            }
            if (parsedDefinitions.containsKey(id)) {
                plugin.getLogger().warning("Duplicitní/kolizní ID odemčení '" + rawId + "'. Prozatímní ID bude použito jen pro zobrazení a položka zůstane zamčená.");
                id = uniqueId("invalid-" + Integer.toUnsignedString(rawId.hashCode(), 36), parsedDefinitions.keySet());
                invalidConfiguration = true;
            }

            Object rawCommands = config.get(path + "commands");
            if (!(rawCommands instanceof List<?> commandList) || commandList.isEmpty()
                    || !UnlockConfigurationRules.isStringListOrMissing(rawCommands)) {
                plugin.getLogger().severe("Odemčení '" + rawId + "' musí mít commands jako neprázdný seznam názvů příkazů. Pravidla se nenačetla; předchozí konfigurace zůstává aktivní.");
                return false;
            }
            List<String> commands = new ArrayList<>();
            for (Object configuredValue : commandList) {
                String configuredCommand = (String) configuredValue;
                if (!CommandLabel.isValidConfiguredCommand(configuredCommand)) {
                    plugin.getLogger().severe("Neplatný název příkazu '" + configuredCommand + "' u odemčení '" + rawId + "'. Reload odmítnut; předchozí pravidla zůstávají aktivní.");
                    return false;
                }
                String normalized = CommandLabel.normalizeConfiguredKey(configuredCommand);
                if (!normalized.isBlank() && !commands.contains(normalized)) commands.add(normalized);
            }

            List<String> reserved = commands.stream().filter(RESERVED_COMMANDS::contains).toList();
            if (!reserved.isEmpty()) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' používá vyhrazený příkaz pluginu WarriorLand: " + reserved + ". Tyto aliasy nelze odemykat.");
                commands.removeAll(reserved);
                invalidConfiguration = true;
            }
            List<String> conflicts = commands.stream().filter(claimedCommandLabels::contains).toList();
            if (!conflicts.isEmpty()) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' sdílí příkaz(y) " + conflicts + " s jinou položkou. Konfliktní aliasy se odeberou z této položky.");
                commands.removeAll(conflicts);
                invalidConfiguration = true;
            }
            if (commands.isEmpty()) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' nemá žádný použitelný příkaz po validaci; nelze ho bezpečně zaregistrovat.");
                continue;
            }

            List<TaskDefinition> tasks = new ArrayList<>();
            Set<String> taskIds = new HashSet<>();
            Object rawTasks = config.get(path + "tasks");
            if (!UnlockConfigurationRules.isMapList(rawTasks)) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' musí mít tasks jako seznam objektů úkolů; přidávám blokující validační úkol.");
                addInvalidTask(tasks, taskIds, "Úkoly mají neplatný formát — kontaktuj administrátora.");
                invalidConfiguration = true;
            } else if (!(rawTasks instanceof List<?> taskList) || taskList.isEmpty()) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' nemá žádný úkol. Každé odemčení musí vyžadovat alespoň jeden úkol; položka zůstane zamčená.");
                addInvalidTask(tasks, taskIds, "Chybí požadovaný úkol — kontaktuj administrátora.");
                invalidConfiguration = true;
            }
            int index = 0;
            for (Map<?, ?> map : config.getMapList(path + "tasks")) {
                int taskIndex = index++;
                Object rawTaskId = map.get("id");
                if (!(rawTaskId instanceof String idValue) || idValue.isBlank()) {
                    plugin.getLogger().warning("Úkol #" + taskIndex + " u odemčení '" + rawId + "' nemá explicitní ID. Přidávám blokující validační úkol.");
                    addInvalidTask(tasks, taskIds, "Úkol nemá stabilní ID — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                String taskId = idValue.toLowerCase(Locale.ROOT);
                if (!taskId.matches("[a-z0-9_-]+")) {
                    plugin.getLogger().warning("Neplatné ID úkolu '" + taskId + "' u odemčení '" + rawId + "'. Přidávám blokující validační úkol.");
                    addInvalidTask(tasks, taskIds, "Neplatné ID úkolu — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                if (!taskIds.add(taskId)) {
                    plugin.getLogger().warning("Duplicitní ID úkolu '" + taskId + "' u odemčení '" + rawId + "'. Přidávám blokující validační úkol.");
                    addInvalidTask(tasks, taskIds, "Duplicitní ID úkolu — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }

                Object rawType = map.get("type");
                if (!(rawType instanceof String typeValue) || typeValue.isBlank()) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' nemá platně definovaný type. Odemčení zůstane zamčené.");
                    addInvalidTask(tasks, taskIds, "Úkol nemá typ — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                String type = typeValue.toUpperCase(Locale.ROOT);
                Object rawAmount = map.get("amount");
                if (rawAmount == null) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' nemá amount. Odemčení zůstane zamčené.");
                    addInvalidTask(tasks, taskIds, "Úkol nemá požadovaný počet — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                if (!UnlockConfigurationRules.isInteger(rawAmount)) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' má nečíselný amount; položka zůstane zamčená.");
                    addInvalidTask(tasks, taskIds, "Neplatná hodnota amount — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                int amount = UnlockConfigurationRules.integer(rawAmount, 1);
                if (amount < 1) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' musí mít amount alespoň 1; položka zůstane zamčená.");
                    addInvalidTask(tasks, taskIds, "Amount musí být alespoň 1 — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                String description = string(map.get("description"), taskId);
                Object rawMaterials = map.get("materials");
                Object rawEntities = map.get("entities");
                Object rawJobs = map.get("jobs");
                List<String> materials = UnlockConfigurationRules.stringList(rawMaterials);
                List<String> entities = UnlockConfigurationRules.stringList(rawEntities);
                List<String> jobs = UnlockConfigurationRules.stringList(rawJobs);

                if (!UnlockConfigurationRules.isStringListOrMissing(rawMaterials) || !UnlockConfigurationRules.isStringListOrMissing(rawEntities)
                        || !UnlockConfigurationRules.isStringListOrMissing(rawJobs)) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' musí mít materials/entities/jobs jako seznam textových hodnot. Odemčení zůstane zamčené.");
                    addInvalidTask(tasks, taskIds, "Seznam úkolu má neplatný formát — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }

                if (!TASK_TYPES.contains(type)) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' má nepodporovaný typ '" + type + "'. Odemčení zůstane bezpečně zamčené.");
                    addInvalidTask(tasks, taskIds, "Nepodporovaný typ úkolu — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                boolean wrongFilterField = (!materials.isEmpty() && !Set.of("BREAK_BLOCK", "FISH_CAUGHT", "CRAFT_ITEM").contains(type))
                        || (!entities.isEmpty() && !type.equals("KILL_MOB"))
                        || (!jobs.isEmpty() && !type.equals("JOBS_ACTION"));
                if (wrongFilterField) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' obsahuje filtr, který neodpovídá typu '" + type + "'. Odemčení zůstane zamčené.");
                    addInvalidTask(tasks, taskIds, "Filtry neodpovídají typu úkolu — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }

                boolean invalidMaterial = materials.stream().anyMatch(material -> {
                    Material resolved = Material.matchMaterial(material);
                    return resolved == null || (type.equals("BREAK_BLOCK") && !resolved.isBlock());
                });
                boolean invalidEntity = entities.stream().anyMatch(entity -> {
                    try {
                        EntityType resolved = EntityType.valueOf(entity.toUpperCase(Locale.ROOT));
                        Class<?> entityClass = resolved.getEntityClass();
                        return resolved == EntityType.PLAYER || entityClass == null || !LivingEntity.class.isAssignableFrom(entityClass);
                    } catch (IllegalArgumentException ignored) {
                        return true;
                    }
                });
                if (type.equals("JOBS_ACTION") && jobs.isEmpty()) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' typu JOBS_ACTION musí obsahovat jobs, např. jobs: [\"Miner\"]. Odemčení zůstane zamčené.");
                    addInvalidTask(tasks, taskIds, "Chybí seznam Jobs — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                if (invalidMaterial || invalidEntity) {
                    plugin.getLogger().warning("Úkol '" + rawId + "/" + taskId + "' obsahuje neznámý Material/EntityType nebo materiál, který není blokem pro BREAK_BLOCK. Odemčení zůstane zamčené.");
                    addInvalidTask(tasks, taskIds, "Neplatný Material/EntityType — kontaktuj administrátora.");
                    invalidConfiguration = true;
                    continue;
                }
                // Store canonical Bukkit enum names, so namespaced config values such as minecraft:stone
                // still match the un-namespaced enum names received from events.
                materials = materials.stream().map(name -> Material.matchMaterial(name).name()).toList();
                entities = entities.stream().map(name -> EntityType.valueOf(name.toUpperCase(Locale.ROOT)).name()).toList();
                tasks.add(new TaskDefinition(taskId, type, amount, description, materials, entities, jobs));
            }

            String configuredCategory = string(config.get(path + "category"), "utility").trim().toLowerCase(Locale.ROOT);
            if (config.getConfigurationSection("categories." + configuredCategory) == null) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' má neznámou kategorii '" + configuredCategory + "'; používám 'utility'.");
                configuredCategory = "utility";
            }

            Object rawRequiredPlugins = config.get(path + "required-plugins");
            if (rawRequiredPlugins != null && !UnlockConfigurationRules.isStringListOrMissing(rawRequiredPlugins)) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' musí mít required-plugins jako seznam názvů pluginů. Položka zůstane zamčená.");
                invalidConfiguration = true;
            }
            List<String> requiredPlugins = new ArrayList<>();
            Set<String> seenRequiredPlugins = new HashSet<>();
            for (String requiredPlugin : UnlockConfigurationRules.stringList(rawRequiredPlugins)) {
                String trimmed = requiredPlugin.trim();
                String normalizedPlugin = trimmed.toLowerCase(Locale.ROOT);
                if (!trimmed.matches("[A-Za-z0-9_.-]+") || !seenRequiredPlugins.add(normalizedPlugin)) {
                    plugin.getLogger().warning("Odemčení '" + rawId + "' obsahuje neplatný nebo duplicitní název required pluginu '" + requiredPlugin + "'. Položka zůstane zamčená.");
                    invalidConfiguration = true;
                } else {
                    requiredPlugins.add(trimmed);
                }
            }

            Object rawPermissions = config.get(path + "permissions");
            if (rawPermissions != null && !UnlockConfigurationRules.isStringListOrMissing(rawPermissions)) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' musí mít permissions jako seznam textových uzlů LuckPerms. Položka zůstane zamčená.");
                invalidConfiguration = true;
            }
            List<String> permissions = new ArrayList<>();
            boolean allowWildcardPermissions = config.getBoolean("settings.allow-wildcard-permissions", false);
            for (String permission : UnlockConfigurationRules.stringList(rawPermissions)) {
                if (!UnlockConfigurationRules.isPermissionNode(permission, allowWildcardPermissions)) {
                    plugin.getLogger().warning("Odemčení '" + rawId + "' obsahuje neplatný LuckPerms node '" + permission
                            + "'. Wildcard uzly jsou ve výchozím stavu zakázané; výjimku lze povolit v settings.allow-wildcard-permissions. Položka zůstane zamčená, dokud config neopravíš.");
                    invalidConfiguration = true;
                } else {
                    permissions.add(permission.trim().toLowerCase(Locale.ROOT));
                }
            }
            if (permissions.isEmpty()) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' nemá žádný platný LuckPerms permission node. Položka zůstane zamčená, dokud node nedoplníš.");
                invalidConfiguration = true;
            }

            Object rawCost = config.get(path + "cost");
            Object rawTaskReward = config.get(path + "task-reward");
            int cost = rawCost == null ? 0 : UnlockConfigurationRules.integer(rawCost, 0);
            int taskReward = rawTaskReward == null ? 0 : UnlockConfigurationRules.integer(rawTaskReward, 0);
            if (rawCost == null) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' nemá definovanou cenu. Přidávám blokující validační úkol.");
                invalidConfiguration = true;
            }
            if ((rawCost != null && !UnlockConfigurationRules.isInteger(rawCost)) || (rawTaskReward != null && !UnlockConfigurationRules.isInteger(rawTaskReward))) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' má nečíselnou cenu nebo odměnu; položka zůstane zamčená do opravy config.yml.");
                invalidConfiguration = true;
            }
            if (cost < 0) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' má zápornou cenu; pro bezpečnost cenu nastavím na 0 a nákup zůstane zamčený do opravy configu.");
                cost = 0;
                invalidConfiguration = true;
            }
            if (taskReward < 0) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' má zápornou odměnu; odměnu nastavím na 0 a nákup zůstane zamčený do opravy configu.");
                taskReward = 0;
                invalidConfiguration = true;
            }

            if (invalidConfiguration && tasks.stream().noneMatch(task -> task.type().equals("INVALID_CONFIG"))) {
                addInvalidTask(tasks, taskIds, "Konfigurace příkazu je neplatná — kontaktuj administrátora.");
            }

            UnlockDefinition definition = new UnlockDefinition(
                    id,
                    config.getString(path + "name", rawId),
                    config.getString(path + "description", ""),
                    configuredCategory,
                    config.getString(path + "icon", "PAPER"),
                    cost,
                    taskReward,
                    commands,
                    permissions,
                    tasks,
                    requiredPlugins
            );
            parsedDefinitions.put(id, definition);
            claimedCommandLabels.addAll(definition.commands());
            if (invalidConfiguration) {
                plugin.getLogger().warning("Odemčení '" + rawId + "' bylo načteno, ale zůstane zamčené kvůli validačnímu úkolu. Oprav konfiguraci a použij /prikazy admin reload.");
            }
        }
        long usableDefinitions = parsedDefinitions.values().stream()
                .filter(definition -> !definition.commands().isEmpty())
                .filter(definition -> !definition.permissions().isEmpty())
                .filter(definition -> definition.tasks().stream().noneMatch(task -> task.type().equals("INVALID_CONFIG")))
                .count();
        if (!UnlockConfigurationRules.hasUsableUnlocks((int) Math.min(Integer.MAX_VALUE, usableDefinitions))) {
            plugin.getLogger().severe("Po validaci nezůstalo žádné skutečně použitelné odemčení. Předchozí aktivní pravidla zůstávají zachována; oprav config.yml.");
            return false;
        }
        definitions.clear();
        definitions.putAll(parsedDefinitions);
        rebuildCommandOwners();
        plugin.getLogger().info("Načteno " + definitions.size() + " odemčení; automaticky chráněno "
                + commandOwners.size() + " názvů/aliasů příkazů.");
        return true;
    }

    private void addInvalidTask(List<TaskDefinition> tasks, Set<String> taskIds, String description) {
        String taskId = uniqueId("invalid-config-" + tasks.size(), taskIds);
        taskIds.add(taskId);
        tasks.add(new TaskDefinition(taskId, "INVALID_CONFIG", 1, description, List.of(), List.of(), List.of()));
    }

    private static String uniqueId(String base, Collection<String> used) {
        String candidate = base;
        int suffix = 2;
        while (used.contains(candidate)) candidate = base + "-" + suffix++;
        return candidate;
    }

    public Collection<UnlockDefinition> all() {
        return List.copyOf(definitions.values());
    }

    public int configuredCommandLabelCount() {
        return (int) definitions.values().stream()
                .flatMap(definition -> definition.commands().stream())
                .distinct()
                .count();
    }

    public int automaticallyProtectedAliasCount() {
        return Math.max(0, commandOwners.size() - configuredCommandLabelCount());
    }

    /** Checks only whether each configured command root is registered; it never executes commands. */
    public CommandAvailabilityPolicy.Status commandRegistrationStatus(UnlockDefinition definition) {
        if (definition == null || definition.commands().isEmpty()) return CommandAvailabilityPolicy.Status.UNKNOWN;
        List<CommandAvailabilityPolicy.Status> statuses = definition.commands().stream()
                .map(aliasResolver::registrationStatus).toList();
        return CommandAvailabilityPolicy.aggregate(statuses);
    }

    public boolean canInspectCommandRegistration() {
        return aliasResolver.canInspectRegistration();
    }

    public int registeredCommandLabelCount() {
        return aliasResolver.registeredLabelCount();
    }

    public UnlockDefinition byId(String id) {
        return id == null ? null : definitions.get(id.toLowerCase(Locale.ROOT));
    }

    /** Rebuild the alias index after another plugin registers or removes commands. */
    public void refreshCommandAliases() {
        rebuildCommandOwners();
    }

    private void rebuildCommandOwners() {
        Map<String, String> allExplicitOwners = new LinkedHashMap<>();
        Map<String, String> singleLabelOwners = new LinkedHashMap<>();
        for (UnlockDefinition definition : definitions.values()) {
            for (String command : definition.commands()) {
                allExplicitOwners.put(command, definition.id());
                if (!command.contains(" ")) singleLabelOwners.put(command, definition.id());
            }
        }
        List<Set<String>> groups = aliasResolver.discoverGroups(singleLabelOwners.keySet());
        CommandAliasPolicy.Resolution resolution = CommandAliasPolicy.resolve(singleLabelOwners, groups, RESERVED_COMMANDS);
        commandOwners.clear();
        commandOwners.putAll(allExplicitOwners); // Exact subcommand selectors never go through alias guessing.
        for (Map.Entry<String, String> entry : resolution.owners().entrySet()) {
            commandOwners.putIfAbsent(entry.getKey(), entry.getValue());
        }
        int autoAdded = (int) resolution.owners().keySet().stream().filter(key -> !singleLabelOwners.containsKey(key)).count();
        if (autoAdded > 0) {
            plugin.getLogger().info("Z příkazové mapy serveru rozpoznáno a chráněno " + autoAdded + " dalších aliasů odemykatelných příkazů.");
        }
        if (!resolution.ambiguousAliases().isEmpty()) {
            plugin.getLogger().warning("Tyto automaticky zjištěné aliasy patří k více samostatným odemčením a nebyly automaticky přiřazeny: "
                    + resolution.ambiguousAliases() + ". Doplň je ručně do config.yml, pokud mají být chráněné.");
        }
    }

    /** Finds the most specific configured command selector matching a player command. */
    public String matchedCommand(String commandInput) {
        List<String> tokens = CommandLabel.inputTokens(commandInput);
        if (tokens.isEmpty()) return "";
        for (int length = tokens.size(); length >= 1; length--) {
            String candidate = String.join(" ", tokens.subList(0, length));
            if (commandOwners.containsKey(candidate)) return candidate;
        }
        return "";
    }

    public UnlockDefinition byCommand(String commandInput) {
        String matched = matchedCommand(commandInput);
        String owner = matched.isBlank() ? null : commandOwners.get(matched);
        return owner == null ? null : definitions.get(owner);
    }

    public List<UnlockDefinition> inCategory(String category) {
        if (category == null || category.equalsIgnoreCase("all")) return List.copyOf(definitions.values());
        return definitions.values().stream().filter(def -> def.category().equalsIgnoreCase(category)).toList();
    }

    public static String normalizeCommand(String command) {
        return CommandLabel.normalizeConfiguredKey(command);
    }

    private static String string(Object object, String fallback) {
        return object == null ? fallback : String.valueOf(object);
    }

}
