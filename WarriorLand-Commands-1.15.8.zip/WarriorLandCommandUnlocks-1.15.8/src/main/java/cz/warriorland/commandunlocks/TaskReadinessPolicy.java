package cz.warriorland.commandunlocks;

/** Pure policy for retrying a ready unlock's one-time task reward without re-notifying unlocked items. */
public final class TaskReadinessPolicy {
    private TaskReadinessPolicy() { }

    /**
     * A ready unlock needs processing while it is still locked, or while its one-time task reward
     * has not yet been confirmed. The second case lets a failed PlayerPoints credit recover later.
     */
    public static boolean shouldProcess(boolean requirementsMet, boolean alreadyUnlocked, boolean rewardPaid) {
        return requirementsMet && (!alreadyUnlocked || !rewardPaid);
    }
}
