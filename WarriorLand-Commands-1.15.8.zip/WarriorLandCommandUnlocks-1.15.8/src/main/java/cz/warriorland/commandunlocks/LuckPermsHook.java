package cz.warriorland.commandunlocks;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.node.Node;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class LuckPermsHook {
    private final LuckPerms luckPerms;

    public LuckPermsHook() {
        this.luckPerms = LuckPermsProvider.get();
    }

    public CompletableFuture<Void> grant(UUID playerId, Collection<String> permissions) {
        return grantTracked(playerId, permissions).thenCompose(result -> {
            if (result.error() == null) return CompletableFuture.completedFuture(null);
            return CompletableFuture.failedFuture(result.error());
        });
    }

    /**
     * Grants permissions and returns both the newly introduced direct nodes and any failure.
     * The receipt is kept even if LuckPerms fails while saving, allowing a purchase to compensate
     * without deleting a permission that the player already had before starting the purchase.
     */
    public CompletableFuture<GrantResult> grantTracked(UUID playerId, Collection<String> permissions) {
        List<String> filtered = normalize(permissions);
        if (filtered.isEmpty()) return CompletableFuture.completedFuture(new GrantResult(List.of(), null));

        List<String> added = new ArrayList<>();
        CompletableFuture<? extends Object> update;
        try {
            update = luckPerms.getUserManager().modifyUser(playerId, user -> {
                var existing = user.data().toCollection();
                for (String permission : filtered) {
                    Node node = Node.builder(permission).value(true).build();
                    if (existing.contains(node)) continue;
                    user.data().add(node);
                    added.add(permission);
                }
            });
            if (update == null) {
                return CompletableFuture.completedFuture(new GrantResult(List.copyOf(added),
                        new IllegalStateException("LuckPerms nevrátil CompletableFuture.")));
            }
        } catch (RuntimeException error) {
            return CompletableFuture.completedFuture(new GrantResult(List.copyOf(added), error));
        }
        return update.handle((ignored, error) -> new GrantResult(List.copyOf(added), unwrap(error)));
    }

    public record GrantResult(List<String> newlyGranted, Throwable error) {
        public GrantResult {
            newlyGranted = newlyGranted == null ? List.of() : List.copyOf(newlyGranted);
        }
    }

    /** Removes only direct positive nodes; this should be used with a receipt from grantTracked. */
    public CompletableFuture<Void> revoke(UUID playerId, Collection<String> permissions) {
        List<String> filtered = normalize(permissions);
        if (filtered.isEmpty()) return CompletableFuture.completedFuture(null);
        return luckPerms.getUserManager().modifyUser(playerId, user -> {
            for (String permission : filtered) {
                user.data().remove(Node.builder(permission).value(true).build());
            }
        }).thenApply(user -> (Void) null);
    }

    private Throwable unwrap(Throwable error) {
        if (error instanceof java.util.concurrent.CompletionException completion && completion.getCause() != null) {
            return completion.getCause();
        }
        return error;
    }

    private List<String> normalize(Collection<String> permissions) {
        if (permissions == null) return List.of();
        return permissions.stream()
                .filter(java.util.Objects::nonNull)
                .map(String::trim)
                .filter(permission -> !permission.isBlank() && !permission.contains(" "))
                .distinct()
                .toList();
    }
}
