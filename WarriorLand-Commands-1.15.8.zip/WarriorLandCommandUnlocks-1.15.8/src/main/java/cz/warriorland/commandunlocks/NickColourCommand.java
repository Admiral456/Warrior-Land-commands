package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Safe, player-only shortcut that uses EssentialsX to persist a colored nickname. */
public final class NickColourCommand implements CommandExecutor, TabCompleter {
    private static final Map<String, Character> COLOURS = colours();
    private static final Pattern SAFE_NICKNAME = Pattern.compile("[A-Za-z0-9_]{1,16}");

    private final CommandUnlocksPlugin plugin;

    public NickColourCommand(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.sendMessage(sender, "only-player");
            return true;
        }
        Plugin essentials = Bukkit.getPluginManager().getPlugin("Essentials");
        if (essentials == null || !essentials.isEnabled()) {
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cBarevná přezdívka vyžaduje zapnutý EssentialsX."));
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &7Použití: &e/nickcolour <barva> <jméno_bez_mezer>"));
            player.sendMessage(plugin.color("&7Barvy: &cred &6gold &eyellow &agreen &baqua &9blue &ddark_purple &fwhite &8gray"));
            return true;
        }

        Character code = colourCode(args[0]);
        if (code == null) {
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cNeznámá barva. Použij například &ered, gold, green, aqua, blue, white &cnebo kód 0–9/a–f."));
            return true;
        }

        String nickname = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)).trim();
        if (!SAFE_NICKNAME.matcher(nickname).matches() || nickname.isBlank()) {
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cJméno může mít 1–16 znaků: anglická písmena, čísla a podtržítko. Mezerové a barevné kódy v textu nejsou povolené."));
            return true;
        }

        // The color code is selected from a fixed allow-list; nickname text rejects command and color syntax.
        // Execute EssentialsX's own nick command directly for the current player. This avoids dispatching a
        // second player command (which would hit the independent /nick unlock) and lets Essentials report
        // nickname validation failures directly to the player.
        try {
            if (!(essentials instanceof JavaPlugin essentialsJavaPlugin)) {
                player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cInstalace EssentialsX neposkytuje očekávané Bukkit rozhraní."));
                return true;
            }
            PluginCommand essentialsNick = essentialsJavaPlugin.getCommand("nick");
            if (essentialsNick == null || essentialsNick.getPlugin() != essentials) {
                player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cPříkaz /nick od EssentialsX není dostupný."));
                return true;
            }
            boolean executed = essentialsNick.execute(player, "nick", new String[]{"&" + code + nickname});
            if (!executed) {
                player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cEssentialsX nepřijal změnu přezdívky. Zkontroluj svou konfiguraci nebo kontaktuj administrátora."));
            }
        } catch (RuntimeException exception) {
            plugin.getLogger().warning("Vlastní /nickcolour selhal pro hráče " + player.getName() + ": " + exception.getMessage());
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cPřezdívku se nepodařilo změnit. Kontaktuj administrátora."));
        }
        return true;
    }

    static Character colourCode(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String value = raw.toLowerCase(Locale.ROOT).trim();
        if (value.length() == 1 && "0123456789abcdef".contains(value)) return value.charAt(0);
        return COLOURS.get(value);
    }

    static boolean isSafeNickname(String nickname) {
        return nickname != null && !nickname.isBlank() && SAFE_NICKNAME.matcher(nickname.trim()).matches();
    }

    private static Map<String, Character> colours() {
        Map<String, Character> colours = new LinkedHashMap<>();
        colours.put("black", '0');
        colours.put("dark_blue", '1');
        colours.put("dark_green", '2');
        colours.put("dark_aqua", '3');
        colours.put("dark_red", '4');
        colours.put("dark_purple", '5');
        colours.put("purple", '5');
        colours.put("gold", '6');
        colours.put("gray", '7');
        colours.put("grey", '7');
        colours.put("dark_gray", '8');
        colours.put("dark_grey", '8');
        colours.put("blue", '9');
        colours.put("green", 'a');
        colours.put("aqua", 'b');
        colours.put("red", 'c');
        colours.put("light_purple", 'd');
        colours.put("pink", 'd');
        colours.put("yellow", 'e');
        colours.put("white", 'f');
        return Map.copyOf(colours);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player)) return List.of();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return COLOURS.keySet().stream().filter(value -> value.startsWith(prefix)).sorted().toList();
        }
        return new ArrayList<>();
    }
}
