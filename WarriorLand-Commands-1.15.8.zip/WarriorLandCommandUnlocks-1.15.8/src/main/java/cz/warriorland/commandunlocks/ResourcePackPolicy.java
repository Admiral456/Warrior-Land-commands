package cz.warriorland.commandunlocks;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;

/** Validates optional resource-pack delivery without making the pack mandatory by default. */
final class ResourcePackPolicy {
    private static final int MAX_URL_LENGTH = 32_767;
    private static final String PACK_ID_NAMESPACE = "warriorland-command-unlocks-resource-pack";

    private ResourcePackPolicy() { }

    static boolean shouldSend(String rawUrl, String rawSha1) {
        return rawUrl != null && !rawUrl.isBlank()
                && isValidHttpsUrl(rawUrl) && isValidSha1OrBlank(rawSha1);
    }

    static boolean isValidHttpsUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.isBlank()) return false;
        String value = rawUrl.trim();
        if (value.length() > MAX_URL_LENGTH) return false;
        // Minecraft's resource-pack protocol requires an ASCII/RFC 1738 encoded URL.
        if (value.chars().anyMatch(character -> character > 0x7f || Character.isISOControl(character))) return false;
        try {
            URI uri = new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme())
                    && uri.getHost() != null && !uri.getHost().isBlank()
                    && uri.getUserInfo() == null && uri.getFragment() == null
                    && (uri.getPort() == -1 || (uri.getPort() >= 1 && uri.getPort() <= 65535));
        } catch (URISyntaxException | IllegalArgumentException exception) {
            return false;
        }
    }

    static boolean isValidSha1OrBlank(String rawSha1) {
        return rawSha1 == null || rawSha1.isBlank() || rawSha1.trim().matches("(?i)^[0-9a-f]{40}$");
    }

    static byte[] decodeSha1(String rawSha1) {
        if (rawSha1 == null || rawSha1.isBlank()) return null;
        String value = rawSha1.trim();
        if (!value.matches("(?i)^[0-9a-f]{40}$")) throw new IllegalArgumentException("SHA-1 must contain exactly 40 hexadecimal characters.");
        byte[] bytes = new byte[20];
        for (int i = 0; i < bytes.length; i++) {
            int high = Character.digit(value.charAt(i * 2), 16);
            int low = Character.digit(value.charAt(i * 2 + 1), 16);
            bytes[i] = (byte) ((high << 4) | low);
        }
        return bytes;
    }

    /** Stable per-URL-and-hash identifier lets the status listener ignore packs sent by other plugins. */
    static UUID requestId(String rawUrl, String rawSha1) {
        if (!shouldSend(rawUrl, rawSha1)) {
            throw new IllegalArgumentException("Cannot create a resource-pack ID from invalid URL/hash configuration.");
        }
        String identity = PACK_ID_NAMESPACE + "\n" + rawUrl.trim() + "\n"
                + (rawSha1 == null ? "" : rawSha1.trim().toLowerCase(Locale.ROOT));
        return UUID.nameUUIDFromBytes(identity.getBytes(StandardCharsets.UTF_8));
    }

    static String configurationProblem(String rawUrl, String rawSha1, boolean required) {
        String url = rawUrl == null ? "" : rawUrl.trim();
        String sha1 = rawSha1 == null ? "" : rawSha1.trim();
        if (url.isEmpty()) {
            if (!sha1.isEmpty()) return "resource-pack-sha1 je nastavený, ale resource-pack-url je prázdná.";
            if (required) return "resource-pack-force=true vyžaduje nakonfigurovanou HTTPS adresu resource packu.";
            return null;
        }
        if (!isValidHttpsUrl(url)) return "resource-pack-url musí být platná HTTPS URL v ASCII/RFC 1738 formátu, bez uživatelských údajů a fragmentu.";
        if (!isValidSha1OrBlank(sha1)) return "resource-pack-sha1 musí být prázdný nebo obsahovat přesně 40 hexadecimálních znaků.";
        return null;
    }
}
