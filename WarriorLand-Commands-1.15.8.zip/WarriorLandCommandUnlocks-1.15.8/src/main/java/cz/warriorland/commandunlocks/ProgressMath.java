package cz.warriorland.commandunlocks;

/** Small, pure arithmetic helpers used for persistent task progress. */
public final class ProgressMath {
    private ProgressMath() { }

    /** Adds a non-negative amount without integer overflow and never exceeds the target cap. */
    public static int addCapped(int current, int amount, int cap) {
        long safeCap = Math.max(0L, cap);
        long safeCurrent = Math.max(0L, current);
        long safeAmount = Math.max(0L, amount);
        return (int) Math.min(safeCap, safeCurrent + safeAmount);
    }

    /** Adds non-negative statistics without allowing long overflow to reset a lifetime counter. */
    public static long addNonNegativeSaturated(long current, long amount) {
        long safeCurrent = Math.max(0L, current);
        long safeAmount = Math.max(0L, amount);
        if (Long.MAX_VALUE - safeCurrent < safeAmount) return Long.MAX_VALUE;
        return safeCurrent + safeAmount;
    }
}
