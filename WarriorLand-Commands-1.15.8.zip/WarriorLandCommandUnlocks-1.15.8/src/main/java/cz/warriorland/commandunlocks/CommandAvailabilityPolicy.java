package cz.warriorland.commandunlocks;

import java.util.Collection;

/** Conservative policy for root-command availability discovered from Bukkit/Paper's command map. */
public final class CommandAvailabilityPolicy {
    public enum Status { REGISTERED, MISSING, UNKNOWN }

    private CommandAvailabilityPolicy() { }

    /** A selector group is available if at least one accepted command/alias is registered. */
    public static Status aggregate(Collection<Status> values) {
        if (values == null || values.isEmpty()) return Status.UNKNOWN;
        boolean unknown = false;
        for (Status value : values) {
            if (value == Status.REGISTERED) return Status.REGISTERED;
            if (value == null || value == Status.UNKNOWN) unknown = true;
        }
        return unknown ? Status.UNKNOWN : Status.MISSING;
    }

    /** An inaccessible command map means "unknown", not "missing"; never block on lack of evidence. */
    public static boolean blocksPurchase(Status status) {
        return status == Status.MISSING;
    }

    public static int availabilityRank(Status status) {
        return switch (status == null ? Status.UNKNOWN : status) {
            case REGISTERED -> 0;
            case UNKNOWN -> 1;
            case MISSING -> 4;
        };
    }
}
