package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.EventExecutor;

import java.lang.reflect.Method;
import java.util.UUID;

/** Optional, reflection-based integration so VotingPlugin remains an optional dependency. */
public final class VotingPluginHook {
    private static final String VOTE_EVENT_CLASS = "com.bencodez.votingplugin.events.PlayerPostVoteEvent";

    private final CommandUnlocksPlugin plugin;
    private boolean registered;

    public boolean isRegistered() { return registered; }

    public VotingPluginHook(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @SuppressWarnings("unchecked")
    public void registerIfAvailable() {
        if (registered) return;
        if (!plugin.getConfig().getBoolean("integrations.voting-plugin.enabled", true)) {
            plugin.getLogger().info("Integrace VotingPlugin je vypnutá v konfiguraci.");
            return;
        }

        Plugin votingPlugin = Bukkit.getPluginManager().getPlugin("VotingPlugin");
        if (votingPlugin == null || !votingPlugin.isEnabled()) {
            plugin.getLogger().info("VotingPlugin nebyl nalezen; úkoly typu VOTE zůstanou neaktivní, dokud integraci nezapneš a nespustíš server s VotingPluginem.");
            return;
        }

        try {
            Class<?> rawEventClass = Class.forName(VOTE_EVENT_CLASS, false, votingPlugin.getClass().getClassLoader());
            if (!Event.class.isAssignableFrom(rawEventClass)) {
                throw new IllegalStateException(VOTE_EVENT_CLASS + " není Bukkit Event.");
            }
            Class<? extends Event> eventClass = (Class<? extends Event>) rawEventClass;
            EventExecutor executor = (listener, event) -> onVote(event);
            Bukkit.getPluginManager().registerEvent(eventClass, new VoteListenerMarker(), EventPriority.MONITOR,
                    executor, plugin, true);
            registered = true;
            plugin.getLogger().info("Integrace VotingPlugin aktivní: úkoly typu VOTE počítají zpracované hlasy.");
        } catch (ClassNotFoundException exception) {
            plugin.getLogger().warning("VotingPlugin je nainstalovaný, ale PlayerPostVoteEvent nebyl nalezen. Úkoly typu VOTE nebudou počítány; ověř verzi VotingPluginu.");
        } catch (Exception | LinkageError exception) {
            plugin.getLogger().warning("Nepodařilo se připojit VotingPlugin: " + exception.getMessage());
        }
    }

    private void onVote(Event event) {
        if (!plugin.getConfig().getBoolean("integrations.voting-plugin.enabled", true)) return;
        // PlayerPostVoteEvent exposes its own boolean flags but does not implement Bukkit Cancellable,
        // so Bukkit's registerEvent(ignoreCancelled=true) alone is not enough here.
        Boolean realVote = booleanValue(event, "isRealVote", "getRealVote");
        Boolean cancelled = booleanValue(event, "isCancelled", "getCancelled");
        if (!VoteEligibility.isCountable(realVote, cancelled)) return;

        // PlayerPostVoteEvent is asynchronous in current VotingPlugin versions. Extract only immutable
        // values here, then resolve online/offline state and mutate plugin data on the server thread.
        String playerName = stringValue(event, "getPlayerName", "getPlayer");
        UUID eventUuid = uuidValue(event);
        Runnable action = () -> {
            UUID playerId = eventUuid;
            Player online = playerId == null ? null : Bukkit.getPlayer(playerId);

            if (playerId == null && playerName != null) {
                playerId = plugin.data().findKnownUuidByName(playerName);
            }
            if (playerId == null && playerName != null) {
                OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(playerName);
                if (cached != null) playerId = cached.getUniqueId();
            }
            if (playerId == null) {
                plugin.getLogger().warning("Přijat skutečný hlas z VotingPluginu, ale nelze bezpečně určit UUID hráče '" + playerName + "'. Hlas nebyl započítán do úkolů WarriorLandu.");
                return;
            }

            if (online == null) online = Bukkit.getPlayer(playerId);
            plugin.data().rememberPlayerName(playerId, playerName);
            plugin.tasks().progress(playerId, online, "VOTE", "VOTE", 1);
        };

        if (event.isAsynchronous()) Bukkit.getScheduler().runTask(plugin, action);
        else action.run();
    }

    private String stringValue(Object object, String... methodNames) {
        for (String methodName : methodNames) {
            try {
                Method method = object.getClass().getMethod(methodName);
                Object value = method.invoke(object);
                if (value instanceof String string && !string.isBlank()) return string;
                if (value instanceof Player player) return player.getName();
                if (value instanceof OfflinePlayer player) return player.getName();
            } catch (ReflectiveOperationException ignored) {
                // Try another known getter name; no optional VotingPlugin classes are linked at compile time.
            }
        }
        return null;
    }

    private Boolean booleanValue(Object object, String... methodNames) {
        for (String methodName : methodNames) {
            try {
                Method method = object.getClass().getMethod(methodName);
                Object value = method.invoke(object);
                if (value instanceof Boolean result) return result;
            } catch (ReflectiveOperationException ignored) {
                // Try another known getter name.
            }
        }
        return null;
    }

    private UUID uuidValue(Object object) {
        for (String methodName : new String[]{"getPlayerUUID", "getPlayerUuid", "getUUID", "getUuid", "getUniqueId", "getPlayer"}) {
            try {
                Method method = object.getClass().getMethod(methodName);
                Object value = method.invoke(object);
                if (value instanceof UUID uuid) return uuid;
                if (value instanceof Player player) return player.getUniqueId();
                if (value instanceof OfflinePlayer player) return player.getUniqueId();
            } catch (ReflectiveOperationException ignored) {
                // Try another getter.
            }
        }
        return null;
    }

    /** Bukkit requires a Listener instance when dynamically registering an event. */
    private static final class VoteListenerMarker implements org.bukkit.event.Listener { }
}
