package cz.warriorland.commandunlocks;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;

/** Small, dependency-free validators for the most important unlock configuration values. */
public final class UnlockConfigurationRules {
    private UnlockConfigurationRules() { }

    /** Null means the optional filter list was omitted; a present value must be a list of strings. */
    public static boolean isStringListOrMissing(Object object) {
        if (object == null) return true;
        if (!(object instanceof List<?> raw)) return false;
        return raw.stream().allMatch(value -> value instanceof String string && !string.isBlank());
    }

    /** Every task definition must be a map; an empty list is accepted syntactically and checked separately. */
    public static boolean isMapList(Object object) {
        return object instanceof List<?> raw && raw.stream().allMatch(Map.class::isInstance);
    }

    /** A config with no usable definitions must never replace the currently active command gate. */
    public static boolean hasUsableUnlocks(int usableDefinitions) {
        return usableDefinitions > 0;
    }

    /**
     * Validates a permission node for an unlock. Wildcards are opt-in and only accepted as a
     * terminal ".*" segment; a global "*" node is never accepted by this plugin.
     */
    /**
     * Resolves a configured permission without allowing blank, malformed, or wildcard values to
     * accidentally turn an admin/bypass check into an empty or overly broad permission query.
     */
    public static String permissionSettingOrDefault(Object rawValue, String fallback) {
        if (!(rawValue instanceof String value) || value.isBlank()) return fallback;
        String normalized = value.trim();
        return isPermissionNode(normalized, false) ? normalized : fallback;
    }

    public static boolean isPermissionNode(String permission, boolean allowWildcard) {
        if (permission == null) return false;
        String value = permission.trim();
        if (value.isEmpty()) return false;
        boolean wildcard = value.endsWith(".*");
        if (value.contains("*") && (!allowWildcard || !wildcard || value.indexOf('*') != value.length() - 1)) {
            return false;
        }
        if (wildcard) value = value.substring(0, value.length() - 2);
        return !value.isBlank() && value.matches("[A-Za-z0-9_-]+(?:[.:][A-Za-z0-9_-]+)*");
    }

    public static List<String> stringList(Object object) {
        if (!(object instanceof List<?> raw)) return List.of();
        return raw.stream().filter(String.class::isInstance).map(String.class::cast)
                .map(String::trim).filter(value -> !value.isBlank()).toList();
    }

    public static int integer(Object object, int fallback) {
        if (!isInteger(object)) return fallback;
        if (object instanceof Number number) return number.intValue();
        try {
            return Integer.parseInt(String.valueOf(object).trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public static boolean isInteger(Object object) {
        if (object == null) return false;
        if (object instanceof BigInteger integer) {
            return integer.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) >= 0
                    && integer.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) <= 0;
        }
        if (object instanceof BigDecimal decimal) {
            try {
                decimal.intValueExact();
                return true;
            } catch (ArithmeticException ignored) {
                return false;
            }
        }
        if (object instanceof Number number) {
            double value = number.doubleValue();
            return Double.isFinite(value) && value == Math.rint(value)
                    && value >= Integer.MIN_VALUE && value <= Integer.MAX_VALUE;
        }
        try {
            Integer.parseInt(String.valueOf(object).trim());
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }
}
