package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicInteger;

public final class PlayerDataStore {
    private final CommandUnlocksPlugin plugin;
    private final File file;
    private final Object saveLock = new Object();
    private final AtomicLong version = new AtomicLong();
    private final AtomicInteger consecutiveSaveFailures = new AtomicInteger();
    private long lastWrittenVersion = -1;
    private BukkitTask delayedSave;
    private BukkitTask retrySave;
    private YamlConfiguration data;

    public PlayerDataStore(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            throw new IllegalStateException("Nepodařilo se vytvořit adresář pluginu: " + plugin.getDataFolder());
        }

        // Never silently replace a malformed player database with an empty one: that would lose
        // every unlock/progress entry on the next save. Keep the original file and make a backup.
        YamlConfiguration loaded = new YamlConfiguration();
        if (file.exists()) {
            try {
                loaded.load(file);
            } catch (IOException | InvalidConfigurationException exception) {
                Path backup = file.toPath().resolveSibling(file.getName() + ".corrupt-" + System.currentTimeMillis() + ".bak");
                try {
                    Files.copy(file.toPath(), backup);
                    plugin.getLogger().severe("Poškozené players.yml bylo zkopírováno do " + backup.getFileName() + ". Původní soubor nebyl přepsán.");
                } catch (IOException backupException) {
                    plugin.getLogger().severe("Nepodařilo se vytvořit zálohu poškozeného players.yml: " + backupException.getMessage());
                }
                throw new IllegalStateException("Nelze bezpečně načíst " + file.getName() + "; plugin se vypíná, aby nepřepsal uložená data.", exception);
            }
        }
        data = loaded;
    }

    public boolean isLoaded() {
        return data != null;
    }

    public void rememberPlayerName(UUID uuid, String playerName) {
        if (uuid == null || playerName == null || playerName.isBlank()) return;
        String key = path(uuid) + ".last-name";
        if (!playerName.equals(data.getString(key, ""))) {
            data.set(key, playerName);
            saveAsyncSoon();
        }
    }


    /** Null means the player has not answered the first-run tutorial prompt. */
    public Boolean getTutorialChoice(UUID uuid) {
        Object value = data.get(path(uuid) + ".preferences.tutorial-enabled");
        return value instanceof Boolean choice ? choice : null;
    }

    /** Persist the first-run decision immediately because it controls the next menu opening. */
    public boolean setTutorialChoice(UUID uuid, Boolean enabled) {
        if (uuid == null || data == null) return false;
        String preferencePath = path(uuid) + ".preferences.tutorial-enabled";
        // Keep memory consistent with the durable file. Without this rollback, a failed save could
        // suppress the first-run prompt until restart even though the player's choice was not stored.
        return TutorialChoiceMutationPolicy.persistOrRestore(data, preferencePath, enabled, this::saveSync);
    }

    /** Null means use the server-wide default HUD setting from config.yml. */
    public Boolean getHudChoice(UUID uuid) {
        if (uuid == null || data == null) return null;
        Object value = data.get(path(uuid) + ".preferences.hud-enabled");
        return value instanceof Boolean choice ? choice : null;
    }

    /** Stores an explicit per-player HUD choice, restoring the previous in-memory value on disk failure. */
    public boolean setHudChoice(UUID uuid, Boolean enabled) {
        if (uuid == null || data == null) return false;
        String preferencePath = path(uuid) + ".preferences.hud-enabled";
        return TutorialChoiceMutationPolicy.persistOrRestore(data, preferencePath, enabled, this::saveSync);
    }

    /** Resolve names from our own persisted cache without issuing a blocking profile lookup. */
    public UUID findKnownUuidByName(String playerName) {
        if (playerName == null || playerName.isBlank()) return null;
        ConfigurationSection players = data.getConfigurationSection("players");
        if (players == null) return null;
        UUID match = null;
        for (String rawUuid : players.getKeys(false)) {
            String lastName = data.getString("players." + rawUuid + ".last-name", "");
            if (!lastName.equalsIgnoreCase(playerName)) continue;
            try {
                UUID candidate = UUID.fromString(rawUuid);
                if (match != null && !match.equals(candidate)) {
                    // Avoid crediting votes to the wrong account after online/offline UUID changes.
                    plugin.getLogger().warning("Jméno hráče '" + playerName + "' je v players.yml přiřazeno více UUID; hlas nelze bezpečně započítat podle jména.");
                    return null;
                }
                match = candidate;
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Neplatné UUID v players.yml: " + rawUuid);
            }
        }
        return match;
    }

    /** Debounced progress save: a burst of mined blocks produces one disk write, not one write per event. */
    public void saveAsyncSoon() {
        if (data == null || delayedSave != null) return;
        try {
            delayedSave = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                delayedSave = null;
                saveAsync();
            }, 40L);
        } catch (IllegalStateException schedulerUnavailable) {
            // During shutdown, make a best-effort synchronous flush instead of losing the final
            // progress mutation because the scheduler no longer accepts delayed tasks.
            if (plugin.isShuttingDown()) saveSync();
            else {
                plugin.getLogger().severe("Nelze naplánovat uložení players.yml: " + schedulerUnavailable.getMessage());
                scheduleSaveRetry();
            }
        }
    }

    public int getTaskProgress(UUID uuid, String unlockId, String taskId) {
        return Math.max(0, data.getInt(path(uuid) + ".progress." + unlockId + "." + taskId, 0));
    }

    public int addTaskProgress(UUID uuid, String unlockId, String taskId, int amount, int cap) {
        String progressPath = path(uuid) + ".progress." + unlockId + "." + taskId;
        int old = Math.max(0, data.getInt(progressPath, 0));
        int updated = ProgressMath.addCapped(old, amount, cap);
        if (updated != old) {
            data.set(progressPath, updated);
            saveAsyncSoon();
        }
        return updated;
    }

    public boolean isUnlocked(UUID uuid, String unlockId) {
        return data.getStringList(path(uuid) + ".unlocked").contains(unlockId.toLowerCase(Locale.ROOT));
    }

    public Set<String> getUnlocked(UUID uuid) {
        return new HashSet<>(data.getStringList(path(uuid) + ".unlocked"));
    }

    public void unlock(UUID uuid, String unlockId) {
        Set<String> unlocked = getUnlocked(uuid);
        unlocked.add(unlockId.toLowerCase(Locale.ROOT));
        data.set(path(uuid) + ".unlocked", unlocked.stream().sorted().toList());
        saveAsyncSoon();
    }

    public boolean hasReadyNotification(UUID uuid, String unlockId) {
        return data.getStringList(path(uuid) + ".ready-notified").contains(unlockId.toLowerCase(Locale.ROOT));
    }

    public void markReadyNotification(UUID uuid, String unlockId) {
        Set<String> notified = new HashSet<>(data.getStringList(path(uuid) + ".ready-notified"));
        notified.add(unlockId.toLowerCase(Locale.ROOT));
        data.set(path(uuid) + ".ready-notified", notified.stream().sorted().toList());
        saveAsyncSoon();
    }

    public boolean hasReceivedTaskReward(UUID uuid, String unlockId) {
        return data.getBoolean(path(uuid) + ".task-reward-paid." + unlockId, false);
    }

    public void markTaskRewardPaid(UUID uuid, String unlockId) {
        data.set(path(uuid) + ".task-reward-paid." + unlockId, true);
        saveAsyncSoon();
    }

    public long getPointsEarnedFromTasks(UUID uuid) {
        return Math.max(0L, data.getLong(path(uuid) + ".stats.points-earned-from-tasks", 0L));
    }

    public long getPointsSpentOnUnlocks(UUID uuid) {
        return Math.max(0L, data.getLong(path(uuid) + ".stats.points-spent-on-unlocks", 0L));
    }

    public void recordTaskPoints(UUID uuid, int amount) {
        String statsPath = path(uuid) + ".stats.points-earned-from-tasks";
        data.set(statsPath, ProgressMath.addNonNegativeSaturated(data.getLong(statsPath, 0L), Math.max(0, amount)));
        saveAsyncSoon();
    }

    public void recordSpentPoints(UUID uuid, int amount) {
        String statsPath = path(uuid) + ".stats.points-spent-on-unlocks";
        data.set(statsPath, ProgressMath.addNonNegativeSaturated(data.getLong(statsPath, 0L), Math.max(0, amount)));
        saveAsyncSoon();
    }

    /** Roll back the local record if a purchase could not be durably committed. */
    public void revertPurchase(UUID uuid, String unlockId, int spentAmount) {
        Set<String> unlocked = getUnlocked(uuid);
        unlocked.remove(unlockId.toLowerCase(Locale.ROOT));
        data.set(path(uuid) + ".unlocked", unlocked.stream().sorted().toList());
        String statsPath = path(uuid) + ".stats.points-spent-on-unlocks";
        data.set(statsPath, Math.max(0L, data.getLong(statsPath, 0L) - Math.max(0, spentAmount)));
        saveAsyncSoon();
    }

    /** Roll back a credited task reward if its one-time marker could not be persisted. */
    public void revertTaskReward(UUID uuid, String unlockId, int amount) {
        data.set(path(uuid) + ".task-reward-paid." + unlockId, false);
        String statsPath = path(uuid) + ".stats.points-earned-from-tasks";
        data.set(statsPath, Math.max(0L, data.getLong(statsPath, 0L) - Math.max(0, amount)));
        saveAsyncSoon();
    }

    private String path(UUID uuid) {
        return "players." + uuid;
    }

    private void saveAsync() {
        if (data == null) return;
        String snapshot = data.saveToString();
        long snapshotVersion = version.incrementAndGet();
        try {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                boolean saved = writeSnapshot(snapshot, snapshotVersion);
                handleWriteResult(snapshotVersion, saved);
            });
        } catch (IllegalStateException schedulerUnavailable) {
            plugin.getLogger().warning("Nelze naplánovat asynchronní uložení players.yml; bude použita opravná cesta, až to plánovač dovolí.");
            scheduleSaveRetry();
        }
    }

    /** Flush pending changes when a player leaves, without writing the whole database on every quit. */
    public void flushPending() {
        if (delayedSave != null || retrySave != null) saveSync();
    }

    /** Writes the latest snapshot and reports I/O failure to callers performing economy transactions. */
    public boolean saveSync() {
        if (data == null) return false;
        if (delayedSave != null) {
            delayedSave.cancel();
            delayedSave = null;
        }
        String snapshot = data.saveToString();
        long snapshotVersion = version.incrementAndGet();
        boolean saved = writeSnapshot(snapshot, snapshotVersion);
        handleWriteResult(snapshotVersion, saved);
        return saved;
    }

    private void handleWriteResult(long snapshotVersion, boolean saved) {
        if (!saved) {
            scheduleSaveRetry();
            return;
        }
        // Do not clear failure history when a concurrent mutation made this snapshot stale.
        if (snapshotVersion < version.get()) return;
        synchronized (this) {
            consecutiveSaveFailures.set(0);
            if (retrySave != null) {
                retrySave.cancel();
                retrySave = null;
            }
        }
    }

    private synchronized void scheduleSaveRetry() {
        if (data == null || retrySave != null || !plugin.isEnabled() || plugin.isShuttingDown()) return;
        int failures = consecutiveSaveFailures.incrementAndGet();
        long delay = SaveRetryPolicy.delayTicks(failures);
        try {
            retrySave = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                synchronized (PlayerDataStore.this) {
                    retrySave = null;
                }
                // Take a fresh snapshot on the server thread rather than retrying stale bytes.
                saveAsync();
            }, delay);
            plugin.getLogger().warning("Uložení players.yml selhalo; další automatický pokus proběhne přibližně za "
                    + Math.max(1, delay / 20) + " s (pokus " + failures + ").");
        } catch (IllegalStateException schedulerUnavailable) {
            plugin.getLogger().severe("Nelze naplánovat opakované uložení players.yml, protože se server vypíná. Změny mohou vyžadovat obnovu při příštím startu.");
        }
    }

    private boolean writeSnapshot(String snapshot, long snapshotVersion) {
        synchronized (saveLock) {
            // Older queued snapshots must never overwrite a newer mutation after the newer write
            // failed. A later save/retry is responsible for writing the current in-memory state.
            if (!SnapshotWritePolicy.shouldWrite(snapshotVersion, lastWrittenVersion, version.get())) {
                // A superseded synchronous snapshot is not automatically a successful save: the
                // newer version may still be queued or its write may have failed. Only report
                // durable success if a snapshot at least this new is already on disk.
                return SnapshotWritePolicy.isDurablyWritten(snapshotVersion, lastWrittenVersion);
            }
            try {
                Path target = file.toPath();
                Path temporary = target.resolveSibling(file.getName() + ".tmp");
                Files.writeString(temporary, snapshot, StandardCharsets.UTF_8);
                try {
                    Files.move(temporary, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                            java.nio.file.StandardCopyOption.ATOMIC_MOVE);
                } catch (java.nio.file.AtomicMoveNotSupportedException atomicNotSupported) {
                    Files.move(temporary, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                lastWrittenVersion = snapshotVersion;
                return true;
            } catch (IOException | SecurityException exception) {
                plugin.getLogger().severe("Nepodařilo se uložit players.yml: " + exception.getMessage());
                return false;
            }
        }
    }
}
