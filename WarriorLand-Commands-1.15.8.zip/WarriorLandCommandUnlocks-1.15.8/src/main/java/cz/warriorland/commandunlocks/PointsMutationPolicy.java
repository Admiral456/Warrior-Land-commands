package cz.warriorland.commandunlocks;

/** Strictly interprets supported PlayerPoints mutation method contracts. */
public final class PointsMutationPolicy {
    private PointsMutationPolicy() { }

    public static boolean supportsReturnType(Class<?> returnType) {
        return returnType == void.class || returnType == boolean.class || returnType == Boolean.class;
    }

    /** A null Boolean or an unfamiliar return type is not evidence of a successful transaction. */
    public static boolean succeeded(Class<?> returnType, Object result) {
        if (returnType == void.class) return true;
        return (returnType == boolean.class || returnType == Boolean.class) && Boolean.TRUE.equals(result);
    }
}
