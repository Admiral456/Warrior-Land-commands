package cz.warriorland.commandunlocks;

import java.util.Set;

/** Pure command-gate decisions, kept separate so the fail-closed behavior can be regression-tested. */
public final class CommandGatePolicy {
    private static final Set<String> MENU_COMMANDS = Set.of("prikazy", "odemykani", "unlock", "odemykat");

    private CommandGatePolicy() { }

    /** Returns the attempted label or an empty string when the message is not a player command. */
    public static String commandLabel(String message) {
        if (message == null || !message.startsWith("/")) return "";
        String label = CommandLabel.normalize(message.substring(1));
        return label.isBlank() || MENU_COMMANDS.contains(label) ? "" : label;
    }

    /** Safe mode fails closed, except for an explicit administrator bypass permission. */
    public static boolean shouldBlock(boolean hasBypass, boolean safeModeOrMissingData, boolean unlocked) {
        return !hasBypass && (safeModeOrMissingData || !unlocked);
    }
}
