package cz.warriorland.commandunlocks;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/** Pure policy for safely assigning automatically discovered command aliases to unlocks. */
public final class CommandAliasPolicy {
    private CommandAliasPolicy() { }

    /**
     * Preserve all explicit command ownership and auto-add an alias only when every registered
     * command object exposing it belongs to the same unlock. Ambiguous aliases stay unowned.
     */
    public static Resolution resolve(Map<String, String> explicitOwners,
                                     Collection<? extends Set<String>> registeredCommandGroups,
                                     Set<String> reservedLabels) {
        Map<String, String> resolved = new LinkedHashMap<>(explicitOwners);
        Map<String, Set<String>> candidates = collectCandidates(explicitOwners, registeredCommandGroups, reservedLabels);
        Set<String> ambiguous = candidates.entrySet().stream()
                .filter(entry -> entry.getValue().size() > 1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toUnmodifiableSet());

        for (Map.Entry<String, Set<String>> entry : candidates.entrySet()) {
            if (entry.getValue().size() == 1) {
                resolved.put(entry.getKey(), entry.getValue().iterator().next());
            }
        }
        return new Resolution(Map.copyOf(resolved), ambiguous);
    }

    private static Map<String, Set<String>> collectCandidates(Map<String, String> explicitOwners,
                                                               Collection<? extends Set<String>> groups,
                                                               Set<String> reservedLabels) {
        Map<String, Set<String>> candidates = new HashMap<>();
        Set<String> reserved = reservedLabels == null ? Set.of() : reservedLabels;
        if (groups == null) return candidates;

        for (Set<String> group : groups) {
            if (group == null || group.isEmpty()) continue;
            Set<String> unlockIds = new HashSet<>();
            for (String label : group) {
                if (label == null) continue;
                String owner = explicitOwners.get(label);
                if (owner != null) unlockIds.add(owner);
            }
            if (unlockIds.isEmpty()) continue;
            for (String label : group) {
                if (label == null || label.isBlank() || explicitOwners.containsKey(label) || reserved.contains(label)) continue;
                candidates.computeIfAbsent(label, ignored -> new HashSet<>()).addAll(unlockIds);
            }
        }
        return candidates;
    }

    public record Resolution(Map<String, String> owners, Set<String> ambiguousAliases) {
        public Resolution {
            owners = Map.copyOf(owners);
            ambiguousAliases = Set.copyOf(ambiguousAliases);
        }
    }
}
