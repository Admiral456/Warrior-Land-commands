package cz.warriorland.commandunlocks;

/** Exponential backoff for recovering transient player-data file write failures. */
public final class SaveRetryPolicy {
    private static final long BASE_DELAY_TICKS = 20L;
    private static final long MAX_DELAY_TICKS = 1200L;

    private SaveRetryPolicy() { }

    /** Returns 1, 2, 4, 8, 16, 32, then at most 60 seconds between retries. */
    public static long delayTicks(int consecutiveFailures) {
        int failures = Math.max(1, consecutiveFailures);
        int exponent = Math.min(6, failures - 1);
        return Math.min(MAX_DELAY_TICKS, BASE_DELAY_TICKS << exponent);
    }
}
