package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/** Refreshes auto-discovered command aliases when server plugins register/remove commands. */
public final class CommandAliasLifecycleListener implements Listener {
    private final CommandUnlocksPlugin plugin;
    private BukkitTask pendingRefresh;

    public CommandAliasLifecycleListener(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPluginEnable(PluginEnableEvent event) {
        scheduleRefresh(event.getPlugin());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPluginDisable(PluginDisableEvent event) {
        scheduleRefresh(event.getPlugin());
    }

    private void scheduleRefresh(Plugin changedPlugin) {
        if (changedPlugin == plugin || plugin.isShuttingDown()) return;
        if (pendingRefresh != null) return;
        try {
            // Let the plugin manager finish adding/removing the command entries before reading CommandMap.
            pendingRefresh = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                pendingRefresh = null;
                if (plugin.isShuttingDown() || plugin.unlocks() == null) return;
                plugin.unlocks().refreshCommandAliases();
            }, 1L);
        } catch (IllegalStateException schedulerUnavailable) {
            plugin.getLogger().warning("Aliasy příkazů nebylo možné obnovit po změně pluginu: " + schedulerUnavailable.getMessage());
        }
    }
}
