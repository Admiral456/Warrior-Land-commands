package cz.warriorland.commandunlocks;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class MenuHolder implements InventoryHolder {
    private Inventory inventory;
    private final String category;
    private final int page;
    private final String selectedId;
    private final boolean pointsView;
    private final boolean confirmationView;

    public MenuHolder(String category, int page, String selectedId, boolean pointsView) {
        this(category, page, selectedId, pointsView, false);
    }

    public MenuHolder(String category, int page, String selectedId, boolean pointsView, boolean confirmationView) {
        this.category = category;
        this.page = Math.max(0, page);
        this.selectedId = selectedId;
        this.pointsView = pointsView;
        this.confirmationView = confirmationView;
    }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }
    public String category() { return category; }
    public int page() { return page; }
    public String selectedId() { return selectedId; }
    public boolean pointsView() { return pointsView; }
    public boolean confirmationView() { return confirmationView; }

    @Override
    public Inventory getInventory() { return inventory; }
}
