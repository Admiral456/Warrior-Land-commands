package cz.warriorland.commandunlocks;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Optional vanilla resource-pack delivery and per-player detection for safe custom icon fallback. */
public final class ResourcePackListener implements Listener {
    private final CommandUnlocksPlugin plugin;
    /** UUID player -> exact pack request ID successfully loaded this session. */
    private final Map<UUID, UUID> loadedPackIds = new HashMap<>();
    private boolean invalidConfigLogged;
    /** The request UUID active in the current configuration; used to remove stale versions on reload. */
    private UUID activeRequestId;
    /** Tracks force-mode changes separately from content identity, which deliberately stays URL/hash-only. */
    private boolean activeForce;

    public ResourcePackListener(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
        this.activeRequestId = configuredRequestId();
        this.activeForce = plugin.getConfig().getBoolean("settings.resource-pack-force", false);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        offerConfiguredPack(event.getPlayer());
    }

    private void offerConfiguredPack(Player player) {
        String url = configuredUrl();
        String sha1 = configuredSha1();
        boolean force = plugin.getConfig().getBoolean("settings.resource-pack-force", false);
        String problem = ResourcePackPolicy.configurationProblem(url, sha1, force);
        if (problem != null) {
            if (!invalidConfigLogged) {
                plugin.getLogger().warning("Resource pack není odesílán: " + problem);
                invalidConfigLogged = true;
            }
            return;
        }
        if (url.isBlank() || player == null || !player.isOnline()) return; // Manual distribution remains supported.
        UUID requestId = ResourcePackPolicy.requestId(url, sha1);
        String promptText = plugin.getConfig().getString("settings.resource-pack-prompt",
                "WarriorLand: vlastní pixelové ikony pro menu příkazů.");
        String prompt = promptText == null || promptText.isBlank() ? null : safePrompt(promptText);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            // A config reload may occur during the two-second join delay. Never send a stale URL/hash or force mode.
            if (!player.isOnline() || !requestId.equals(configuredRequestId())
                    || force != plugin.getConfig().getBoolean("settings.resource-pack-force", false)) return;
            try {
                // Add, rather than replace, the pack so server packs from ItemsAdder or other plugins stay in the stack.
                // The request UUID lets this plugin ignore status events belonging to unrelated packs.
                player.addResourcePack(requestId, url, ResourcePackPolicy.decodeSha1(sha1), prompt, force);
            } catch (IllegalArgumentException | IllegalStateException exception) {
                plugin.getLogger().warning("Nelze odeslat resource pack hráči " + player.getName() + ": " + exception.getMessage());
                player.sendMessage(plugin.color("&cNepodařilo se nabídnout WarriorLand resource pack. Použij vanilla ikony nebo kontaktuj administrátora."));
            }
        }, 40L);
    }

    @EventHandler
    public void onResourcePackStatus(PlayerResourcePackStatusEvent event) {
        String url = configuredUrl();
        String sha1 = configuredSha1();
        if (!ResourcePackPolicy.shouldSend(url, sha1)) return;

        UUID expectedPackId = ResourcePackPolicy.requestId(url, sha1);
        // Paper 1.21.10 includes the pack UUID in the status event. Ignore status events
        // from server packs sent by other plugins or from an older URL/hash after reload.
        if (!expectedPackId.equals(event.getID())) return;

        UUID playerId = event.getPlayer().getUniqueId();
        switch (event.getStatus()) {
            case SUCCESSFULLY_LOADED -> {
                loadedPackIds.put(playerId, expectedPackId);
                if (plugin.getConfig().getBoolean("settings.use-resource-pack-icons", false)) {
                    event.getPlayer().sendMessage(plugin.color("&aWarriorLand resource pack byl načten. Vlastní ikony jsou aktivní."));
                }
                plugin.menus().refresh(event.getPlayer());
            }
            case DECLINED, DISCARDED, FAILED_DOWNLOAD, FAILED_RELOAD, INVALID_URL -> {
                loadedPackIds.remove(playerId, expectedPackId);
                if (plugin.getConfig().getBoolean("settings.use-resource-pack-icons", false)) {
                    event.getPlayer().sendMessage(plugin.color("&eWarriorLand resource pack není načten; menu použije běžné Minecraft ikony."));
                }
                plugin.menus().refresh(event.getPlayer());
            }
            default -> { /* ACCEPTED/DOWNLOADED are transient states; keep the current fallback. */ }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        loadedPackIds.remove(event.getPlayer().getUniqueId());
    }

    public void forget(UUID playerId) {
        if (playerId != null) loadedPackIds.remove(playerId);
    }

    /** If URL is blank, manual pack distribution is allowed only when force mode is off. */
    public boolean canUseCustomIcons(Player player) {
        if (player == null) return false;
        boolean enabled = plugin.getConfig().getBoolean("settings.use-resource-pack-icons", false);
        String url = configuredUrl();
        String sha1 = configuredSha1();
        boolean force = plugin.getConfig().getBoolean("settings.resource-pack-force", false);
        boolean validConfiguration = ResourcePackPolicy.configurationProblem(url, sha1, force) == null;
        boolean loadedCurrentPack = false;
        if (validConfiguration && !url.isBlank()) {
            UUID expectedPackId = ResourcePackPolicy.requestId(url, sha1);
            loadedCurrentPack = expectedPackId.equals(loadedPackIds.get(player.getUniqueId()));
        }
        // Without automatic delivery there is no trustworthy signal that a manually installed pack
        // is active. The explicit override is intentionally named "unverified" and defaults false.
        boolean allowManual = plugin.getConfig().getBoolean("settings.allow-unverified-manual-resource-pack-icons", false);
        return ResourcePackIconPolicy.canUseCustomIcons(enabled, validConfiguration, url, allowManual, loadedCurrentPack);
    }

    /** Drop success markers from a previous resource-pack URL/hash after an admin reload. */
    public void onConfigurationReloaded() {
        invalidConfigLogged = false;
        UUID previousRequestId = activeRequestId;
        boolean previousForce = activeForce;
        UUID nextRequestId = configuredRequestId();
        boolean nextForce = plugin.getConfig().getBoolean("settings.resource-pack-force", false);
        boolean packIdentityChanged = ResourcePackReloadPolicy.identityChanged(previousRequestId, nextRequestId);
        boolean forceModeChanged = previousForce != nextForce;
        activeRequestId = nextRequestId;
        activeForce = nextForce;

        if (ResourcePackReloadPolicy.shouldRemovePrevious(previousRequestId, nextRequestId)) {
            // Remove only our own stale pack. Never clear all server packs: ItemsAdder or another
            // plugin may have an unrelated pack loaded at the same time.
            for (Player online : plugin.getServer().getOnlinePlayers()) {
                try {
                    online.removeResourcePack(previousRequestId);
                } catch (IllegalArgumentException | IllegalStateException exception) {
                    plugin.getLogger().warning("Nelze odebrat starou verzi WarriorLand resource packu hráči "
                            + online.getName() + ": " + exception.getMessage());
                }
            }
            loadedPackIds.clear();
        } else if (ResourcePackReloadPolicy.shouldClearLoadedState(nextRequestId)) {
            loadedPackIds.clear();
        } else {
            loadedPackIds.values().removeIf(packId -> !nextRequestId.equals(packId));
        }

        String problem = ResourcePackPolicy.configurationProblem(configuredUrl(), configuredSha1(), nextForce);
        if (problem != null) {
            if (!invalidConfigLogged) {
                plugin.getLogger().warning("Resource pack není odesílán po reloadu: " + problem);
                invalidConfigLogged = true;
            }
            return;
        }
        // If the URL/hash changed, offer the new pack to everyone. If force mode toggled, re-offer
        // only to players who have not successfully loaded this pack so a decline can be enforced.
        if (ResourcePackReloadPolicy.shouldOfferAfterReload(nextRequestId, previousRequestId, forceModeChanged)) {
            for (Player online : plugin.getServer().getOnlinePlayers()) {
                if (ResourcePackReloadPolicy.shouldOfferToPlayer(nextRequestId,
                        loadedPackIds.get(online.getUniqueId()), packIdentityChanged, forceModeChanged)) {
                    offerConfiguredPack(online);
                }
            }
        }
    }

    private UUID configuredRequestId() {
        String url = configuredUrl();
        String sha1 = configuredSha1();
        boolean force = plugin.getConfig().getBoolean("settings.resource-pack-force", false);
        return ResourcePackPolicy.configurationProblem(url, sha1, force) == null
                && ResourcePackPolicy.shouldSend(url, sha1)
                ? ResourcePackPolicy.requestId(url, sha1) : null;
    }

    public int loadedPlayerCount() {
        String url = configuredUrl();
        String sha1 = configuredSha1();
        if (!ResourcePackPolicy.shouldSend(url, sha1)) return 0;
        UUID expectedPackId = ResourcePackPolicy.requestId(url, sha1);
        return (int) loadedPackIds.values().stream().filter(expectedPackId::equals).count();
    }

    public boolean hasAutomaticDelivery() {
        return ResourcePackPolicy.shouldSend(configuredUrl(), configuredSha1());
    }

    private String configuredUrl() {
        String value = plugin.getConfig().getString("settings.resource-pack-url", "");
        return value == null ? "" : value.trim();
    }

    private String configuredSha1() {
        String value = plugin.getConfig().getString("settings.resource-pack-sha1", "");
        return value == null ? "" : value.trim();
    }

    private String safePrompt(String value) {
        String sanitized = value.replaceAll("[\\r\\n\\t§]", " ").replaceAll("\\s+", " ").trim();
        if (sanitized.length() > 180) return sanitized.substring(0, 180);
        return sanitized;
    }
}
