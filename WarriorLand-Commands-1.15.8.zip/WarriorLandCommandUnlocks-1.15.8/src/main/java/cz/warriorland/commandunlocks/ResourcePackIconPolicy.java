package cz.warriorland.commandunlocks;

/** Decides whether a player may see custom item models or must receive vanilla-safe icons. */
final class ResourcePackIconPolicy {
    private ResourcePackIconPolicy() { }

    static boolean canUseCustomIcons(boolean enabled, boolean configurationValid, String url,
                                     boolean allowUnverifiedManualPack, boolean verifiedAutomaticLoad) {
        if (!enabled || !configurationValid) return false;
        if (url == null || url.isBlank()) return allowUnverifiedManualPack;
        return verifiedAutomaticLoad;
    }
}
