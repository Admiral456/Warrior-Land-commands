package cz.warriorland.commandunlocks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.ToIntFunction;

/** Pure server-side catalog filter/sort policy; no displayed text is trusted as purchase data. */
final class CatalogViewPolicy {
    private CatalogViewPolicy() { }

    static List<UnlockDefinition> apply(List<UnlockDefinition> source, String query, String sortMode,
                                        Function<String, String> categoryLabel,
                                        ToIntFunction<UnlockDefinition> availabilityRank) {
        List<UnlockDefinition> result = new ArrayList<>(source == null ? List.of() : source);
        String safeQuery = CommandSearchPolicy.sanitize(query);
        if (!safeQuery.isBlank()) {
            result.removeIf(definition -> !CommandSearchPolicy.matches(safeQuery,
                    definition.id(), definition.name(), definition.description(), definition.primaryCommand(),
                    String.join(" ", definition.commands()), definition.category(),
                    categoryLabel == null ? definition.category() : categoryLabel.apply(definition.category())));
        }

        String mode = CommandSearchPolicy.isValidSort(sortMode) ? sortMode : "default";
        Comparator<UnlockDefinition> comparator = switch (mode) {
            case "price-asc" -> Comparator.comparingInt(UnlockDefinition::cost).thenComparing(UnlockDefinition::id);
            case "price-desc" -> Comparator.comparingInt(UnlockDefinition::cost).reversed().thenComparing(UnlockDefinition::id);
            case "name" -> Comparator.comparing((UnlockDefinition definition) ->
                    CommandSearchPolicy.normalizeForSearch(definition.name())).thenComparing(UnlockDefinition::id);
            case "availability" -> Comparator.comparingInt((UnlockDefinition definition) ->
                    availabilityRank == null ? 3 : availabilityRank.applyAsInt(definition))
                    .thenComparingInt(UnlockDefinition::cost).thenComparing(UnlockDefinition::id);
            default -> null;
        };
        if (comparator != null) result.sort(comparator);
        return List.copyOf(result);
    }
}
