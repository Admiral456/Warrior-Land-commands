package cz.warriorland.commandunlocks;

import java.util.List;
import java.util.Locale;

public record TaskDefinition(
        String id,
        String type,
        int amount,
        String description,
        List<String> materials,
        List<String> entities,
        List<String> jobs
) {
    public TaskDefinition {
        id = id == null ? "task" : id.toLowerCase(Locale.ROOT);
        type = type == null ? "BREAK_BLOCK" : type.toUpperCase(Locale.ROOT);
        amount = Math.max(1, amount);
        description = description == null || description.isBlank() ? id : description;
        materials = materials == null ? List.of() : materials.stream().map(s -> s.toUpperCase(Locale.ROOT)).toList();
        entities = entities == null ? List.of() : entities.stream().map(s -> s.toUpperCase(Locale.ROOT)).toList();
        jobs = jobs == null ? List.of() : jobs.stream().map(s -> s.toUpperCase(Locale.ROOT)).toList();
    }
}
