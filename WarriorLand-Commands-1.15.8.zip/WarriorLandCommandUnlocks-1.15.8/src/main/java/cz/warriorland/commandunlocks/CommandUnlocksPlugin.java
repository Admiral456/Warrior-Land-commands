package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;

public final class CommandUnlocksPlugin extends JavaPlugin {
    private PlayerDataStore dataStore;
    private UnlockRegistry unlockRegistry;
    private PlayerPointsHook playerPoints;
    private LuckPermsHook luckPerms;
    private MenuManager menuManager;
    private HudNotifier hudNotifier;
    private TaskService taskService;
    private PurchaseService purchaseService;
    private VotingPluginHook votingPluginHook;
    private ItemsAdderHook itemsAdderHook;
    private ResourcePackListener resourcePackListener;
    private JobsPluginHook jobsPluginHook;
    private volatile boolean safeMode;
    private volatile boolean shuttingDown;
    private String safeModeReason = "";
    private boolean safeModeUsingBundledRules;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();
        migrateLegacyBlockedCommandMessage();
        migrateMissingDefaultUnlocks();
        validateResourcePackConfiguration();

        unlockRegistry = new UnlockRegistry(this);
        if (!loadInitialUnlockConfiguration()) {
            getLogger().severe("Ani zabudovanou bezpečnou konfiguraci nelze načíst. Plugin se vypíná.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Register the command gate before loading optional integrations or player data. If a required
        // data/API dependency is unavailable, the plugin can remain in fail-closed mode instead of
        // silently releasing every configured command when the plugin disables itself.
        if (!registerCommandAndGate()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (safeMode) {
            logSafeMode();
            return;
        }

        try {
            playerPoints = new PlayerPointsHook(this);
            luckPerms = new LuckPermsHook();
        } catch (Exception | LinkageError exception) {
            enterSafeMode("PlayerPoints nebo LuckPerms není dostupný: " + exception.getMessage());
            logSafeMode();
            return;
        }

        dataStore = new PlayerDataStore(this);
        try {
            dataStore.load();
        } catch (RuntimeException exception) {
            enterSafeMode("Databázi hráčů nelze bezpečně načíst: " + exception.getMessage());
            logSafeMode();
            return;
        }

        hudNotifier = new HudNotifier(this);
        hudNotifier.start();
        menuManager = new MenuManager(this);
        taskService = new TaskService(this);
        purchaseService = new PurchaseService(this);

        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new TaskProgressListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerQuitListener(this), this);
        resourcePackListener = new ResourcePackListener(this);
        getServer().getPluginManager().registerEvents(resourcePackListener, this);
        votingPluginHook = new VotingPluginHook(this);
        votingPluginHook.registerIfAvailable();
        itemsAdderHook = new ItemsAdderHook(this);
        itemsAdderHook.registerIfAvailable();
        jobsPluginHook = new JobsPluginHook(this);
        jobsPluginHook.registerIfAvailable();

        getLogger().info("WarriorLand Command Unlocks zapnut. Použij /prikazy.");
        getLogger().info("Saldo bodů poskytuje PlayerPoints, udělování oprávnění LuckPerms.");
        if (getServer().getPluginManager().getPlugin("ChatColor2") == null) {
            getLogger().warning("ChatColor2 není nalezen. Vlastní /chatcolour je registrován, ale barevný chat nebude fungovat, dokud nebude ChatColor2 nainstalován a zapnut.");
        }
        if (getServer().getPluginManager().getPlugin("Essentials") == null) {
            getLogger().warning("EssentialsX není nalezen. Vlastní /nickcolour vyžaduje EssentialsX pro bezpečné uložení barevné přezdívky.");
        }
    }

    /**
     * Existing installations keep their own config.yml when a JAR is updated. Migrate the old
     * built-in blocked-command text, but never overwrite a custom message chosen by the admin.
     */
    private void migrateLegacyBlockedCommandMessage() {
        // Do not use saveConfig() on an incompletely parsed config: Bukkit can expose a partial
        // configuration after a YAML parse error, and saving it here could overwrite the admin's
        // original file before loadInitialUnlockConfiguration enters safe mode.
        File configFile = new File(getDataFolder(), "config.yml");
        YamlConfiguration diskConfig = new YamlConfiguration();
        diskConfig.options().parseComments(true);
        try {
            diskConfig.load(configFile);
            var unlockSection = diskConfig.getConfigurationSection("unlocks");
            if (unlockSection == null || unlockSection.getKeys(false).isEmpty()) {
                getLogger().warning("Migrace hlášky zamčeného příkazu byla přeskočena: config.yml nemá neprázdnou sekci unlocks. Původní soubor zůstává zachován.");
                return;
            }

            String configured = diskConfig.getString("messages.blocked-command");
            String migrated = DefaultMessageMigration.migrateBlockedCommand(configured);
            if (migrated.equals(configured)) return;

            diskConfig.set("messages.blocked-command", migrated);
            Path target = configFile.toPath();
            Path temporary = target.resolveSibling("config.yml.migration.tmp");
            try {
                diskConfig.save(temporary.toFile());
                try {
                    Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
                    Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(temporary);
            }
            reloadConfig();
            getLogger().info("Výchozí hláška pro zamčený příkaz byla aktualizována; vlastní texty administrátora zůstávají zachované.");
        } catch (IOException | InvalidConfigurationException | RuntimeException exception) {
            getLogger().warning("Migrace hlášky zamčeného příkazu byla přeskočena, protože config.yml nelze bezpečně upravit: "
                    + exception.getMessage() + ". Původní soubor zůstává zachován.");
        }
    }

    /**
     * Merges newly shipped default unlock entries into older installations without replacing
     * existing player settings, costs, task progress, custom unlocks, or custom messages.
     */
    private void migrateMissingDefaultUnlocks() {
        File configFile = new File(getDataFolder(), "config.yml");
        YamlConfiguration diskConfig = new YamlConfiguration();
        diskConfig.options().parseComments(true);
        try (var reader = getTextResource("config.yml")) {
            if (reader == null) {
                getLogger().warning("Migrace nových příkazů byla přeskočena: zabudovaná výchozí konfigurace chybí.");
                return;
            }
            diskConfig.load(configFile);
            var currentUnlocks = diskConfig.getConfigurationSection("unlocks");
            if (currentUnlocks == null || currentUnlocks.getKeys(false).isEmpty()) {
                getLogger().warning("Migrace nových příkazů byla přeskočena: uživatelský config.yml nemá platnou sekci unlocks.");
                return;
            }
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(reader);
            var defaultUnlocks = defaults.getConfigurationSection("unlocks");
            if (defaultUnlocks == null || defaultUnlocks.getKeys(false).isEmpty()) {
                getLogger().warning("Migrace nových příkazů byla přeskočena: zabudovaná sekce unlocks je prázdná.");
                return;
            }

            boolean changed = false;
            int added = 0;

            // Add new presentation/HUD flags to old configs only when absent. An administrator's
            // explicit choice is never overwritten during a plugin upgrade.
            for (String settingPath : java.util.List.of(
                    "settings.use-resource-pack-icons",
                    "settings.allow-unverified-manual-resource-pack-icons",
                    "settings.hud-status-bar",
                    "settings.hud-notifications",
                    "settings.hud-notification-sounds",
                    "settings.hud-particles",
                    "settings.hud-task-progress",
                    "settings.itemsadder-textured-gui",
                    "settings.itemsadder-font-image",
                    "settings.itemsadder-title-offset",
                    "settings.itemsadder-texture-offset",
                    "settings.resource-pack-url",
                    "settings.resource-pack-sha1",
                    "settings.resource-pack-prompt",
                    "settings.resource-pack-force")) {
                if (!diskConfig.contains(settingPath) && defaults.contains(settingPath)) {
                    diskConfig.set(settingPath, defaults.get(settingPath));
                    changed = true;
                }
            }

            // New search/sort messages are merged field-by-field so upgrades preserve custom wording.
            for (String messageKey : java.util.List.of(
                    "search-applied", "search-cleared", "search-cancelled", "search-timeout", "sort-applied", "sort-usage", "command-provider-missing")) {
                String messagePath = "messages." + messageKey;
                if (!diskConfig.contains(messagePath) && defaults.contains(messagePath)) {
                    diskConfig.set(messagePath, defaults.get(messagePath));
                    changed = true;
                }
            }

            for (String id : defaultUnlocks.getKeys(false)) {
                if (diskConfig.contains("unlocks." + id)) continue;
                diskConfig.set("unlocks." + id, toPlainMap(defaultUnlocks.getConfigurationSection(id)));
                added++;
                changed = true;
            }

            // Safe field-level migration: do not overwrite a server owner's explicit value, price,
            // permissions or task definitions; add only prerequisite metadata introduced by this release.
            for (String id : java.util.List.of("chatcolour", "nickcolour")) {
                String itemPath = "unlocks." + id;
                String requiredPath = itemPath + ".required-plugins";
                var defaultSection = defaults.getConfigurationSection(itemPath);
                if (diskConfig.isConfigurationSection(itemPath) && !diskConfig.contains(requiredPath)
                        && defaultSection != null) {
                    java.util.List<String> defaultRequirements = defaultSection.getStringList("required-plugins");
                    if (!defaultRequirements.isEmpty()) {
                        diskConfig.set(requiredPath, defaultRequirements);
                        changed = true;
                    }
                }
            }

            var currentCategories = diskConfig.getConfigurationSection("categories");
            if (currentCategories != null && !diskConfig.isConfigurationSection("categories.residence")) {
                int targetSlot = -1;
                if (diskConfig.isConfigurationSection("categories.homes")) {
                    targetSlot = diskConfig.getInt("categories.homes.slot", 18);
                    var existing = diskConfig.getConfigurationSection("unlocks");
                    if (existing != null) {
                        for (String id : existing.getKeys(false)) {
                            String path = "unlocks." + id + ".category";
                            if ("homes".equalsIgnoreCase(diskConfig.getString(path, ""))) {
                                diskConfig.set(path, "teleport");
                            }
                        }
                    }
                    diskConfig.set("categories.homes", null);
                    changed = true;
                } else {
                    for (int candidate : new int[]{0, 9, 18, 27, 36}) {
                        boolean occupied = currentCategories.getKeys(false).stream()
                                .anyMatch(id -> diskConfig.getInt("categories." + id + ".slot", -1) == candidate);
                        if (!occupied) { targetSlot = candidate; break; }
                    }
                }
                if (targetSlot >= 0) {
                    var defaultCategory = defaults.getConfigurationSection("categories.residence");
                    if (defaultCategory != null) {
                        Map<String, Object> values = toPlainMap(defaultCategory);
                        values.put("slot", targetSlot);
                        diskConfig.set("categories.residence", values);
                        changed = true;
                    }
                } else {
                    getLogger().warning("Nebylo volné místo v levém menu pro kategorii Residence. Příkazy zůstávají dostupné v kategorii Všechny příkazy.");
                }
            }

            if (!changed) return;
            Path target = configFile.toPath();
            Path temporary = target.resolveSibling("config.yml.defaults-migration.tmp");
            try {
                diskConfig.save(temporary.toFile());
                try {
                    Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
                    Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(temporary);
            }
            reloadConfig();
            getLogger().info("Migrace konfigurace dokončena: přidáno " + added
                    + " chybějících výchozích odemčení. Existující položky a jejich ceny nebyly přepsány.");
        } catch (IOException | InvalidConfigurationException | RuntimeException exception) {
            getLogger().warning("Migrace chybějících výchozích příkazů nebyla bezpečně dokončena; původní konfigurace zůstala zachována: "
                    + exception.getMessage());
        }
    }

    private Map<String, Object> toPlainMap(org.bukkit.configuration.ConfigurationSection section) {
        Map<String, Object> values = new java.util.LinkedHashMap<>();
        if (section == null) return values;
        for (String key : section.getKeys(false)) {
            var nested = section.getConfigurationSection(key);
            if (nested != null) values.put(key, toPlainMap(nested));
            else values.put(key, section.get(key));
        }
        return values;
    }

    private void validateResourcePackConfiguration() {
        String url = getConfig().getString("settings.resource-pack-url", "");
        String sha1 = getConfig().getString("settings.resource-pack-sha1", "");
        boolean force = getConfig().getBoolean("settings.resource-pack-force", false);
        String problem = ResourcePackPolicy.configurationProblem(url, sha1, force);
        if (problem != null) {
            getLogger().warning("Resource pack nebude odesílán: " + problem);
        }
        if (getConfig().getBoolean("settings.use-resource-pack-icons", false)
                && (url == null || url.isBlank())) {
            getLogger().warning("Vlastní item-model ikony jsou povolené, ale resource-pack-url je prázdná. Z bezpečnostních důvodů zůstávají vanilla ikony aktivní, pokud explicitně nezapneš settings.allow-unverified-manual-resource-pack-icons; bez automatické nabídky nelze načtení packu spolehlivě ověřit.");
        }
    }

    private boolean loadInitialUnlockConfiguration() {
        try {
            if (unlockRegistry.reload(loadRawConfig())) return true;
            enterSafeMode("config.yml neobsahuje platná pravidla odemykání");
        } catch (IOException | InvalidConfigurationException | RuntimeException exception) {
            enterSafeMode("config.yml nelze bezpečně načíst: " + exception.getMessage());
        }

        // A malformed user file must not disable the command gate. Load the packaged defaults only
        // for emergency locking; normal features stay disabled until the administrator repairs config.yml.
        try (var reader = getTextResource("config.yml")) {
            if (reader != null && unlockRegistry.reload(YamlConfiguration.loadConfiguration(reader))) {
                safeModeUsingBundledRules = true;
                getLogger().severe("Používám zabudovaná výchozí pravidla pouze pro bezpečné zamknutí známých příkazů. Oprav config.yml a restartuj server.");
                return true;
            }
        } catch (IOException | RuntimeException exception) {
            getLogger().severe("Nepodařilo se načíst ani zabudovanou konfiguraci: " + exception.getMessage());
        }
        return false;
    }

    private boolean registerCommandAndGate() {
        PluginCommand command = getCommand("prikazy");
        if (command == null) {
            getLogger().severe("Příkaz 'prikazy' není definován v plugin.yml.");
            return false;
        }
        UnlockCommand executor = new UnlockCommand(this);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
        PluginCommand chatColour = getCommand("chatcolour");
        PluginCommand nickColour = getCommand("nickcolour");
        if (chatColour == null || nickColour == null) {
            getLogger().severe("V plugin.yml chybí deklarace příkazu chatcolour nebo nickcolour.");
            return false;
        }
        ChatColourCommand chatColourExecutor = new ChatColourCommand(this);
        chatColour.setExecutor(chatColourExecutor);
        chatColour.setTabCompleter(chatColourExecutor);
        NickColourCommand nickColourExecutor = new NickColourCommand(this);
        nickColour.setExecutor(nickColourExecutor);
        nickColour.setTabCompleter(nickColourExecutor);
        getServer().getPluginManager().registerEvents(new CommandGateListener(this), this);
        getServer().getPluginManager().registerEvents(new CommandAliasLifecycleListener(this), this);
        return true;
    }

    private void enterSafeMode(String reason) {
        safeMode = true;
        safeModeReason = reason == null || reason.isBlank() ? "neznámá chyba při inicializaci" : reason;
    }

    private void logSafeMode() {
        getLogger().severe("PLUGIN JE V BEZPEČNÉM REŽIMU: " + safeModeReason);
        getLogger().severe("Odemykací menu a nákupy jsou vypnuté. Oprav problém a restartuj server.");
        if (safeModeUsingBundledRules) {
            getLogger().severe("Příkazy uvedené v zabudované výchozí konfiguraci zůstávají zamčené (kromě bypass oprávnění). Vlastní aliasy z poškozeného config.yml nemusejí být rozpoznány.");
        } else {
            getLogger().severe("Příkazy z načtené konfigurace zůstávají zamčené (kromě bypass oprávnění).");
        }
    }

    @Override
    public void onDisable() {
        shuttingDown = true;
        if (hudNotifier != null) hudNotifier.shutdown();
        if (purchaseService != null) purchaseService.shutdown();
        if (dataStore != null && !safeMode && !dataStore.saveSync()) {
            getLogger().severe("Závěrečné uložení players.yml selhalo. Zkontroluj log a zálohu datového adresáře.");
        }
    }

    public boolean reloadPlugin() {
        if (purchaseService != null
                && (purchaseService.inProgressCount() > 0 || purchaseService.unresolvedPermissionCleanupCount() > 0)) {
            getLogger().warning("Reload konfigurace byl odmítnut, protože probíhá nákup nebo čeká kompenzace LuckPerms. Zkus to znovu, až /prikazy admin status ukáže nulové počty.");
            return false;
        }
        if (safeMode) {
            getLogger().warning("Reload není v bezpečném režimu povolen; oprav problém a restartuj server.");
            return false;
        }
        try {
            FileConfiguration candidate = loadRawConfig();
            if (!unlockRegistry.reload(candidate)) return false;
            // Only publish the new Bukkit config after the critical unlock rules validate.
            reloadConfig();
            if (resourcePackListener != null) resourcePackListener.onConfigurationReloaded();
            if (hudNotifier != null) hudNotifier.onConfigurationReloaded();
            validateResourcePackConfiguration();
        } catch (IOException | InvalidConfigurationException | RuntimeException exception) {
            getLogger().severe("Reload konfigurace selhal; předchozí pravidla a aktivní nastavení zůstávají zachována: " + exception.getMessage());
            return false;
        }
        menuManager.clearIconCache();
        if (votingPluginHook != null) votingPluginHook.registerIfAvailable();
        if (itemsAdderHook != null) itemsAdderHook.registerIfAvailable();
        if (jobsPluginHook != null) jobsPluginHook.registerIfAvailable();
        for (var player : Bukkit.getOnlinePlayers()) {
            dataStore.rememberPlayerName(player.getUniqueId(), player.getName());
            taskService.checkAllReady(player);
            menuManager.refresh(player);
        }
        return true;
    }

    private FileConfiguration loadRawConfig() throws IOException, InvalidConfigurationException {
        YamlConfiguration candidate = new YamlConfiguration();
        candidate.options().parseComments(true);
        candidate.load(new File(getDataFolder(), "config.yml"));
        return candidate;
    }

    public PlayerDataStore data() { return dataStore; }
    public UnlockRegistry unlocks() { return unlockRegistry; }
    public PlayerPointsHook points() { return playerPoints; }
    public LuckPermsHook luckPerms() { return luckPerms; }
    public MenuManager menus() { return menuManager; }
    public HudNotifier hud() { return hudNotifier; }
    public TaskService tasks() { return taskService; }
    public PurchaseService purchases() { return purchaseService; }
    public boolean isSafeMode() { return safeMode; }
    public boolean isShuttingDown() { return shuttingDown; }
    public String safeModeReason() { return safeModeReason; }
    public boolean isSafeModeUsingBundledRules() { return safeModeUsingBundledRules; }
    public VotingPluginHook votingPluginHook() { return votingPluginHook; }
    public ItemsAdderHook itemsAdderHook() { return itemsAdderHook; }
    public ResourcePackListener resourcePackListener() { return resourcePackListener; }
    public JobsPluginHook jobsPluginHook() { return jobsPluginHook; }

    /** Returns configured dependencies that are absent or disabled, matching Bukkit plugin names case-insensitively. */
    java.util.List<String> missingRequiredPlugins(UnlockDefinition definition) {
        if (definition == null || definition.requiredPlugins().isEmpty()) return java.util.List.of();
        java.util.List<String> enabledNames = java.util.Arrays.stream(getServer().getPluginManager().getPlugins())
                .filter(org.bukkit.plugin.Plugin::isEnabled)
                .map(org.bukkit.plugin.Plugin::getName)
                .toList();
        return RequiredPluginPolicy.missing(definition.requiredPlugins(), enabledNames);
    }

    public void sendSafeModeMessage(CommandSender sender) {
        sender.sendMessage(color("&8[&5WarriorLand&8] &cOdemykací systém je v bezpečném režimu. Příkazy zůstávají zamčené kvůli ochraně hráčských dat. Kontaktuj administrátora."));
    }

    public String getAdminPermission() {
        return UnlockConfigurationRules.permissionSettingOrDefault(
                getConfig().get("settings.admin-permission"), "warriorland.unlocks.admin");
    }

    public String getBypassPermission() {
        return UnlockConfigurationRules.permissionSettingOrDefault(
                getConfig().get("settings.bypass-permission"), "warriorland.unlocks.bypass");
    }

    public void sendMessage(CommandSender sender, String key, String... replacements) {
        String prefix = getConfig().getString("messages.prefix", "&8[&5WarriorLand&8] &r");
        String message = getConfig().getString("messages." + key, "&cChybí zpráva: " + key);
        for (int i = 0; i + 1 < replacements.length; i += 2) message = message.replace(replacements[i], replacements[i + 1]);
        sender.sendMessage(color(prefix + message));
    }

    public String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }
}
