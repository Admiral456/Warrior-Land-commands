package cz.warriorland.commandunlocks;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.ArrayList;
import java.util.List;

public final class PlayerJoinListener implements Listener {
    private final CommandUnlocksPlugin plugin;

    public PlayerJoinListener(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        var player = event.getPlayer();
        plugin.data().rememberPlayerName(player.getUniqueId(), player.getName());
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            List<String> permissions = new ArrayList<>();
            for (UnlockDefinition definition : plugin.unlocks().all()) {
                if (plugin.data().isUnlocked(player.getUniqueId(), definition.id())) permissions.addAll(definition.permissions());
            }
            plugin.luckPerms().grant(player.getUniqueId(), permissions).exceptionally(error -> {
                plugin.getLogger().warning("Nepodařilo se synchronizovat LuckPerms pro " + player.getName() + ": " + error.getMessage());
                return null;
            });
            plugin.tasks().checkAllReady(player);
            if (plugin.hud() != null) plugin.hud().refreshStatusBar(player);
        }, 20L);
    }
}
