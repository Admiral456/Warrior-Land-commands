package cz.warriorland.commandunlocks;

/** Fail-closed eligibility check for VotingPlugin's custom event flags. */
public final class VoteEligibility {
    private VoteEligibility() { }

    /**
     * A vote is countable only when the event explicitly confirms it was real and not cancelled.
     * Null values mean the optional event API did not provide the expected flag and are rejected.
     */
    public static boolean isCountable(Boolean realVote, Boolean cancelled) {
        return Boolean.TRUE.equals(realVote) && Boolean.FALSE.equals(cancelled);
    }
}
