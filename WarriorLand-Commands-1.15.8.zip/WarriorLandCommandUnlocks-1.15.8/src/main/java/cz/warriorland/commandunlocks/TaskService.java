package cz.warriorland.commandunlocks;

import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.UUID;

public final class TaskService {
    private final CommandUnlocksPlugin plugin;

    public TaskService(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean requirementsMet(UUID playerId, UnlockDefinition definition) {
        for (TaskDefinition task : definition.tasks()) {
            if (plugin.data().getTaskProgress(playerId, definition.id(), task.id()) < task.amount()) return false;
        }
        return true;
    }

    public void progress(Player player, String eventType, String targetType, int amount) {
        if (player == null) return;
        progress(player.getUniqueId(), player, eventType, targetType, amount);
    }

    /** Also supports events for known offline players, such as votes processed while they are offline. */
    public void progress(UUID playerId, Player onlinePlayer, String eventType, String targetType, int amount) {
        if (playerId == null || amount <= 0 || eventType == null) return;

        String normalizedType = eventType.toUpperCase(Locale.ROOT);
        String normalizedTarget = targetType == null ? "" : targetType.toUpperCase(Locale.ROOT);
        boolean changed = false;

        for (UnlockDefinition definition : plugin.unlocks().all()) {
            if (plugin.data().isUnlocked(playerId, definition.id())) continue;
            boolean itemChanged = false;
            for (TaskDefinition task : definition.tasks()) {
                if (!task.type().equals(normalizedType)) continue;
                if (!targetMatches(task, normalizedTarget)) continue;
                int old = plugin.data().getTaskProgress(playerId, definition.id(), task.id());
                if (old >= task.amount()) continue;
                int updated = plugin.data().addTaskProgress(playerId, definition.id(), task.id(), amount, task.amount());
                if (updated > old) {
                    itemChanged = true;
                    changed = true;
                    if (onlinePlayer != null && onlinePlayer.isOnline() && plugin.hud() != null) {
                        plugin.hud().taskProgress(onlinePlayer, task.description(), updated, task.amount());
                    }
                }
            }
            if (itemChanged) checkReady(playerId, onlinePlayer, definition);
        }

        if (changed) {
            plugin.data().saveAsyncSoon();
            if (onlinePlayer != null && onlinePlayer.isOnline()) plugin.menus().refresh(onlinePlayer);
        }
    }

    public void checkAllReady(Player player) {
        if (player == null) return;
        UUID playerId = player.getUniqueId();
        for (UnlockDefinition definition : plugin.unlocks().all()) {
            boolean unlocked = plugin.data().isUnlocked(playerId, definition.id());
            boolean rewardPaid = plugin.data().hasReceivedTaskReward(playerId, definition.id());
            boolean ready = requirementsMet(playerId, definition);
            if (TaskReadinessPolicy.shouldProcess(ready, unlocked, rewardPaid)) {
                checkReady(playerId, player, definition);
            }
        }
    }

    private boolean targetMatches(TaskDefinition task, String target) {
        if (!task.materials().isEmpty() && (task.type().equals("BREAK_BLOCK") || task.type().equals("CRAFT_ITEM") || task.type().equals("FISH_CAUGHT"))) {
            return task.materials().contains(target);
        }
        if (!task.entities().isEmpty() && task.type().equals("KILL_MOB")) {
            return task.entities().contains(target);
        }
        if (task.type().equals("JOBS_ACTION")) {
            return TaskTargetMatcher.matchesJob(task.jobs(), target);
        }
        return true;
    }

    private void checkReady(UUID playerId, Player onlinePlayer, UnlockDefinition definition) {
        boolean alreadyUnlocked = plugin.data().isUnlocked(playerId, definition.id());
        boolean rewardAlreadyPaid = plugin.data().hasReceivedTaskReward(playerId, definition.id());
        if (!TaskReadinessPolicy.shouldProcess(requirementsMet(playerId, definition), alreadyUnlocked, rewardAlreadyPaid)) return;

        boolean persistentChange = false;
        boolean currencyWasCredited = false;
        if (!plugin.data().hasReceivedTaskReward(playerId, definition.id())) {
            if (!definition.tasks().isEmpty() && definition.taskReward() > 0) {
                if (plugin.points().give(playerId, definition.taskReward())) {
                    plugin.data().recordTaskPoints(playerId, definition.taskReward());
                    plugin.data().markTaskRewardPaid(playerId, definition.id());
                    persistentChange = true;
                    currencyWasCredited = true;
                } else {
                    plugin.getLogger().warning("PlayerPoints odmítl odměnu za úkoly hráče " + playerId + " (" + definition.id() + "). Odměna se zkusí znovu při další kontrole.");
                }
            } else {
                plugin.data().markTaskRewardPaid(playerId, definition.id());
                persistentChange = true;
            }
        }

        // Do not mark an offline player's notification as sent; the join listener will deliver it later.
        boolean notifyPlayer = !alreadyUnlocked && onlinePlayer != null && onlinePlayer.isOnline()
                && !plugin.data().hasReadyNotification(playerId, definition.id());
        if (notifyPlayer) {
            plugin.data().markReadyNotification(playerId, definition.id());
            persistentChange = true;
        }

        if (persistentChange) {
            // Persist the one-time reward marker before confirming a currency payout to the player.
            if (currencyWasCredited) {
                if (!plugin.data().saveSync()) {
                    boolean refunded = plugin.points().take(playerId, definition.taskReward());
                    if (refunded) {
                        plugin.data().revertTaskReward(playerId, definition.id(), definition.taskReward());
                        plugin.getLogger().warning("Odměna " + definition.taskReward() + " PP za úkoly hráče " + playerId
                                + " ('" + definition.id() + "') byla vrácena, protože se nepodařilo uložit její jednorázový marker. Po opravě úložiště se odměna zkusí znovu.");
                        if (onlinePlayer != null && onlinePlayer.isOnline()) {
                            plugin.sendMessage(onlinePlayer, "task-reward-save-failed", "%amount%", String.valueOf(definition.taskReward()));
                        }
                    } else {
                        // The currency store refused compensation. Keep the paid marker in memory and
                        // schedule a retry to reduce the risk of paying twice after a restart.
                        plugin.data().saveAsyncSoon();
                        plugin.getLogger().severe("Nepodařilo se uložit marker ani vrátit odměnu " + definition.taskReward()
                                + " PP hráči " + playerId + " ('" + definition.id() + "'). Zůstatek a players.yml vyžadují ruční kontrolu.");
                        if (onlinePlayer != null && onlinePlayer.isOnline()) {
                            plugin.sendMessage(onlinePlayer, "task-reward", "%amount%", String.valueOf(definition.taskReward()), "%name%", definition.name());
                        }
                    }
                } else if (onlinePlayer != null && onlinePlayer.isOnline()) {
                    plugin.sendMessage(onlinePlayer, "task-reward", "%amount%", String.valueOf(definition.taskReward()), "%name%", definition.name());
                    if (plugin.hud() != null) plugin.hud().taskReward(onlinePlayer, definition.name(), definition.taskReward());
                }
            } else {
                plugin.data().saveAsyncSoon();
            }
        }

        if (notifyPlayer) {
            plugin.sendMessage(onlinePlayer, "ready-notification",
                    "%name%", definition.name(),
                    "%command%", "/" + definition.primaryCommand(),
                    "%id%", definition.id());
        }
    }
}
