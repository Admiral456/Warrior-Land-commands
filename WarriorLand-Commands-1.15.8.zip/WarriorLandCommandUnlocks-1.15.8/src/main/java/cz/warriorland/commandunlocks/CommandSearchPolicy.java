package cz.warriorland.commandunlocks;

import java.util.Locale;
import java.text.Normalizer;
import java.util.Set;

/** Small, deterministic input policy for server-side command catalog search/sort. */
public final class CommandSearchPolicy {
    public static final int MAX_QUERY_LENGTH = 48;
    private static final Set<String> SORT_MODES = Set.of("default", "price-asc", "price-desc", "name", "availability");

    private CommandSearchPolicy() { }

    public static String sanitize(String raw) {
        if (raw == null || raw.isBlank()) return "";
        String normalized = raw.replace('|', ' ').replaceAll("[\\p{Cntrl}]", " ")
                .trim().replaceAll("\\s+", " ");
        if (normalized.codePointCount(0, normalized.length()) > MAX_QUERY_LENGTH) {
            int end = normalized.offsetByCodePoints(0, MAX_QUERY_LENGTH);
            normalized = normalized.substring(0, end).trim();
        }
        return normalized;
    }

    public static boolean matches(String query, String... values) {
        String normalized = normalizeForSearch(sanitize(query));
        if (normalized.isEmpty()) return true;
        if (values == null) return false;
        for (String value : values) {
            if (value != null && normalizeForSearch(value).contains(normalized)) return true;
        }
        return false;
    }

    /** Czech and other Latin-language search should work with or without diacritics. */
    static String normalizeForSearch(String value) {
        if (value == null || value.isEmpty()) return "";
        String decomposed = Normalizer.normalize(value, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
    }

    public static boolean isValidSort(String value) {
        return value != null && SORT_MODES.contains(value);
    }

    public static String nextSortMode(String value) {
        return switch (value == null ? "default" : value.toLowerCase(Locale.ROOT)) {
            case "default" -> "availability";
            case "availability" -> "price-asc";
            case "price-asc" -> "price-desc";
            case "price-desc" -> "name";
            default -> "default";
        };
    }

    public static String label(String value) {
        return switch (value == null ? "default" : value.toLowerCase(Locale.ROOT)) {
            case "availability" -> "Dostupnost";
            case "price-asc" -> "Cena: nejnižší první";
            case "price-desc" -> "Cena: nejvyšší první";
            case "name" -> "Název A–Z";
            default -> "Výchozí pořadí";
        };
    }
}
