package cz.warriorland.commandunlocks;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

/**
 * Selects a compatible ItemsAdder TexturedInventoryWrapper constructor without a hard dependency
 * on ItemsAdder. Prefer the documented offset-aware API; fall back to older public signatures.
 */
final class ItemsAdderConstructorPolicy {
    enum Signature {
        TITLE_AND_TEXTURE_ARRAY_OFFSETS,
        TITLE_AND_SINGLE_TEXTURE_OFFSETS,
        LEGACY_TITLE_AND_TEXTURE,
        TEXTURE_AND_OFFSET
    }

    record Plan(Constructor<?> constructor, Signature signature) {
        Object[] arguments(Object holder, int size, String title, Object fontImage,
                           Class<?> fontImageType, int titleOffset, int textureOffset) {
            return switch (signature) {
                case TITLE_AND_TEXTURE_ARRAY_OFFSETS -> {
                    Object textures = Array.newInstance(fontImageType, 1);
                    Array.set(textures, 0, fontImage);
                    yield new Object[]{holder, size, title, titleOffset, textureOffset, textures};
                }
                case TITLE_AND_SINGLE_TEXTURE_OFFSETS ->
                        new Object[]{holder, size, title, fontImage, titleOffset, textureOffset};
                case LEGACY_TITLE_AND_TEXTURE -> new Object[]{holder, size, title, fontImage};
                case TEXTURE_AND_OFFSET -> new Object[]{holder, size, fontImage, textureOffset};
            };
        }

        Object create(Object holder, int size, String title, Object fontImage, Class<?> fontImageType,
                      int titleOffset, int textureOffset) throws ReflectiveOperationException {
            try {
                return constructor.newInstance(arguments(holder, size, title, fontImage,
                        fontImageType, titleOffset, textureOffset));
            } catch (InvocationTargetException exception) {
                Throwable cause = exception.getCause();
                if (cause instanceof ReflectiveOperationException reflective) throw reflective;
                if (cause instanceof RuntimeException runtime) throw runtime;
                if (cause instanceof Error error) throw error;
                throw new ReflectiveOperationException("ItemsAdder inventory wrapper constructor failed", cause);
            }
        }
    }

    private ItemsAdderConstructorPolicy() { }

    static Plan findBest(Class<?> wrapperType, Class<?> holderType, Class<?> fontImageType) {
        if (wrapperType == null || holderType == null || fontImageType == null) return null;
        Constructor<?>[] constructors = wrapperType.getConstructors();
        Signature[] preference = {
                Signature.TITLE_AND_TEXTURE_ARRAY_OFFSETS,
                Signature.TITLE_AND_SINGLE_TEXTURE_OFFSETS,
                Signature.LEGACY_TITLE_AND_TEXTURE,
                Signature.TEXTURE_AND_OFFSET
        };
        for (Signature signature : preference) {
            for (Constructor<?> constructor : constructors) {
                if (!Modifier.isPublic(constructor.getModifiers())) continue;
                if (matches(constructor.getParameterTypes(), signature, holderType, fontImageType)) {
                    return new Plan(constructor, signature);
                }
            }
        }
        return null;
    }

    private static boolean matches(Class<?>[] types, Signature signature, Class<?> holderType, Class<?> fontImageType) {
        if (types.length == 0 || !types[0].isAssignableFrom(holderType)) return false;
        return switch (signature) {
            case TITLE_AND_TEXTURE_ARRAY_OFFSETS -> types.length == 6
                    && isInt(types[1]) && types[2] == String.class && isInt(types[3]) && isInt(types[4])
                    && types[5].isArray() && types[5].getComponentType().isAssignableFrom(fontImageType);
            case TITLE_AND_SINGLE_TEXTURE_OFFSETS -> types.length == 6
                    && isInt(types[1]) && types[2] == String.class && types[3].isAssignableFrom(fontImageType)
                    && isInt(types[4]) && isInt(types[5]);
            case LEGACY_TITLE_AND_TEXTURE -> types.length == 4
                    && isInt(types[1]) && types[2] == String.class && types[3].isAssignableFrom(fontImageType);
            case TEXTURE_AND_OFFSET -> types.length == 4
                    && isInt(types[1]) && types[2].isAssignableFrom(fontImageType) && isInt(types[3]);
        };
    }

    private static boolean isInt(Class<?> type) {
        return type == int.class || type == Integer.class;
    }
}
