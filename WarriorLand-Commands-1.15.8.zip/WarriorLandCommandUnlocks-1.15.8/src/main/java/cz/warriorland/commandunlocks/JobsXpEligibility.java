package cz.warriorland.commandunlocks;

/** Pure fail-closed check for Jobs Reborn XP events. */
public final class JobsXpEligibility {
    private JobsXpEligibility() { }

    /** Only an explicitly non-cancelled event carrying finite, positive XP is countable. */
    public static boolean isCountable(Number experience, Boolean cancelled) {
        if (!Boolean.FALSE.equals(cancelled) || experience == null) return false;
        double amount = experience.doubleValue();
        return Double.isFinite(amount) && amount > 0.0D;
    }
}
