package cz.warriorland.commandunlocks;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** British-spelling entry point for the uploaded ChatColor2 plugin. */
public final class ChatColourCommand implements CommandExecutor, TabCompleter {
    private final CommandUnlocksPlugin plugin;

    public ChatColourCommand(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.sendMessage(sender, "only-player");
            return true;
        }
        Plugin chatColor = Bukkit.getPluginManager().getPlugin("ChatColor2");
        if (chatColor == null || !chatColor.isEnabled()) {
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cBarevný chat momentálně není dostupný. ChatColor2 není zapnutý; kontaktuj administrátora."));
            return true;
        }

        // With no arguments, open ChatColor2's supported GUI rather than merely printing the current color.
        String targetCommand = args.length == 0 ? "chatcolor gui" : "chatcolor " + String.join(" ", args);
        boolean dispatched;
        try {
            dispatched = Bukkit.dispatchCommand(player, targetCommand);
        } catch (RuntimeException exception) {
            plugin.getLogger().warning("Předání /chatcolour do ChatColor2 selhalo: " + exception.getMessage());
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cBarevný chat se nepodařilo otevřít. Zkus to později nebo kontaktuj administrátora."));
            return true;
        }
        if (!dispatched) {
            player.sendMessage(plugin.color("&8[&5WarriorLand&8] &cChatColor2 nepřijal příkaz. Zkus &e/chatcolour &cnebo kontaktuj administrátora."));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player)) return List.of();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return List.of("gui", "clear", "help", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f")
                    .stream().filter(value -> value.startsWith(prefix)).toList();
        }
        return new ArrayList<>();
    }
}
