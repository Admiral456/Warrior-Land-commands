package cz.warriorland.commandunlocks;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/** Flushes already-pending progress before a normal logout completes. */
public final class PlayerQuitListener implements Listener {
    private final CommandUnlocksPlugin plugin;

    public PlayerQuitListener(CommandUnlocksPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.data().flushPending();
        if (plugin.hud() != null) plugin.hud().forget(event.getPlayer().getUniqueId());
        if (plugin.resourcePackListener() != null) plugin.resourcePackListener().forget(event.getPlayer().getUniqueId());
        if (plugin.menus() != null) plugin.menus().forget(event.getPlayer().getUniqueId());
    }
}
