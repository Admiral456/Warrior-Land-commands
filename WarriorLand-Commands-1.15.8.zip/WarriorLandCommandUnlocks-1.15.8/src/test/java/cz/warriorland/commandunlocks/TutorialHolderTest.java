package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TutorialHolderTest {
    @Test void promptIsNotMistakenForPlayerOrAdminPage() {
        TutorialHolder holder = TutorialHolder.prompt();
        assertTrue(holder.isPrompt());
        assertFalse(holder.isAdminTutorial());
    }

    @Test void adminPagesAreTaggedSeparatelyFromPlayerTutorial() {
        TutorialHolder player = TutorialHolder.page(2);
        TutorialHolder admin = TutorialHolder.adminPage(1);
        assertFalse(player.isPrompt());
        assertFalse(player.isAdminTutorial());
        assertEquals(2, player.page());
        assertFalse(admin.isPrompt());
        assertTrue(admin.isAdminTutorial());
        assertEquals(1, admin.page());
        assertEquals(0, TutorialHolder.adminPage(-20).page());
    }
}
