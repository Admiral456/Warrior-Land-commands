package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class MenuQuickActionPolicyTest {
    @Test void visibleShortcutsAllMapToAnAction() {
        assertEquals(MenuQuickActionPolicy.Action.TUTORIAL, MenuQuickActionPolicy.actionFor(5));
        assertEquals(MenuQuickActionPolicy.Action.POINTS, MenuQuickActionPolicy.actionFor(6));
        assertEquals(MenuQuickActionPolicy.Action.TASKS, MenuQuickActionPolicy.actionFor(38));
        assertEquals(MenuQuickActionPolicy.Action.POINTS, MenuQuickActionPolicy.actionFor(39));
        assertEquals(MenuQuickActionPolicy.Action.STATUS_LEGEND, MenuQuickActionPolicy.actionFor(40));
        assertEquals(MenuQuickActionPolicy.Action.HUD_TOGGLE, MenuQuickActionPolicy.actionFor(41));
    }

    @Test void nonShortcutSlotsDoNotStealCategoryOrCardClicks() {
        assertEquals(MenuQuickActionPolicy.Action.NONE, MenuQuickActionPolicy.actionFor(0));
        assertEquals(MenuQuickActionPolicy.Action.NONE, MenuQuickActionPolicy.actionFor(11));
        assertEquals(MenuQuickActionPolicy.Action.NONE, MenuQuickActionPolicy.actionFor(43));
        assertEquals(MenuQuickActionPolicy.Action.NONE, MenuQuickActionPolicy.actionFor(50));
        assertEquals(MenuQuickActionPolicy.Action.NONE, MenuQuickActionPolicy.actionFor(-1));
        assertEquals(MenuQuickActionPolicy.Action.NONE, MenuQuickActionPolicy.actionFor(54));
    }
}
