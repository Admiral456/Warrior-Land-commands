package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RequiredPluginPolicyTest {
    @Test void noRequirementsMeansAvailable() {
        assertTrue(RequiredPluginPolicy.missing(List.of(), List.of()).isEmpty());
        assertTrue(RequiredPluginPolicy.missing(null, null).isEmpty());
    }

    @Test void pluginNamesAreCaseInsensitive() {
        assertTrue(RequiredPluginPolicy.missing(List.of("Essentials", "ChatColor2"), List.of("essentials", "CHATCOLOR2")).isEmpty());
    }

    @Test void absentOrDisabledPluginNameIsReportedAsMissing() {
        assertEquals(List.of("ChatColor2"), RequiredPluginPolicy.missing(List.of("ChatColor2"), List.of("Essentials")));
    }

    @Test void onlyRequiredNamesMissingFromEnabledSetAreReturnedWithoutDuplicates() {
        assertEquals(List.of("Essentials", "ChatColor2"), RequiredPluginPolicy.missing(
                List.of("Essentials", "ChatColor2", "Essentials"), List.of("PlayerPoints", "LuckPerms")));
    }
}
