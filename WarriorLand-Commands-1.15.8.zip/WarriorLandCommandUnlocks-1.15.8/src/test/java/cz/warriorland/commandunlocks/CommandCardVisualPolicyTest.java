package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CommandCardVisualPolicyTest {
    @Test void unlockedHasGreenVariant() {
        assertEquals("unlocked", CommandCardVisualPolicy.variant(true, false, true, true));
    }

    @Test void unavailableDependencyOutranksOwnershipAndReadiness() {
        assertEquals("unavailable", CommandCardVisualPolicy.variant(true, true, true, true));
        assertEquals("unavailable", CommandCardVisualPolicy.variant(false, true, true, true));
    }

    @Test void incompleteTasksUseLockedVariant() {
        assertEquals("locked", CommandCardVisualPolicy.variant(false, false, false, true));
    }

    @Test void completedRequirementsUseReadyOrInsufficientVariant() {
        assertEquals("ready", CommandCardVisualPolicy.variant(false, false, true, true));
        assertEquals("insufficient", CommandCardVisualPolicy.variant(false, false, true, false));
    }
}
