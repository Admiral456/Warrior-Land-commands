package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TaskTargetMatcherTest {
    @Test
    void matchesJobsRebornNamesWithoutCaseSensitivity() {
        assertTrue(TaskTargetMatcher.matchesJob(List.of("Miner"), "MINER"));
        assertTrue(TaskTargetMatcher.matchesJob(List.of("  woodcutter ", "Miner"), "WoodCutter"));
        assertFalse(TaskTargetMatcher.matchesJob(List.of("Miner"), "Farmer"));
    }

    @Test
    void malformedOrMissingJobNamesNeverMatch() {
        assertFalse(TaskTargetMatcher.matchesJob(null, "Miner"));
        assertFalse(TaskTargetMatcher.matchesJob(List.of("Miner"), null));
        assertFalse(TaskTargetMatcher.matchesJob(List.of("Miner"), "  "));
        assertFalse(TaskTargetMatcher.matchesJob(List.of("", "  "), "Miner"));
    }
}
