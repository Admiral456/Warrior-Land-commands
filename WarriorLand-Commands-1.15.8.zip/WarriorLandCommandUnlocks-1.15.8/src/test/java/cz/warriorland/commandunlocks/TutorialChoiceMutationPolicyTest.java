package cz.warriorland.commandunlocks;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TutorialChoiceMutationPolicyTest {
    private static final String PATH = "players.00000000-0000-0000-0000-000000000001.preferences.tutorial-enabled";

    @Test void keepsChoiceWhenDurableSaveSucceeds() {
        YamlConfiguration data = new YamlConfiguration();
        assertTrue(TutorialChoiceMutationPolicy.persistOrRestore(data, PATH, true, () -> true));
        assertEquals(Boolean.TRUE, data.get(PATH));
    }

    @Test void restoresPreviousChoiceAfterFailedSave() {
        YamlConfiguration data = new YamlConfiguration();
        data.set(PATH, false);
        assertFalse(TutorialChoiceMutationPolicy.persistOrRestore(data, PATH, true, () -> false));
        assertEquals(Boolean.FALSE, data.get(PATH));
    }

    @Test void restoresUnansweredStateAfterFailedReset() {
        YamlConfiguration data = new YamlConfiguration();
        assertNull(data.get(PATH));
        assertFalse(TutorialChoiceMutationPolicy.persistOrRestore(data, PATH, null, () -> false));
        assertNull(data.get(PATH));
    }

    @Test void restoresPreviousChoiceWhenSaveThrows() {
        YamlConfiguration data = new YamlConfiguration();
        data.set(PATH, false);
        assertThrows(IllegalStateException.class,
                () -> TutorialChoiceMutationPolicy.persistOrRestore(data, PATH, true,
                        () -> { throw new IllegalStateException("disk error"); }));
        assertEquals(Boolean.FALSE, data.get(PATH));
    }

    @Test void successfulResetRemovesPreviouslyStoredChoice() {
        YamlConfiguration data = new YamlConfiguration();
        data.set(PATH, true);
        assertTrue(TutorialChoiceMutationPolicy.persistOrRestore(data, PATH, null, () -> true));
        assertNull(data.get(PATH));
    }
}
