package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CommandAvailabilityPolicyTest {
    @Test void aRegisteredAliasMakesTheFunctionAvailable() {
        assertEquals(CommandAvailabilityPolicy.Status.REGISTERED,
                CommandAvailabilityPolicy.aggregate(List.of(CommandAvailabilityPolicy.Status.MISSING,
                        CommandAvailabilityPolicy.Status.REGISTERED)));
        assertFalse(CommandAvailabilityPolicy.blocksPurchase(CommandAvailabilityPolicy.Status.REGISTERED));
    }

    @Test void blocksOnlyWhenTheCommandMapConfirmsEveryConfiguredVariantIsMissing() {
        assertEquals(CommandAvailabilityPolicy.Status.MISSING,
                CommandAvailabilityPolicy.aggregate(List.of(CommandAvailabilityPolicy.Status.MISSING,
                        CommandAvailabilityPolicy.Status.MISSING)));
        assertTrue(CommandAvailabilityPolicy.blocksPurchase(CommandAvailabilityPolicy.Status.MISSING));
        assertEquals(CommandAvailabilityPolicy.Status.UNKNOWN,
                CommandAvailabilityPolicy.aggregate(List.of(CommandAvailabilityPolicy.Status.MISSING,
                        CommandAvailabilityPolicy.Status.UNKNOWN)));
        assertFalse(CommandAvailabilityPolicy.blocksPurchase(CommandAvailabilityPolicy.Status.UNKNOWN));
        assertFalse(CommandAvailabilityPolicy.blocksPurchase(null));
    }

    @Test void registeredCommandsRankAheadOfUnverifiedAndMissingCommands() {
        assertTrue(CommandAvailabilityPolicy.availabilityRank(CommandAvailabilityPolicy.Status.REGISTERED)
                < CommandAvailabilityPolicy.availabilityRank(CommandAvailabilityPolicy.Status.UNKNOWN));
        assertTrue(CommandAvailabilityPolicy.availabilityRank(CommandAvailabilityPolicy.Status.UNKNOWN)
                < CommandAvailabilityPolicy.availabilityRank(CommandAvailabilityPolicy.Status.MISSING));
    }
}
