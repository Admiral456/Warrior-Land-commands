package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HudProgressPolicyTest {
    @Test void firstProgressEventCanNotifyButBurstsAreRateLimited() {
        long cooldown = 1_000_000_000L;
        assertTrue(HudProgressPolicy.shouldNotify(null, 100L, cooldown));
        assertFalse(HudProgressPolicy.shouldNotify(100L, 100L + cooldown - 1, cooldown));
        assertTrue(HudProgressPolicy.shouldNotify(100L, 100L + cooldown, cooldown));
    }

    @Test void progressBarUsesSafeBounds() {
        assertEquals(0, HudProgressPolicy.filledSegments(-1, 10, 8));
        assertEquals(0, HudProgressPolicy.filledSegments(5, 0, 8));
        assertEquals(4, HudProgressPolicy.filledSegments(5, 10, 8));
        assertEquals(8, HudProgressPolicy.filledSegments(10, 10, 8));
        assertEquals(8, HudProgressPolicy.filledSegments(Integer.MAX_VALUE, Integer.MAX_VALUE, 8));
        assertEquals(0, HudProgressPolicy.filledSegments(5, 10, -2));
        assertEquals(20, HudProgressPolicy.filledSegments(5, 10, 99));
    }
}
