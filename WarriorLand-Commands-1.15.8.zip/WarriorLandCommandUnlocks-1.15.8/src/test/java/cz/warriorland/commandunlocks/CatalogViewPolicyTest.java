package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CatalogViewPolicyTest {
    private static UnlockDefinition entry(String id, String name, String description, int cost, String... commands) {
        return new UnlockDefinition(id, name, description, "utility", "PAPER", cost, 0,
                List.of(commands), List.of("test." + id), List.of(), List.of());
    }

    private static List<UnlockDefinition> sample() {
        return List.of(
                entry("nick", "Přezdívka", "Změní vzhled jména", 95, "nick", "nickname"),
                entry("chatcolour", "Barva chatu", "Změní barvu zpráv", 110, "chatcolour", "chatcolor"),
                entry("home", "Domov", "Teleportace domů", 50, "home"));
    }

    @Test void searchIncludesNameDescriptionPrimaryCommandAndAliasWithoutCzechDiacritics() {
        assertEquals(List.of("chatcolour"), CatalogViewPolicy.apply(sample(), "barva", "default", null, null)
                .stream().map(UnlockDefinition::id).toList());
        assertEquals(List.of("chatcolour"), CatalogViewPolicy.apply(sample(), "CHATCOLOR", "default", null, null)
                .stream().map(UnlockDefinition::id).toList());
        assertEquals(List.of("home"), CatalogViewPolicy.apply(sample(), "teleportace", "default", null, null)
                .stream().map(UnlockDefinition::id).toList());
        assertEquals(List.of("nick"), CatalogViewPolicy.apply(sample(), "prezdivka", "default", null, null)
                .stream().map(UnlockDefinition::id).toList());
    }

    @Test void sortingUsesPriceNameAndCallerSuppliedAvailabilityRank() {
        assertEquals(List.of("home", "nick", "chatcolour"), CatalogViewPolicy.apply(sample(), "", "price-asc", null, null)
                .stream().map(UnlockDefinition::id).toList());
        assertEquals(List.of("chatcolour", "nick", "home"), CatalogViewPolicy.apply(sample(), "", "price-desc", null, null)
                .stream().map(UnlockDefinition::id).toList());
        assertEquals(List.of("home", "chatcolour", "nick"), CatalogViewPolicy.apply(sample(), "", "availability", null,
                definition -> definition.id().equals("chatcolour") ? 0 : 1).stream().map(UnlockDefinition::id).toList());
    }

    @Test void defaultOrderIsPreservedAndSourceIsNotMutated() {
        List<UnlockDefinition> source = sample();
        var result = CatalogViewPolicy.apply(source, "", "default", null, null);
        assertEquals(List.of("nick", "chatcolour", "home"), result.stream().map(UnlockDefinition::id).toList());
        assertEquals("nick", source.getFirst().id());
        assertNotSame(source, result);
    }
}
