package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PointsMutationPolicyTest {
    @Test
    void supportsOnlyExplicitlyHandledMutationContracts() {
        assertTrue(PointsMutationPolicy.supportsReturnType(void.class));
        assertTrue(PointsMutationPolicy.supportsReturnType(boolean.class));
        assertTrue(PointsMutationPolicy.supportsReturnType(Boolean.class));
        assertFalse(PointsMutationPolicy.supportsReturnType(int.class));
        assertFalse(PointsMutationPolicy.supportsReturnType(String.class));
    }

    @Test
    void neverTreatsUnknownOrNullMutationResultAsSuccess() {
        assertTrue(PointsMutationPolicy.succeeded(void.class, null));
        assertTrue(PointsMutationPolicy.succeeded(boolean.class, Boolean.TRUE));
        assertTrue(PointsMutationPolicy.succeeded(Boolean.class, Boolean.TRUE));
        assertFalse(PointsMutationPolicy.succeeded(boolean.class, Boolean.FALSE));
        assertFalse(PointsMutationPolicy.succeeded(Boolean.class, null));
        assertFalse(PointsMutationPolicy.succeeded(String.class, "ok"));
    }
}
