package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MenuLayoutTest {
    @Test
    void allSectionsFitThe54SlotInventoryWithoutOverlaps() {
        assertTrue(MenuLayout.hasValidLayout());
        assertEquals(54, MenuLayout.INVENTORY_SIZE);
        assertEquals(12, MenuLayout.cardSlots().length);
        assertEquals(4, MenuLayout.quickInfoSlots().length);
        Set<Integer> all = new HashSet<>();
        for (int[] section : new int[][]{
                MenuLayout.categorySlots(), MenuLayout.headerSlots(), MenuLayout.separatorSlots(), MenuLayout.cardSlots(),
                MenuLayout.quickInfoSlots(), MenuLayout.detailSlots(), MenuLayout.footerSlots()
        }) {
            assertTrue(Arrays.stream(section).allMatch(slot -> slot >= 0 && slot < 54));
            for (int slot : section) assertTrue(all.add(slot), "Slot " + slot + " overlaps another section");
        }
        assertEquals(54, all.size());
    }

    @Test
    void sidebarIsExactlyTheFiveReservedCategorySlots() {
        for (int slot : new int[]{0, 9, 18, 27, 36}) assertTrue(MenuLayout.isSidebarCategorySlot(slot));
        for (int slot : new int[]{1, 8, 10, 11, 45, 53, -1, 54}) assertFalse(MenuLayout.isSidebarCategorySlot(slot));
    }

    @Test
    void slotArraysAreDefensiveCopies() {
        int[] cards = MenuLayout.cardSlots();
        cards[0] = 53;
        assertEquals(11, MenuLayout.cardSlots()[0]);
    }
}
