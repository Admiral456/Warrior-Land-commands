package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PointsCreditPolicyTest {
    @Test
    void allowsCreditsThatStayWithinIntRange() {
        assertTrue(PointsCreditPolicy.canCredit(0, 0));
        assertTrue(PointsCreditPolicy.canCredit(50, 25));
        assertTrue(PointsCreditPolicy.canCredit(Integer.MAX_VALUE - 1, 1));
        assertTrue(PointsCreditPolicy.canCredit(Integer.MAX_VALUE, 0));
    }

    @Test
    void rejectsNegativeValuesAndOverflow() {
        assertFalse(PointsCreditPolicy.canCredit(-1, 1));
        assertFalse(PointsCreditPolicy.canCredit(1, -1));
        assertFalse(PointsCreditPolicy.canCredit(Integer.MAX_VALUE, 1));
        assertFalse(PointsCreditPolicy.canCredit(Integer.MAX_VALUE - 5, 6));
    }
}
