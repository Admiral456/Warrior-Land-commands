package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HudStatusPolicyTest {
    @Test void nullPreferenceUsesServerDefault() {
        assertTrue(HudStatusPolicy.isEnabled(null, true));
        assertFalse(HudStatusPolicy.isEnabled(null, false));
    }

    @Test void explicitPlayerChoiceOverridesServerDefault() {
        assertTrue(HudStatusPolicy.isEnabled(true, false));
        assertFalse(HudStatusPolicy.isEnabled(false, true));
    }

    @Test void titleShowsPointsUnlocksAndCompletedTasksWithoutUnsafeCounts() {
        String title = HudStatusPolicy.title(250, 28, 75, 42, 120);
        assertTrue(title.contains("250 PP"));
        assertTrue(title.contains("Příkazy 28/75"));
        assertTrue(title.contains("Úkoly 42/120"));
        assertTrue(HudStatusPolicy.title(-5, 99, 75, 500, 120).contains("0 PP"));
        assertTrue(HudStatusPolicy.title(-5, 99, 75, 500, 120).contains("Příkazy 75/75"));
        assertTrue(HudStatusPolicy.title(-5, 99, 75, 500, 120).contains("Úkoly 120/120"));
    }

    @Test void progressIsClampedAndSafeForEmptyCatalog() {
        assertEquals(0.0d, HudStatusPolicy.progress(0, 0));
        assertEquals(0.0d, HudStatusPolicy.progress(-5, 75));
        assertEquals(0.5d, HudStatusPolicy.progress(38, 76), 1e-9);
        assertEquals(1.0d, HudStatusPolicy.progress(100, 75));
    }

    @Test void taskCompletionRequiresPositiveTarget() {
        assertTrue(HudStatusPolicy.isTaskComplete(5, 5));
        assertFalse(HudStatusPolicy.isTaskComplete(4, 5));
        assertFalse(HudStatusPolicy.isTaskComplete(10, 0));
        assertFalse(HudStatusPolicy.isTaskComplete(0, -1));
    }

    @Test void onlyPositiveCompletedTaskTargetsCount() {
        assertEquals(2, HudStatusPolicy.completedTasks(
                new int[]{5, 9, 0, 10}, new int[]{5, 10, 0, 8}));
    }

    @Test void nullAndMismatchedTaskArraysAreSafe() {
        assertEquals(0, HudStatusPolicy.completedTasks(null, new int[]{5}));
        assertEquals(1, HudStatusPolicy.completedTasks(new int[]{5, 8}, new int[]{5}));
    }
}
