package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SaveRetryPolicyTest {
    @Test
    void backsOffForRepeatedFailuresAndCapsAtOneMinute() {
        assertEquals(20L, SaveRetryPolicy.delayTicks(1));
        assertEquals(40L, SaveRetryPolicy.delayTicks(2));
        assertEquals(80L, SaveRetryPolicy.delayTicks(3));
        assertEquals(640L, SaveRetryPolicy.delayTicks(6));
        assertEquals(1200L, SaveRetryPolicy.delayTicks(7));
        assertEquals(1200L, SaveRetryPolicy.delayTicks(100));
        assertEquals(20L, SaveRetryPolicy.delayTicks(0));
    }
}
