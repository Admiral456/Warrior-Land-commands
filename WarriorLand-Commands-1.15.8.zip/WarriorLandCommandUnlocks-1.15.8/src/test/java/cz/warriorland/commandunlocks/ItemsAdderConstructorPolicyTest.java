package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Array;

import static org.junit.jupiter.api.Assertions.*;

class ItemsAdderConstructorPolicyTest {
    interface Holder { }
    static final class Menu implements Holder { }
    static final class FontImage { }

    public static final class ModernArrayWrapper {
        final Object[] captured;
        public ModernArrayWrapper(Holder holder, int size, String title, int titleOffset,
                                  int textureOffset, FontImage... images) {
            captured = new Object[]{holder, size, title, titleOffset, textureOffset, images};
        }
    }

    public static final class ModernSingleWrapper {
        final Object[] captured;
        public ModernSingleWrapper(Holder holder, int size, String title, FontImage image,
                                   int titleOffset, int textureOffset) {
            captured = new Object[]{holder, size, title, image, titleOffset, textureOffset};
        }
    }

    public static final class LegacyWrapper {
        final Object[] captured;
        public LegacyWrapper(Holder holder, int size, String title, FontImage image) {
            captured = new Object[]{holder, size, title, image};
        }
    }

    public static final class TextureOffsetWrapper {
        final Object[] captured;
        public TextureOffsetWrapper(Holder holder, int size, FontImage image, int textureOffset) {
            captured = new Object[]{holder, size, image, textureOffset};
        }
    }

    public static final class IncompatibleWrapper {
        public IncompatibleWrapper(String unrelated) { }
    }

    @Test
    void prefersModernVarargsConstructorAndPassesOffsets() throws Exception {
        Menu holder = new Menu();
        FontImage image = new FontImage();
        var plan = ItemsAdderConstructorPolicy.findBest(ModernArrayWrapper.class, Menu.class, FontImage.class);
        assertNotNull(plan);
        assertEquals(ItemsAdderConstructorPolicy.Signature.TITLE_AND_TEXTURE_ARRAY_OFFSETS, plan.signature());
        ModernArrayWrapper created = (ModernArrayWrapper) plan.create(holder, 54, "Příkazy", image,
                FontImage.class, 6, -9);
        assertSame(holder, created.captured[0]);
        assertEquals(54, created.captured[1]);
        assertEquals("Příkazy", created.captured[2]);
        assertEquals(6, created.captured[3]);
        assertEquals(-9, created.captured[4]);
        Object textures = created.captured[5];
        assertEquals(1, Array.getLength(textures));
        assertSame(image, Array.get(textures, 0));
    }

    @Test
    void supportsModernSingleTextureConstructor() throws Exception {
        var plan = ItemsAdderConstructorPolicy.findBest(ModernSingleWrapper.class, Menu.class, FontImage.class);
        assertNotNull(plan);
        assertEquals(ItemsAdderConstructorPolicy.Signature.TITLE_AND_SINGLE_TEXTURE_OFFSETS, plan.signature());
        FontImage image = new FontImage();
        ModernSingleWrapper created = (ModernSingleWrapper) plan.create(new Menu(), 54, "Příkazy", image,
                FontImage.class, 3, 11);
        assertSame(image, created.captured[3]);
        assertEquals(3, created.captured[4]);
        assertEquals(11, created.captured[5]);
    }

    @Test
    void retainsCompatibilityWithLegacyItemsAdderConstructor() throws Exception {
        var plan = ItemsAdderConstructorPolicy.findBest(LegacyWrapper.class, Menu.class, FontImage.class);
        assertNotNull(plan);
        assertEquals(ItemsAdderConstructorPolicy.Signature.LEGACY_TITLE_AND_TEXTURE, plan.signature());
        FontImage image = new FontImage();
        LegacyWrapper created = (LegacyWrapper) plan.create(new Menu(), 54, "Příkazy", image,
                FontImage.class, 5, -7);
        assertEquals(4, created.captured.length);
        assertSame(image, created.captured[3]);
    }

    @Test
    void supportsTextureOnlyConstructorAsLastFallback() throws Exception {
        var plan = ItemsAdderConstructorPolicy.findBest(TextureOffsetWrapper.class, Menu.class, FontImage.class);
        assertNotNull(plan);
        assertEquals(ItemsAdderConstructorPolicy.Signature.TEXTURE_AND_OFFSET, plan.signature());
        FontImage image = new FontImage();
        TextureOffsetWrapper created = (TextureOffsetWrapper) plan.create(new Menu(), 54, "Příkazy", image,
                FontImage.class, 5, -7);
        assertSame(image, created.captured[2]);
        assertEquals(-7, created.captured[3]);
    }

    @Test
    void ignoresUnsupportedSignaturesAndIncompatibleHolderTypes() {
        assertNull(ItemsAdderConstructorPolicy.findBest(IncompatibleWrapper.class, Menu.class, FontImage.class));
        assertNull(ItemsAdderConstructorPolicy.findBest(ModernArrayWrapper.class, String.class, FontImage.class));
        assertNull(ItemsAdderConstructorPolicy.findBest(null, Menu.class, FontImage.class));
    }
}
