package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ProgressMathTest {
    @Test
    void capsProgressAtTarget() {
        assertEquals(10, ProgressMath.addCapped(8, 5, 10));
    }

    @Test
    void treatsNegativeInputsAsZero() {
        assertEquals(4, ProgressMath.addCapped(4, -20, 10));
        assertEquals(3, ProgressMath.addCapped(-50, 3, 10));
        assertEquals(0, ProgressMath.addCapped(-2, -3, -1));
    }

    @Test
    void avoidsIntegerOverflow() {
        assertEquals(Integer.MAX_VALUE, ProgressMath.addCapped(Integer.MAX_VALUE - 2, 100, Integer.MAX_VALUE));
    }

    @Test
    void lifetimeCountersSaturateInsteadOfOverflowing() {
        assertEquals(7L, ProgressMath.addNonNegativeSaturated(4L, 3L));
        assertEquals(Long.MAX_VALUE, ProgressMath.addNonNegativeSaturated(Long.MAX_VALUE - 2, 10));
        assertEquals(5L, ProgressMath.addNonNegativeSaturated(-10L, 5L));
        assertEquals(5L, ProgressMath.addNonNegativeSaturated(5L, -4L));
    }
}
