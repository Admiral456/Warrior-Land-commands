package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VoteEligibilityTest {
    @Test
    void countsOnlyExplicitlyRealAndNotCancelledVotes() {
        assertTrue(VoteEligibility.isCountable(true, false));
        assertFalse(VoteEligibility.isCountable(false, false));
        assertFalse(VoteEligibility.isCountable(true, true));
        assertFalse(VoteEligibility.isCountable(null, false));
        assertFalse(VoteEligibility.isCountable(true, null));
    }
}
