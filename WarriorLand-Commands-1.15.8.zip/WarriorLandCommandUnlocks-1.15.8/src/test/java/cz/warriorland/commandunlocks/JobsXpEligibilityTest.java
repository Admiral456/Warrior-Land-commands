package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JobsXpEligibilityTest {
    @Test
    void countsOnlyPositiveFiniteExperienceFromExplicitlyNonCancelledEvents() {
        assertTrue(JobsXpEligibility.isCountable(1, false));
        assertTrue(JobsXpEligibility.isCountable(0.125, false));
        assertFalse(JobsXpEligibility.isCountable(0, false));
        assertFalse(JobsXpEligibility.isCountable(-1, false));
        assertFalse(JobsXpEligibility.isCountable(Double.NaN, false));
        assertFalse(JobsXpEligibility.isCountable(Double.POSITIVE_INFINITY, false));
        assertFalse(JobsXpEligibility.isCountable(1, true));
        assertFalse(JobsXpEligibility.isCountable(1, null));
        assertFalse(JobsXpEligibility.isCountable(null, false));
    }
}
