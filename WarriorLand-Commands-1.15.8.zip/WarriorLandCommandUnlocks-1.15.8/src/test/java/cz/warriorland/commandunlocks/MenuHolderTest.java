package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MenuHolderTest {
    @Test
    void legacyConstructorRemainsAStandardMenuOrPointsView() {
        MenuHolder commands = new MenuHolder("utility", 2, "workbench", false);
        assertEquals("utility", commands.category());
        assertEquals(2, commands.page());
        assertEquals("workbench", commands.selectedId());
        assertFalse(commands.pointsView());
        assertFalse(commands.confirmationView());

        MenuHolder points = new MenuHolder("all", 0, null, true);
        assertTrue(points.pointsView());
        assertFalse(points.confirmationView());
    }

    @Test
    void confirmationViewIsExplicitAndPreservesNavigationContext() {
        MenuHolder confirmation = new MenuHolder("residence", 1, "residence_tp", false, true);
        assertEquals("residence", confirmation.category());
        assertEquals(1, confirmation.page());
        assertEquals("residence_tp", confirmation.selectedId());
        assertFalse(confirmation.pointsView());
        assertTrue(confirmation.confirmationView());
    }

    @Test
    void negativePageCannotLeakIntoInventoryNavigation() {
        MenuHolder holder = new MenuHolder("all", -5, "tpa", false, true);
        assertEquals(0, holder.page());
        assertTrue(holder.confirmationView());
    }
}
