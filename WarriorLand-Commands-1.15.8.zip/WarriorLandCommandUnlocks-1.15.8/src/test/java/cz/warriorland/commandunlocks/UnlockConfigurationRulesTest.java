package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class UnlockConfigurationRulesTest {
    @Test
    void validatesOptionalStringListsWithoutSilentlyAcceptingScalars() {
        assertTrue(UnlockConfigurationRules.isStringListOrMissing(null));
        assertTrue(UnlockConfigurationRules.isStringListOrMissing(List.of("STONE", "COBBLESTONE")));
        assertFalse(UnlockConfigurationRules.isStringListOrMissing("STONE"));
        assertFalse(UnlockConfigurationRules.isStringListOrMissing(List.of("STONE", 5)));
        assertFalse(UnlockConfigurationRules.isStringListOrMissing(List.of("STONE", "   ")));
    }

    @Test
    void validatesListsOfTaskMaps() {
        assertTrue(UnlockConfigurationRules.isMapList(List.of(Map.of("id", "one"))));
        assertTrue(UnlockConfigurationRules.isMapList(List.of()));
        assertFalse(UnlockConfigurationRules.isMapList("type: BREAK_BLOCK"));
        assertFalse(UnlockConfigurationRules.isMapList(List.of(Map.of("id", "one"), "bad-task")));
        assertFalse(UnlockConfigurationRules.isMapList(null));
    }

    @Test
    void invalidReloadCannotReplaceTheRegistryWithNoUsableUnlocks() {
        assertFalse(UnlockConfigurationRules.hasUsableUnlocks(0));
        assertFalse(UnlockConfigurationRules.hasUsableUnlocks(-1));
        assertTrue(UnlockConfigurationRules.hasUsableUnlocks(1));
        assertTrue(UnlockConfigurationRules.hasUsableUnlocks(5));
    }

    @Test
    void permissionNodesAreExactByDefaultAndWildcardsRequireExplicitOptIn() {
        assertTrue(UnlockConfigurationRules.isPermissionNode("essentials.home", false));
        assertTrue(UnlockConfigurationRules.isPermissionNode("my-plugin:command.use", false));
        assertFalse(UnlockConfigurationRules.isPermissionNode("essentials.warps.*", false));
        assertTrue(UnlockConfigurationRules.isPermissionNode("essentials.warps.*", true));
        assertFalse(UnlockConfigurationRules.isPermissionNode("*", true));
        assertFalse(UnlockConfigurationRules.isPermissionNode("essentials.*.home", true));
        assertFalse(UnlockConfigurationRules.isPermissionNode("essentials..home", false));
        assertFalse(UnlockConfigurationRules.isPermissionNode("essentials.home extra", true));
        assertFalse(UnlockConfigurationRules.isPermissionNode(null, true));
    }

    @Test
    void numericValuesMustBeIntegralAndWithinIntegerRange() {
        assertTrue(UnlockConfigurationRules.isInteger(5));
        assertTrue(UnlockConfigurationRules.isInteger(5.0));
        assertTrue(UnlockConfigurationRules.isInteger("12"));
        assertFalse(UnlockConfigurationRules.isInteger(5.5));
        assertFalse(UnlockConfigurationRules.isInteger(Double.NaN));
        assertFalse(UnlockConfigurationRules.isInteger((long) Integer.MAX_VALUE + 1L));
        assertTrue(UnlockConfigurationRules.isInteger(BigInteger.valueOf(42)));
        assertFalse(UnlockConfigurationRules.isInteger(BigInteger.valueOf(Integer.MAX_VALUE).add(BigInteger.ONE)));
        assertTrue(UnlockConfigurationRules.isInteger(new BigDecimal("2147483647.000")));
        assertFalse(UnlockConfigurationRules.isInteger(new BigDecimal("2147483647.00000001")));
        assertFalse(UnlockConfigurationRules.isInteger("not-a-number"));
        assertEquals(12, UnlockConfigurationRules.integer("12", 1));
        assertEquals(1, UnlockConfigurationRules.integer("invalid", 1));
    }

    @Test
    void invalidAdminAndBypassPermissionSettingsUseSafeDefaults() {
        assertEquals("warriorland.unlocks.admin", UnlockConfigurationRules.permissionSettingOrDefault("", "warriorland.unlocks.admin"));
        assertEquals("warriorland.unlocks.bypass", UnlockConfigurationRules.permissionSettingOrDefault("*", "warriorland.unlocks.bypass"));
        assertEquals("warriorland.unlocks.admin", UnlockConfigurationRules.permissionSettingOrDefault(25, "warriorland.unlocks.admin"));
        assertEquals("custom.admin", UnlockConfigurationRules.permissionSettingOrDefault(" custom.admin ", "warriorland.unlocks.admin"));
    }
}
