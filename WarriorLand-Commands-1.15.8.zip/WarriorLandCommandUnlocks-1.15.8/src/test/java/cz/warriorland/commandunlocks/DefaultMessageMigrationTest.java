package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DefaultMessageMigrationTest {
    @Test
    void updatesTheLegacyBundledBlockedCommandMessage() {
        assertEquals(DefaultMessageMigration.CURRENT_BLOCKED_COMMAND,
                DefaultMessageMigration.migrateBlockedCommand(DefaultMessageMigration.LEGACY_BLOCKED_COMMAND));
    }

    @Test
    void fillsMissingBlockedCommandMessage() {
        assertEquals(DefaultMessageMigration.CURRENT_BLOCKED_COMMAND, DefaultMessageMigration.migrateBlockedCommand(null));
        assertEquals(DefaultMessageMigration.CURRENT_BLOCKED_COMMAND, DefaultMessageMigration.migrateBlockedCommand("  "));
    }

    @Test
    void preservesAdministratorCustomMessage() {
        String custom = "&cPříkaz &e%command% &cnení dostupný. Kontaktuj tým.";
        assertEquals(custom, DefaultMessageMigration.migrateBlockedCommand(custom));
    }
}
