package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CommandLabelTest {
    @Test
    void normalizesSlashCaseNamespaceAndArguments() {
        assertEquals("tpa", CommandLabel.normalize("/Essentials:Tpa Alex"));
        assertEquals("tpaccept", CommandLabel.normalize("//TPACCEPT"));
        assertEquals("balance", CommandLabel.normalize("balance"));
        assertEquals("home", CommandLabel.normalize("/home\tSteve"));
        assertEquals("home", CommandLabel.normalize("/essentials:home\u00A0Steve"));
    }

    @Test
    void nullAndBlankCommandsNormalizeToEmpty() {
        assertEquals("", CommandLabel.normalize(null));
        assertEquals("", CommandLabel.normalize("   "));
    }

    @Test
    void validatesRootLabelsAndLiteralSubcommandSelectors() {
        assertTrue(CommandLabel.isValidConfiguredCommand("tpa"));
        assertTrue(CommandLabel.isValidConfiguredCommand("/essentials:tpa"));
        assertTrue(CommandLabel.isValidConfiguredCommand("my-plugin.command_1"));
        assertTrue(CommandLabel.isValidConfiguredCommand("res tp"));
        assertTrue(CommandLabel.isValidConfiguredCommand("/residence set"));
        assertEquals("res tp", CommandLabel.normalizeConfiguredKey("/Residence:Res TP"));
        assertEquals(List.of("res", "tp", "home"), CommandLabel.inputTokens("/RES tp home"));
        assertFalse(CommandLabel.isValidConfiguredCommand("tpa;op"));
        assertFalse(CommandLabel.isValidConfiguredCommand(""));
        assertFalse(CommandLabel.isValidConfiguredCommand(null));
    }
}
