package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class CommandAliasPolicyTest {
    @Test
    void protectsAliasesWhenExactlyOneUnlockOwnsTheRegisteredCommandGroup() {
        CommandAliasPolicy.Resolution result = CommandAliasPolicy.resolve(
                Map.of("home", "home"),
                List.of(Set.of("home", "h")),
                Set.of("prikazy", "unlock"));
        Map<String, String> owners = result.owners();

        assertEquals("home", owners.get("home"));
        assertEquals("home", owners.get("h"));
    }

    @Test
    void preservesExplicitOwnershipAndDoesNotGuessAmbiguousAliases() {
        CommandAliasPolicy.Resolution result = CommandAliasPolicy.resolve(
                Map.of("home", "home", "sethome", "sethome", "shared", "explicit-owner"),
                List.of(Set.of("home", "h", "shared"), Set.of("sethome", "sh", "shared")),
                Set.of("prikazy"));
        Map<String, String> owners = result.owners();

        assertEquals("home", owners.get("home"));
        assertEquals("sethome", owners.get("sethome"));
        assertEquals("explicit-owner", owners.get("shared"));
        assertNull(owners.get("h"));
        assertNull(owners.get("sh"));
        assertFalse(owners.containsKey("prikazy"));
        assertTrue(result.ambiguousAliases().contains("h"));
        assertTrue(result.ambiguousAliases().contains("sh"));
    }
}
