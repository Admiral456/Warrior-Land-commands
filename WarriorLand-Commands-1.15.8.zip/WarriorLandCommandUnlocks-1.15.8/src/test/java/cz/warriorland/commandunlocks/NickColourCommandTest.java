package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NickColourCommandTest {
    @Test
    void recognizesLegacyMinecraftColoursAndFriendlyNames() {
        assertEquals(Character.valueOf('c'), NickColourCommand.colourCode("red"));
        assertEquals(Character.valueOf('6'), NickColourCommand.colourCode("gold"));
        assertEquals(Character.valueOf('5'), NickColourCommand.colourCode("dark_purple"));
        assertEquals(Character.valueOf('a'), NickColourCommand.colourCode("A"));
        assertNull(NickColourCommand.colourCode("#ff00ff"));
        assertNull(NickColourCommand.colourCode("not-a-color"));
    }

    @Test
    void nicknameValidationRejectsCommandAndFormattingInjection() {
        assertTrue(NickColourCommand.isSafeNickname("Warrior123"));
        assertTrue(NickColourCommand.isSafeNickname("Player_01"));
        assertFalse(NickColourCommand.isSafeNickname("&cAdmin"));
        assertFalse(NickColourCommand.isSafeNickname("Admin;op"));
        assertFalse(NickColourCommand.isSafeNickname("/op"));
        assertFalse(NickColourCommand.isSafeNickname("ANameLongerThanSixteen"));
        assertFalse(NickColourCommand.isSafeNickname("Warrior 123"));
        assertFalse(NickColourCommand.isSafeNickname("Hráč_01"));
        assertFalse(NickColourCommand.isSafeNickname("   "));
    }
}
