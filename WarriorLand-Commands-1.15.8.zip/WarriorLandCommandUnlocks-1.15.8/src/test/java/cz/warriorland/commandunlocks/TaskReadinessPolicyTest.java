package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskReadinessPolicyTest {
    @Test
    void processesLockedItemsOnceRequirementsAreMet() {
        assertTrue(TaskReadinessPolicy.shouldProcess(true, false, false));
        assertTrue(TaskReadinessPolicy.shouldProcess(true, false, true));
    }

    @Test
    void retriesAnUnpaidRewardEvenAfterUnlocking() {
        assertTrue(TaskReadinessPolicy.shouldProcess(true, true, false));
    }

    @Test
    void skipsIncompleteOrFullyProcessedItems() {
        assertFalse(TaskReadinessPolicy.shouldProcess(false, false, false));
        assertFalse(TaskReadinessPolicy.shouldProcess(false, true, false));
        assertFalse(TaskReadinessPolicy.shouldProcess(true, true, true));
    }
}
