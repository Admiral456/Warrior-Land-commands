package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommandGatePolicyTest {
    @Test
    void extractsTheActualCommandFromNormalNamespacedAndWhitespaceForms() {
        assertEquals("tpa", CommandGatePolicy.commandLabel("/tpa Steve"));
        assertEquals("home", CommandGatePolicy.commandLabel("/Essentials:Home\u00a0base"));
        assertEquals("sethome", CommandGatePolicy.commandLabel("//SetHome"));
    }

    @Test
    void doesNotInterceptTheUnlockMenuAliasesOrNonCommandMessages() {
        assertEquals("", CommandGatePolicy.commandLabel(null));
        assertEquals("", CommandGatePolicy.commandLabel("hello there"));
        assertEquals("", CommandGatePolicy.commandLabel("/prikazy admin status"));
        assertEquals("", CommandGatePolicy.commandLabel("/unlock"));
        assertEquals("", CommandGatePolicy.commandLabel("/odemykani"));
    }

    @Test
    void blocksLockedCommandsAndFailsClosedButAllowsUnlockedAndBypass() {
        assertTrue(CommandGatePolicy.shouldBlock(false, false, false));
        assertTrue(CommandGatePolicy.shouldBlock(false, true, true));
        assertFalse(CommandGatePolicy.shouldBlock(false, false, true));
        assertFalse(CommandGatePolicy.shouldBlock(true, true, false));
    }
}
