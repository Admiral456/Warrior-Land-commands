package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SnapshotWritePolicyTest {
    @Test
    void allowsOnlyCurrentOrNewestSnapshot() {
        assertTrue(SnapshotWritePolicy.shouldWrite(7, 6, 7));
        assertTrue(SnapshotWritePolicy.shouldWrite(7, 7, 7));
        assertFalse(SnapshotWritePolicy.shouldWrite(6, 5, 7));
        assertFalse(SnapshotWritePolicy.shouldWrite(6, 7, 7));
    }

    @Test
    void skippedSnapshotIsNotReportedDurableUntilSameOrNewerVersionWasWritten() {
        assertFalse(SnapshotWritePolicy.isDurablyWritten(12, 10));
        assertFalse(SnapshotWritePolicy.isDurablyWritten(12, 11));
        assertTrue(SnapshotWritePolicy.isDurablyWritten(12, 12));
        assertTrue(SnapshotWritePolicy.isDurablyWritten(12, 13));
    }

    @Test
    void staleAsyncSnapshotCannotOverwriteAfterNewerWriteFailed() {
        long olderQueuedSnapshot = 11;
        long failedNewerSyncSnapshot = 12;
        long lastSuccessfulWrite = 10;
        assertFalse(SnapshotWritePolicy.shouldWrite(olderQueuedSnapshot, lastSuccessfulWrite, failedNewerSyncSnapshot));
        assertTrue(SnapshotWritePolicy.shouldWrite(13, lastSuccessfulWrite, 13));
    }
}
