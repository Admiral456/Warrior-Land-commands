package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ResourcePackPolicyTest {
    private static final String HASH = "0123456789abcdef0123456789abcdef01234567";

    @Test void onlyHttpsUrlsWithAHostAreAccepted() {
        assertTrue(ResourcePackPolicy.isValidHttpsUrl("https://cdn.example.org/packs/wl.zip"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("http://cdn.example.org/packs/wl.zip"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("https:///missing-host.zip"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("https://user:password@cdn.example.org/pack.zip"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("https://cdn.example.org/pack.zip#fragment"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("not a url"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("https://cdn.example.org/příkazy.zip"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl("https://cdn.example.org/" + "a".repeat(32_768) + ".zip"));
        assertTrue(ResourcePackPolicy.isValidHttpsUrl("https://cdn.example.org/p%C5%99%C3%ADkazy.zip?rev=15"));
        assertFalse(ResourcePackPolicy.isValidHttpsUrl(""));
    }

    @Test void emptyHashIsOptionalButConfiguredHashMustBeFortyHexDigits() {
        assertTrue(ResourcePackPolicy.isValidSha1OrBlank(null));
        assertTrue(ResourcePackPolicy.isValidSha1OrBlank("  "));
        assertTrue(ResourcePackPolicy.isValidSha1OrBlank(HASH));
        assertTrue(ResourcePackPolicy.isValidSha1OrBlank(HASH.toUpperCase()));
        assertFalse(ResourcePackPolicy.isValidSha1OrBlank("abcd"));
        assertFalse(ResourcePackPolicy.isValidSha1OrBlank("g".repeat(40)));
    }

    @Test void sha1IsDecodedToTwentyBytesInOrder() {
        byte[] decoded = ResourcePackPolicy.decodeSha1(HASH);
        assertNotNull(decoded);
        assertEquals(20, decoded.length);
        assertEquals(0x01, decoded[0] & 0xff);
        assertEquals(0x23, decoded[1] & 0xff);
        assertEquals(0x67, decoded[19] & 0xff);
        assertNull(ResourcePackPolicy.decodeSha1(""));
        assertThrows(IllegalArgumentException.class, () -> ResourcePackPolicy.decodeSha1("bad"));
    }

    @Test void invalidOrIncompleteConfigurationNeverSendsThePack() {
        assertTrue(ResourcePackPolicy.shouldSend("https://cdn.example.org/wl.zip", HASH));
        assertTrue(ResourcePackPolicy.shouldSend("https://cdn.example.org/wl.zip", ""));
        assertFalse(ResourcePackPolicy.shouldSend("http://cdn.example.org/wl.zip", HASH));
        assertFalse(ResourcePackPolicy.shouldSend("https://cdn.example.org/wl.zip", "bad"));
        assertFalse(ResourcePackPolicy.shouldSend("", ""));
        assertNull(ResourcePackPolicy.configurationProblem("", "", false));
        assertNotNull(ResourcePackPolicy.configurationProblem("", "", true));
        assertNotNull(ResourcePackPolicy.configurationProblem("http://cdn.example.org/wl.zip", "", false));
    }

    @Test void requestIdIsStableForOnePackAndChangesWhenUrlOrHashChanges() {
        String url = "https://cdn.example.org/wl.zip";
        UUID first = ResourcePackPolicy.requestId(url, HASH);
        assertEquals(first, ResourcePackPolicy.requestId(url, HASH.toUpperCase()));
        assertNotEquals(first, ResourcePackPolicy.requestId(url + "?rev=2", HASH));
        assertNotEquals(first, ResourcePackPolicy.requestId(url, "abcdef0123456789abcdef0123456789abcdef01"));
        assertThrows(IllegalArgumentException.class, () -> ResourcePackPolicy.requestId("http://cdn.example.org/wl.zip", HASH));
    }
}
