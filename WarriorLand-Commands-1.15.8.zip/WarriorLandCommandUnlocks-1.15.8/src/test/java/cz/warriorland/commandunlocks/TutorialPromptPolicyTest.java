package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TutorialPromptPolicyTest {
    @Test void asksOnlyBeforeAChoiceHasBeenSaved() {
        assertTrue(TutorialPromptPolicy.shouldPrompt(null));
        assertFalse(TutorialPromptPolicy.shouldPrompt(Boolean.TRUE));
        assertFalse(TutorialPromptPolicy.shouldPrompt(Boolean.FALSE));
    }
}
