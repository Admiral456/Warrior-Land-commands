package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommandSearchPolicyTest {
    @Test
    void sanitizesSeparatorsControlsAndLength() {
        assertEquals("chat color", CommandSearchPolicy.sanitize("  chat|color\n"));
        assertEquals("", CommandSearchPolicy.sanitize(null));
        assertEquals("", CommandSearchPolicy.sanitize("  \t\n"));
        assertEquals(48, CommandSearchPolicy.sanitize("x".repeat(100)).length());
        assertEquals(48, CommandSearchPolicy.sanitize("🙂".repeat(70)).codePointCount(0, CommandSearchPolicy.sanitize("🙂".repeat(70)).length()));
    }

    @Test
    void matchesCaseInsensitivelyAndTreatsEmptyQueryAsMatchAll() {
        assertTrue(CommandSearchPolicy.matches("CHAT", "Barevný chat", "/chatcolor"));
        assertTrue(CommandSearchPolicy.matches("teleportace", "Teleportace"));
        assertTrue(CommandSearchPolicy.matches("teleportace", "Teléportace"));
        assertTrue(CommandSearchPolicy.matches("prikaz", "Příkaz"));
        assertTrue(CommandSearchPolicy.matches("", "any command"));
        assertFalse(CommandSearchPolicy.matches("warp", "enderchest", "/ec"));
        assertFalse(CommandSearchPolicy.matches("boss", (String[]) null));
    }

    @Test
    void validatesOnlySupportedSortModes() {
        assertTrue(CommandSearchPolicy.isValidSort("default"));
        assertTrue(CommandSearchPolicy.isValidSort("price-asc"));
        assertTrue(CommandSearchPolicy.isValidSort("price-desc"));
        assertTrue(CommandSearchPolicy.isValidSort("name"));
        assertTrue(CommandSearchPolicy.isValidSort("availability"));
        assertFalse(CommandSearchPolicy.isValidSort("console"));
        assertFalse(CommandSearchPolicy.isValidSort(null));
        assertEquals("availability", CommandSearchPolicy.nextSortMode("default"));
        assertEquals("price-asc", CommandSearchPolicy.nextSortMode("availability"));
        assertEquals("Výchozí pořadí", CommandSearchPolicy.label("default"));
    }
}
