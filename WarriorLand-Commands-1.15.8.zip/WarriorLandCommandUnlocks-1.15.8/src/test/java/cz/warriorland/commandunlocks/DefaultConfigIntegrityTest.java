package cz.warriorland.commandunlocks;

import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class DefaultConfigIntegrityTest {
    private static final Set<String> TASK_TYPES = Set.of(
            "BREAK_BLOCK", "FISH_CAUGHT", "KILL_MOB", "CRAFT_ITEM", "VOTE", "JOBS_ACTION");

    @Test
    void bundledConfigHasUsableUniqueUnlocksAndTheRequiredBlockedCommandMessage() throws IOException, InvalidConfigurationException {
        YamlConfiguration config = load("/config.yml");
        var unlocks = config.getConfigurationSection("unlocks");
        assertNotNull(unlocks, "Bundled config needs an unlocks section");
        assertFalse(unlocks.getKeys(false).isEmpty(), "Bundled config must not fail-open with zero unlocks");

        Set<String> commandLabels = new HashSet<>();
        for (String id : unlocks.getKeys(false)) {
            String path = "unlocks." + id + ".";
            List<String> commands = config.getStringList(path + "commands");
            assertFalse(commands.isEmpty(), id + " must lock at least one command");
            for (String command : commands) {
                assertTrue(CommandLabel.isValidConfiguredCommand(command), id + " has an invalid command label: " + command);
                assertTrue(commandLabels.add(CommandLabel.normalizeConfiguredKey(command)),
                        "Command aliases must be unique after normalization: " + command);
            }

            List<Map<?, ?>> tasks = config.getMapList(path + "tasks");
            assertFalse(tasks.isEmpty(), id + " must require at least one task");
            Set<String> taskIds = new HashSet<>();
            for (Map<?, ?> task : tasks) {
                assertTrue(task.get("id") instanceof String, id + " contains a task without a string id");
                String taskId = ((String) task.get("id")).toLowerCase(java.util.Locale.ROOT);
                assertTrue(taskIds.add(taskId), id + " contains duplicate task id " + taskId);
                assertTrue(task.get("type") instanceof String, id + "/" + taskId + " has no task type");
                assertTrue(TASK_TYPES.contains(((String) task.get("type")).toUpperCase(java.util.Locale.ROOT)),
                        id + "/" + taskId + " has an unsupported task type");
                assertTrue(UnlockConfigurationRules.isInteger(task.get("amount")),
                        id + "/" + taskId + " needs an integral amount");
                assertTrue(UnlockConfigurationRules.integer(task.get("amount"), 0) > 0,
                        id + "/" + taskId + " needs a positive amount");
            }

            List<String> permissions = config.getStringList(path + "permissions");
            assertFalse(permissions.isEmpty(), id + " needs a LuckPerms permission node");
            boolean wildcardsAllowed = config.getBoolean("settings.allow-wildcard-permissions", false);
            for (String permission : permissions) {
                assertTrue(UnlockConfigurationRules.isPermissionNode(permission, wildcardsAllowed),
                        id + " has an invalid LuckPerms node: " + permission);
            }
            assertTrue(UnlockConfigurationRules.isInteger(config.get(path + "cost")), id + " needs an integral cost");
            assertTrue(UnlockConfigurationRules.integer(config.get(path + "cost"), -1) >= 0, id + " has a negative cost");
            assertTrue(UnlockConfigurationRules.isInteger(config.get(path + "task-reward")), id + " needs an integral task reward");
            assertTrue(UnlockConfigurationRules.integer(config.get(path + "task-reward"), -1) >= 0, id + " has a negative task reward");
        }

        String blockedMessage = config.getString("messages.blocked-command", "");
        assertTrue(blockedMessage.contains("Tenhle příkaz ještě nemáš odemčený"),
                "The player-facing text for a locked command must use the approved Czech wording");
        assertTrue(blockedMessage.contains("%command%"), "The message must include the attempted command");
        assertTrue(blockedMessage.contains("/prikazy"), "The message must guide the player to the unlock menu");
    }

    @Test
    void bundledPluginMetadataKeepsTheMenuCommandAndJavaApiLine() throws IOException, InvalidConfigurationException {
        YamlConfiguration metadata = load("/plugin.yml");
        assertEquals("WarriorLandCommandUnlocks", metadata.getString("name"));
        assertEquals("cz.warriorland.commandunlocks.CommandUnlocksPlugin", metadata.getString("main"));
        String expectedVersion = System.getProperty("warriorland.projectVersion");
        assertNotNull(expectedVersion, "Gradle must pass the project version into tests");
        assertEquals(expectedVersion, metadata.getString("version"));
        assertEquals("1.21.10", metadata.getString("api-version"));
        assertNotNull(metadata.getConfigurationSection("commands.prikazy"));
        assertTrue(metadata.getStringList("commands.prikazy.aliases").contains("unlock"));
    }


    @Test
    void optionalResourcePackAndTaskHudDefaultsAreSafeAndDocumented() throws IOException, InvalidConfigurationException {
        YamlConfiguration config = load("/config.yml");
        assertEquals("", config.getString("settings.resource-pack-url", ""));
        assertEquals("", config.getString("settings.resource-pack-sha1", ""));
        assertFalse(config.getBoolean("settings.resource-pack-force", true), "Resource pack must not be forced by default");
        assertFalse(config.getBoolean("settings.use-resource-pack-icons", true), "Custom item models must remain disabled until the pack is distributed");
        assertFalse(config.getBoolean("settings.itemsadder-textured-gui", true), "ItemsAdder textured GUI must be optional by default");
        assertEquals("warriorland_unlocks:command_menu_background", config.getString("settings.itemsadder-font-image"));
        assertEquals(0, config.getInt("settings.itemsadder-title-offset"));
        assertEquals(0, config.getInt("settings.itemsadder-texture-offset"));
        String prompt = config.getString("settings.resource-pack-prompt", "");
        assertNotNull(prompt);
        assertFalse(prompt.isBlank());
        assertTrue(prompt.length() <= 180, "Resource-pack acceptance prompt should be short");
        assertTrue(config.getBoolean("settings.hud-task-progress", false), "Vanilla action-bar task progress should be enabled by default");
        assertTrue(config.getBoolean("settings.hud-status-bar", false), "Persistent native BossBar HUD should be enabled by default");
    }

    @Test
    void defaultActualCommandsAreUnlockedIndependentlyWhileTrueAliasesStayTogether() throws IOException, InvalidConfigurationException {
        YamlConfiguration config = load("/config.yml");
        assertEquals(List.of("tpa"), config.getStringList("unlocks.tpa.commands"));
        assertEquals(List.of("tpaccept"), config.getStringList("unlocks.tpaccept.commands"));
        assertEquals(List.of("tpdeny"), config.getStringList("unlocks.tpdeny.commands"));
        assertEquals(List.of("home"), config.getStringList("unlocks.home.commands"));
        assertEquals(List.of("sethome"), config.getStringList("unlocks.sethome.commands"));
        assertEquals(List.of("balance", "bal"), config.getStringList("unlocks.balance.commands"));
        assertEquals(List.of("enderchest", "ec"), config.getStringList("unlocks.enderchest.commands"));
        assertTrue(config.getConfigurationSection("unlocks").getKeys(false).size() >= 40,
                "WarriorLand should ship at least 40 unlockable commands/functions");
        assertEquals(List.of("chatcolour", "chatcolor"), config.getStringList("unlocks.chatcolour.commands"));
        assertEquals(List.of("ChatColor2"), config.getStringList("unlocks.chatcolour.required-plugins"));
        assertEquals(List.of("Essentials"), config.getStringList("unlocks.nickcolour.required-plugins"));
        assertTrue(config.getStringList("unlocks.chatcolour.permissions").contains("chatcolor.clear"));
        assertFalse(config.isConfigurationSection("unlocks.chatcolor"), "chatcolor is an alias, not a second paid unlock");
        assertFalse(config.isConfigurationSection("unlocks.other"), "unverified 'other' is not a saleable function");
        assertTrue(config.getString("settings.purchase-title", "").contains("Potvrdit nákup"));
        assertTrue(config.isConfigurationSection("categories.residence"));
        assertNotNull(load("/plugin.yml").getConfigurationSection("commands.chatcolour"));
        assertNotNull(load("/plugin.yml").getConfigurationSection("commands.nickcolour"));
        assertTrue(config.getStringList("unlocks.residence_tp.commands").containsAll(List.of("res tp", "residence tp")));
    }


    @Test
    void residenceSubcommandsHaveSeparateSelectorsAndAreNotCollapsedToTheRoot() throws IOException, InvalidConfigurationException {
        YamlConfiguration config = load("/config.yml");
        assertEquals(List.of("res tp", "residence tp"), config.getStringList("unlocks.residence_tp.commands"));
        assertEquals(List.of("res list", "residence list"), config.getStringList("unlocks.residence_list.commands"));
        assertNotEquals(config.getStringList("unlocks.residence_tp.commands"), config.getStringList("unlocks.residence_list.commands"));
        assertTrue(config.getStringList("unlocks.residence_tp.commands").stream().allMatch(c -> CommandLabel.normalizeConfiguredKey(c).endsWith(" tp")));
        assertTrue(config.getStringList("unlocks.residence_list.commands").stream().allMatch(c -> CommandLabel.normalizeConfiguredKey(c).endsWith(" list")));
    }

    @Test
    void reviewedCustomCommandsRemainOneFunctionPerPurchaseAndDoNotInventOther() throws IOException, InvalidConfigurationException {
        YamlConfiguration config = load("/config.yml");
        var unlocks = config.getConfigurationSection("unlocks");
        assertNotNull(unlocks);
        assertEquals(List.of("chatcolour", "chatcolor"), config.getStringList("unlocks.chatcolour.commands"));
        assertFalse(unlocks.contains("chatcolor"), "American and British spelling must not be sold twice");
        assertFalse(unlocks.contains("other"), "The meaning of 'other' is unverified and must not be sold");
        assertEquals(List.of("workbench"), config.getStringList("unlocks.workbench.commands"));
        assertEquals(List.of("ignore"), config.getStringList("unlocks.ignore.commands"));
        assertEquals(List.of("nick"), config.getStringList("unlocks.nick.commands"));
        assertEquals(List.of("nickcolour"), config.getStringList("unlocks.nickcolour.commands"));
        assertTrue(config.getStringList("unlocks.residence_tp.commands").containsAll(List.of("res tp", "residence tp")));
    }

    private YamlConfiguration load(String path) throws IOException, InvalidConfigurationException {
        InputStream stream = getClass().getResourceAsStream(path);
        assertNotNull(stream, "Missing bundled resource " + path);
        try (stream; InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            YamlConfiguration configuration = new YamlConfiguration();
            configuration.options().parseComments(true);
            configuration.load(reader);
            return configuration;
        }
    }
}
