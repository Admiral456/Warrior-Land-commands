package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ResourcePackIconPolicyTest {
    @Test void disabledIconsAlwaysUseVanillaFallback() {
        assertFalse(ResourcePackIconPolicy.canUseCustomIcons(false, true, "https://cdn.example.org/wl.zip", false, true));
        assertFalse(ResourcePackIconPolicy.canUseCustomIcons(false, true, "", true, false));
    }

    @Test void automaticDeliveryRequiresSuccessfulLoadOfConfiguredPack() {
        String url = "https://cdn.example.org/wl.zip";
        assertTrue(ResourcePackIconPolicy.canUseCustomIcons(true, true, url, false, true));
        assertFalse(ResourcePackIconPolicy.canUseCustomIcons(true, true, url, false, false));
    }

    @Test void missingOrInvalidConfigurationNeverUsesCustomModelsByDefault() {
        assertFalse(ResourcePackIconPolicy.canUseCustomIcons(true, false, "https://cdn.example.org/wl.zip", true, true));
        assertFalse(ResourcePackIconPolicy.canUseCustomIcons(true, true, "", false, false));
    }

    @Test void manualDistributionRequiresExplicitUnverifiedOptIn() {
        assertFalse(ResourcePackIconPolicy.canUseCustomIcons(true, true, "", false, false));
        assertTrue(ResourcePackIconPolicy.canUseCustomIcons(true, true, "", true, false));
    }
}
