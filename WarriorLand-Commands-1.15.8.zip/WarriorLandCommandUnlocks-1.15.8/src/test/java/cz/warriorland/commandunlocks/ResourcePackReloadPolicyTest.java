package cz.warriorland.commandunlocks;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ResourcePackReloadPolicyTest {
    private static final UUID OLD_PACK = UUID.fromString("11111111-2222-3333-4444-555555555555");
    private static final UUID NEW_PACK = UUID.fromString("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee");

    @Test void onlyAChangedExistingPackIsRemoved() {
        assertFalse(ResourcePackReloadPolicy.shouldRemovePrevious(null, NEW_PACK));
        assertFalse(ResourcePackReloadPolicy.shouldRemovePrevious(OLD_PACK, OLD_PACK));
        assertTrue(ResourcePackReloadPolicy.shouldRemovePrevious(OLD_PACK, NEW_PACK));
        assertTrue(ResourcePackReloadPolicy.shouldRemovePrevious(OLD_PACK, null));
    }

    @Test void emptyConfigurationClearsLoadedMarkers() {
        assertTrue(ResourcePackReloadPolicy.shouldClearLoadedState(null));
        assertFalse(ResourcePackReloadPolicy.shouldClearLoadedState(NEW_PACK));
    }

    @Test void changedPackIsOfferedToAllOnlinePlayers() {
        assertTrue(ResourcePackReloadPolicy.shouldOfferAfterReload(NEW_PACK, OLD_PACK, false));
        assertTrue(ResourcePackReloadPolicy.shouldOfferAfterReload(NEW_PACK, null, false));
        assertFalse(ResourcePackReloadPolicy.shouldOfferAfterReload(null, OLD_PACK, true));
        assertFalse(ResourcePackReloadPolicy.shouldOfferAfterReload(OLD_PACK, OLD_PACK, false));
    }

    @Test void forceModeChangeOnlyReoffersToPlayersWithoutSuccessfulLoad() {
        assertTrue(ResourcePackReloadPolicy.shouldOfferAfterReload(OLD_PACK, OLD_PACK, true));
        assertFalse(ResourcePackReloadPolicy.shouldOfferToPlayer(OLD_PACK, OLD_PACK, false, true));
        assertTrue(ResourcePackReloadPolicy.shouldOfferToPlayer(OLD_PACK, null, false, true));
        assertTrue(ResourcePackReloadPolicy.shouldOfferToPlayer(NEW_PACK, OLD_PACK, true, false));
        assertFalse(ResourcePackReloadPolicy.shouldOfferToPlayer(null, null, true, true));
    }
}
